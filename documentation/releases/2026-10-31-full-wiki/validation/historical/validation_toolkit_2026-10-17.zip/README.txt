VALIDATION TOOLKIT - SYNTHETIC FIXTURES ONLY

Node.js and Playwright: npm install playwright ; npx playwright install chromium
Python tools: python -m pip install -r requirements.txt ; python -m playwright install chromium

node test_ml.js
node test_panel.js
node test_names.js path/to/index.html
node test_edges.js path/to/index.html path/to/synthetic.rdml path/to/synthetic.eds
node test_selection.js path/to/index.html first.ixo second.ixo first.eds second.eds

Use the individually supplied synthetic ZIPs for those inputs. Files are read in supplied order. Scripts write results/screenshots into their own folder. Node scripts optionally accept PLAYWRIGHT_MODULE and CHROME_PATH environment variables for installed runtimes. No private lab fixture paths are embedded. Generator and verifier instructions are supplied with the synthetic demo.

Scope: engine/panel checks, synthetic sample-selection and name-pattern regressions, population/export scenario verification tools. Passing software tests is not clinical validation or calibrated statistical performance. No real laboratory data included.
