/* Tests for the advisory engine. Revision 2 after independent review.
   Run: node test_ml.js
   Three kinds of check, deliberately:
     REF  — against closed-form mathematics or published values, computed here
            by an independent route, not by the code under test;
     BEH  — the behaviour the panel relies on;
     GUARD— the properties the review asked to be enforced before release
            (no mutation of inputs, determinism, honest degenerate handling).  */
const m=require('./ml_advisory.js');
let fail=0,n=0;
const ok=(c,msg)=>{n++;if(!c)fail++;console.log((c?'PASS  ':'FAIL  ')+msg);};
const near=(a,b,tol,msg)=>ok(Math.abs(a-b)<=tol,`${msg} (got ${Number(a).toPrecision(10)}, want ${Number(b).toPrecision(10)})`);

/* ---------------- REF: distributions ---------------- */
near(m.mlBetaI(0.5,2,3),0.6875,1e-12,'REF  I_0.5(2,3) = 11/16 exactly');
near(m.mlBetaI(0.3,1,1),0.3,1e-12,'REF  I_x(1,1) = x');
near(m.mlTinv(0.975,1),12.70620474,1e-6,'REF  t(0.975, 1 dof) = 12.70620');
near(m.mlTinv(0.975,2),4.302652730,1e-8,'REF  t(0.975, 2 dof) = 4.3026527');
near(m.mlTinv(0.975,10),2.228138852,1e-8,'REF  t(0.975, 10 dof) = 2.2281389');
near(m.mlTinv(0.975,30),2.042272456,1e-8,'REF  t(0.975, 30 dof) = 2.0422725');
near(m.mlTinv(0.995,15),2.946712883,1e-8,'REF  t(0.995, 15 dof) = 2.9467129');
near(m.mlTinv(0.975,1e7),1.959963985,1e-5,'REF  t -> normal quantile as dof grows');
[1,3,7,20,100].forEach(d=>near(m.mlTcdf(m.mlTinv(0.975,d),d),0.975,1e-9,`REF  t quantile round-trips at ${d} dof`));
near(m.mlChi2Upper(3.841459,1),0.05,1e-6,'REF  chi-square upper tail at 3.8415, 1 df = 0.05');
near(m.mlChi2Upper(18.30704,10),0.05,1e-6,'REF  chi-square upper tail at 18.307, 10 df = 0.05');
near(m.mlChi2Upper(0,5),1,1e-12,'REF  chi-square upper tail at 0 = 1');

/* ---------------- REF: linear algebra and leverage ---------------- */
{
  const A=[[4,7],[2,6]],Ai=m.mlMatInv(A);
  near(Ai[0][0],0.6,1e-12,'REF  2x2 inverse, element [0][0]');
  near(Ai[0][1],-0.7,1e-12,'REF  2x2 inverse, element [0][1]');
  const P=[[2,1,1],[1,3,2],[1,0,0]],Pi=m.mlMatInv(P);
  let maxOff=0;
  for(let i=0;i<3;i++)for(let j=0;j<3;j++){
    let s=0;for(let k=0;k<3;k++)s+=P[i][k]*Pi[k][j];
    maxOff=Math.max(maxOff,Math.abs(s-(i===j?1:0)));}
  ok(maxOff<1e-12,'REF  3x3 inverse satisfies A A^-1 = I (max error '+maxOff.toExponential(2)+')');
}
{
  /* The leverage of a straight-line fit has a closed form. The code computes
     v'(X'X)^-1 v generically, so for degree 1 the two must agree exactly --
     and for degree 2 they must NOT, which is the defect the review found. */
  const x=Array.from({length:40},(_,i)=>i/39);
  const y=x.map(v=>1+2*v+0.5*v*v);
  const xbar=m.mlMean(x),sxx=x.reduce((s,v)=>s+(v-xbar)*(v-xbar),0);
  const textbook=xv=>1/x.length+Math.pow(xv-xbar,2)/sxx;
  const f1=m.mlPolyFit(x,y,1),f2=m.mlPolyFit(x,y,2);
  const xf=1.1;                                   /* just beyond the data */
  near(f1.lev(xf),textbook(xf),1e-12,'REF  degree 1 leverage equals 1/n + (x-xbar)^2/Sxx');
  near(f1.lev(0.5),textbook(0.5),1e-12,'REF  degree 1 leverage matches inside the data too');
  ok(f2.lev(xf)>textbook(xf)*1.2,
     `BEH  degree 2 leverage exceeds the linear formula at the forecast point (${f2.lev(xf).toFixed(6)} vs ${textbook(xf).toFixed(6)})`);
  /* independent recomputation of the quadratic leverage from the design */
  const X=x.map(v=>[1,v,v*v]);
  const XtX=[0,1,2].map(i=>[0,1,2].map(j=>X.reduce((s,r)=>s+r[i]*r[j],0)));
  const inv=m.mlMatInv(XtX),v=[1,xf,xf*xf];
  let q=0;for(let i=0;i<3;i++)for(let j=0;j<3;j++)q+=v[i]*inv[i][j]*v[j];
  near(f2.lev(xf),q,1e-9,'REF  degree 2 leverage equals an independently computed v\'(X\'X)^-1 v');
}
{
  /* AICc must count the residual variance as an estimated parameter. */
  const x=Array.from({length:30},(_,i)=>i),rng=m.mlRng(7);
  const y=x.map(v=>3+0.2*v+(rng()-0.5));
  const f=m.mlPolyFit(x,y,1),k=f.p+1;
  const want=f.n*Math.log(f.rss/f.n)+2*k+2*k*(k+1)/(f.n-k-1);
  near(f.aicc,want,1e-9,'REF  AICc uses k = coefficients + 1 for the variance');
}

/* ---------------- BEH: forecast ---------------- */
{
  const x=Array.from({length:40},(_,i)=>i+1),rng=m.mlRng(11);
  const y=x.map(v=>10+0.25*v+(rng()-0.5)*0.4);
  const f=m.mlForecast(x,y,5);
  ok(f.model==='linear','BEH  a straight trend keeps the linear model (got '+f.model+', margin '+Number(f.selectionMargin).toFixed(2)+')');
  near(f.points[4].y,10+0.25*45,0.6,'BEH  five-step forecast lands near the truth');
  ok(f.points[0].lo<f.points[0].y&&f.points[0].y<f.points[0].hi,'BEH  the interval brackets the forecast');
  near(f.points[0].half,m.mlTinv(0.975,f.dof)*f.points[0].se,1e-12,
       'REF  half-width is exactly t(0.975, dof) * standard error');
  near(f.points[0].se/f.sigma,Math.sqrt(1+Math.pow(f.points[0].se/f.sigma,2)-1),1e-12,
       'REF  the standard error carries the sqrt(1 + leverage) factor');
  ok(f.points[4].se>f.points[0].se,'BEH  the interval widens with distance from the data ('
     +f.points[0].se.toFixed(4)+' -> '+f.points[4].se.toFixed(4)+')');
  ok(f.tQuantile>1.96&&f.tQuantile<2.1,'BEH  a Student-t quantile is used, not 1.96 (got '+f.tQuantile.toFixed(4)+')');
  ok(f.dof===40-(f.degree+1),'BEH  degrees of freedom are n - p (got '+f.dof+')');
  ok(f.independence.ok===true,'BEH  independent noise passes the independence screen (p '+f.independence.p.toFixed(3)+')');
  ok(f.intervalReliable===true,'BEH  the interval is offered when the screen passes');
  ok(Math.abs(f.stepX-1)<1e-9,'BEH  the assumed future spacing is the median observed step');
}
{
  /* Strong positive autocorrelation: the interval must be withheld, not
     silently drawn too narrow. */
  const n=60,phi=0.9,rng=m.mlRng(5),e=[];let prev=0;
  for(let i=0;i<n;i++){prev=phi*prev+(rng()-0.5);e.push(prev);}
  const x=Array.from({length:n},(_,i)=>i+1),y=x.map((v,i)=>5+0.01*v+e[i]);
  const f=m.mlForecast(x,y,5);
  ok(f.independence.ok===false,'GUARD autocorrelated residuals fail the screen (Ljung-Box p '+f.independence.p.toExponential(2)+')');
  ok(f.intervalReliable===false,'GUARD the interval is marked unreliable so the panel can withhold it');
  ok(f.independence.r1>0.5,'BEH  the lag-1 autocorrelation is reported ('+f.independence.r1.toFixed(3)+')');
}
{
  const x=Array.from({length:30},(_,i)=>i+1);
  const y=x.map(v=>2+0.5*v+0.08*v*v);
  const q=m.mlForecast(x,y,3);
  ok(q.model==='quadratic','BEH  real curvature does select the quadratic model (margin '+Number(q.selectionMargin).toFixed(1)+')');
  ok(q.selectionMargin>=2,'BEH  and it wins by more than the parsimony margin ('+q.selectionMargin.toFixed(1)+')');
  {  /* a line with noise must not be reported as a curve on any of these seeds */
    let curved=0;
    for(const sd of [1,2,3,4,5,6,7,8]){
      const r=m.mlRng(sd),xx=Array.from({length:40},(_,i)=>i+1);
      const yy=xx.map(v=>10+0.25*v+(r()-0.5)*0.4);
      if(m.mlForecast(xx,yy,3).model!=='linear')curved++;
    }
    ok(curved===0,'GUARD a straight trend is never reported as curved across eight seeds (got '+curved+')');
  }
  ok(m.mlForecast([1,2,3,4,5],[1,2,3,4,5],3)===null,'GUARD fewer than eight runs returns null, not a guess');
}

{
  /* Interval coverage, measured the way the panel behaves.

     The second review was right that the previous version of this test did not
     measure what the panel offers: it counted every interval, including those
     the panel would withhold, used one origin per synthetic history, tested one
     step and one process shape, and its ablation changed both the leverage term
     and the critical value so the difference could not be attributed to either.

     What is measured here, and what it does and does not establish:
       - ROLLING ORIGIN within a single history: the fit walks forward one run
         at a time over the same series, which is how the panel is actually used
         -- repeatedly, on a growing history -- rather than once on each of many
         independent histories;
       - horizons 1 to 5, since the panel shows five;
       - three process shapes: straight line with independent noise, quadratic,
         and AR(1), the last to confirm that dependence is mostly WITHHELD
         rather than silently miscovered;
       - offered and withheld are counted separately, and coverage is reported
         CONDITIONAL ON BEING OFFERED, because a withheld interval makes no
         claim to cover anything.
     None of this is evidence about a real instrument archive, and none of it is
     a post-selection guarantee: the model is chosen from the same data, so the
     nominal level is not exact even where coverage lands near it.            */
  const normalFrom=rng=>()=>{const u=Math.max(rng(),1e-12),v=rng();
    return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);};
  const rollingOrigin=(gen,opts)=>{
    const {n,first,hmax,reps,seed}=opts;
    let offered=0,withheld=0,fits=0;
    const hit=new Array(hmax).fill(0),tried=new Array(hmax).fill(0);
    let widthSum=0,widthN=0;
    for(let rep=0;rep<reps;rep++){
      const rng=m.mlRng(seed+rep*7919),nz=normalFrom(rng);
      const x=Array.from({length:n},(_,i)=>i+1),y=gen(x,nz);
      for(let o=first;o<=n-hmax;o++){
        const f=m.mlForecast(x.slice(0,o),y.slice(0,o),hmax);
        if(!f)continue;
        fits++;
        if(!f.intervalReliable){withheld++;continue;}
        offered++;
        f.points.forEach((p,h)=>{
          if(o+h>=n)return;
          tried[h]++;widthSum+=p.hi-p.lo;widthN++;
          if(y[o+h]>=p.lo&&y[o+h]<=p.hi)hit[h]++;
        });
      }
    }
    return {fits,offered,withheld,hit,tried,
      cover:hit.map((h,i)=>tried[i]?h/tried[i]:NaN),
      meanWidth:widthN?widthSum/widthN:NaN};
  };
  const lin=(x,nz)=>x.map(v=>5+0.3*v+nz()*0.8);
  const quad=(x,nz)=>x.map(v=>5+0.3*v+0.004*v*v+nz()*0.8);
  const ar1=(x,nz)=>{let e=0;return x.map(v=>{e=0.9*e+nz()*0.5;return 5+0.05*v+e;});};

  const L=rollingOrigin(lin,{n:60,first:20,hmax:5,reps:40,seed:20261012});
  console.log(`        linear   : ${L.fits} fits, ${L.offered} offered / ${L.withheld} withheld`
    +` · coverage by horizon ${L.cover.map(c=>(100*c).toFixed(1)+'%').join(' ')} · mean width ${L.meanWidth.toFixed(2)}`);
  ok(L.offered>500,'REF  rolling origin on a linear process produced '+L.offered+' offered intervals');
  ok(L.cover.every(c=>c>0.90&&c<0.99),
     'REF  coverage conditional on being offered is within 90-99 % at every horizon 1..5');
  ok(L.cover[0]>L.cover[4]-0.08,'BEH  coverage does not collapse as the horizon grows');

  const Q=rollingOrigin(quad,{n:60,first:20,hmax:5,reps:40,seed:777});
  console.log(`        quadratic: ${Q.fits} fits, ${Q.offered} offered / ${Q.withheld} withheld`
    +` · coverage by horizon ${Q.cover.map(c=>(100*c).toFixed(1)+'%').join(' ')}`);
  ok(Q.offered>400,'BEH  the quadratic process also yields offered intervals ('+Q.offered+')');
  ok(Q.cover.every(c=>c>0.85),'REF  coverage on a curved process stays above 85 % at every horizon');

  const A=rollingOrigin(ar1,{n:60,first:20,hmax:5,reps:40,seed:4242});
  const withheldShare=A.withheld/(A.offered+A.withheld);
  console.log(`        AR(1)    : ${A.fits} fits, ${A.offered} offered / ${A.withheld} withheld`
    +` (${(100*withheldShare).toFixed(1)} % withheld)`);
  ok(withheldShare>0.5,'GUARD on an AR(1) process the majority of intervals are WITHHELD ('
    +(100*withheldShare).toFixed(1)+' %), so dependence is declined rather than miscovered');

  {
    /* Ablation of the leverage term ALONE: same series, same selected degree,
       same Student-t critical value and the same sigma; the only difference is
       sqrt(1 + v'(X'X)^-1 v) against sqrt(1 + 1/n). */
    let inFull=0,inNoLev=0,tot=0;
    for(let rep=0;rep<60;rep++){
      const rng=m.mlRng(31337+rep),nz=normalFrom(rng);
      const n=40,x=Array.from({length:n},(_,i)=>i+1),y=lin(x,nz);
      for(let o=25;o<=n-1;o++){
        const xs=x.slice(0,o),ys=y.slice(0,o);
        const x0=xs[0],sx=(xs[o-1]-x0)||1,xn=xs.map(v=>(v-x0)/sx);
        const f=m.mlPolyFit(xn,ys,1);
        if(!f)continue;
        const d=[];for(let i=1;i<xn.length;i++)d.push(xn[i]-xn[i-1]);
        const xf=xn[xn.length-1]+(m.mlMedian(d)||1);
        const t=m.mlTinv(0.975,f.dof),yh=f.fit(xf);
        const full=t*f.sigma*Math.sqrt(1+f.lev(xf));
        const noLev=t*f.sigma*Math.sqrt(1+1/f.n);
        tot++;
        if(Math.abs(y[o]-yh)<=full)inFull++;
        if(Math.abs(y[o]-yh)<=noLev)inNoLev++;
      }
    }
    console.log(`        ablation : leverage term present ${(100*inFull/tot).toFixed(1)} %`
      +` vs absent ${(100*inNoLev/tot).toFixed(1)} % over ${tot} one-step forecasts`);
    ok(inNoLev<inFull,'REF  with the model and the critical value held identical, dropping the leverage term alone undercovers');
    ok(inFull/tot>0.92&&inFull/tot<0.98,'REF  and with it present, one-step coverage is near nominal');
  }
}

/* ---------------- BEH/GUARD: change points ---------------- */
{
  /* The review's example: three levels. The table must agree with the figure. */
  const y=[].concat(Array(30).fill(0),Array(30).fill(10),Array(30).fill(20));
  const r=m.mlChangepoints(y,3);
  ok(r.points.length===2,'BEH  three levels give two change points (got '+r.points.length+')');
  near(r.points[0].before,0,1e-9,'GUARD first change point reports the final segment mean before it (0)');
  near(r.points[0].after,10,1e-9,'GUARD first change point reports 10, not the greedy 15');
  near(r.points[1].after,20,1e-9,'GUARD second change point reports 20');
  ok(r.segments.map(s=>Math.round(s.level)).join(',')==='0,10,20',
     'GUARD the segment levels match the plotted segments ('+r.segments.map(s=>s.level.toFixed(0)).join(',')+')');
  {  /* a single extreme run must not be reported as a pair of level changes */
    const rng=m.mlRng(77),z=[];
    for(let i=0;i<60;i++)z.push(5+(rng()-0.5)*0.2);
    z[25]=25;
    const s1=m.mlChangepoints(z,3);
    ok(s1.points.length===0,'GUARD one wild run produces no level change (got '+s1.points.length+')');
    const w=[];for(let i=0;i<60;i++)w.push((i<30?5:9)+(rng()-0.5)*0.2);
    w[10]=25;
    const s2=m.mlChangepoints(w,3);
    ok(s2.points.length===1&&Math.abs(s2.points[0].index-30)<=2,
       'GUARD a real shift survives the screen even with an outlier present (points '+s2.points.length+')');
    near(s2.points[0].before,5,0.2,'GUARD and its level before is the robust median');
  }
}
{
  const rng=m.mlRng(3),y=[];
  for(let i=0;i<60;i++)y.push((i<30?10:13)+(rng()-0.5)*0.6);
  const r=m.mlChangepoints(y,3);
  ok(r.points.length===1&&Math.abs(r.points[0].index-30)<=2,'BEH  a single step is found at the right place (index '+(r.points[0]||{}).index+')');
  ok(/within the regimes|successive differences/.test(r.scaleKind),'BEH  the penalty scale is a within-regime scale, not the shifted SD ('+r.scaleKind+')');
  ok(r.scale<1,'BEH  that scale is not inflated by the shift (got '+r.scale.toFixed(3)+')');
}
{
  const rng=m.mlRng(9),y=Array.from({length:60},()=>5+(rng()-0.5)*0.4);
  ok(m.mlChangepoints(y,3).points.length===0,'BEH  no change point in a stable series');
}

/* ---------------- BEH/GUARD: unusualness rank ---------------- */
{
  const rng=m.mlRng(4),y=Array.from({length:40},()=>1+(rng()-0.5)*0.2);
  y[17]=3.0;
  const a=m.mlAnomalyScores(y);
  const order=a.scores.map((s,i)=>({s:s.score,i})).filter(o=>Number.isFinite(o.s)).sort((p,q)=>q.s-p.s);
  ok(order[0].i===17,'BEH  the planted outlier ranks first (got index '+order[0].i+')');
  const s17=a.scores[17];
  near(s17.score,Math.max(s17.robust,s17.local),1e-12,'GUARD the score is max(robust, local) -- novelty no longer drives it');
  ok(Number.isFinite(s17.novelty),'BEH  novelty is still reported, for information');
  ok(a.scaleKind==='scaled MAD','BEH  the scale used is named ('+a.scaleKind+')');
}
{
  const y=Array(30).fill(7);
  const a=m.mlAnomalyScores(y);
  ok(a.degenerate===true&&/identical/.test(a.note),'GUARD a constant series is refused, not divided by 1e-9');
  const r=Array.from({length:30},(_,i)=>i%2?7.0:7.1);r[10]=7.4;
  const b=m.mlAnomalyScores(r);
  ok(b.scaleKind!=='scaled MAD'||b.scale>0.01,'GUARD a rounded series does not get a 1e-9 scale (scale '+b.scale.toExponential(2)+', '+b.scaleKind+')');
  ok(b.scores.every(s=>!Number.isFinite(s.score)||s.score<1e6),'GUARD no score explodes on a resolution-limited series');
}
{
  const a=[1,2,3,4,5],b=m.mlMad(a.concat([100]));
  ok(b<3,'BEH  the MAD barely moves with one wild value ('+b.toFixed(3)+')');
  ok(m.mlSd(a.concat([100]))>10,'BEH  the SD does move, which is why the MAD is used');
}

/* ---------------- REF/BEH: PCA, T-squared and the residual distance ---------------- */
{
  const rng=m.mlRng(21),rows=[];
  for(let i=0;i<60;i++){const t=rng()*2-1;
    rows.push([t+0.02*(rng()-0.5),t+0.02*(rng()-0.5),rng()-0.5,rng()-0.5]);}
  /* a fault in the near-null direction: the two correlated metrics move apart */
  rows[25]=[2.2,-2.2,0.1,-0.1];
  const p=m.mlPCA(rows,2,1234);
  ok(p.p===4&&p.rank===4,'BEH  every direction is computed; rank reported ('+p.rank+' of '+p.p+')');
  near(p.eig.reduce((s,e)=>s+e.value,0),4,1e-6,'REF  the eigenvalues of a correlation matrix sum to the metric count');
  ok(p.retained>0.3&&p.retained<1,'BEH  the retained variance share is reported ('+(100*p.retained).toFixed(1)+' %)');
  const speOrder=p.spe.map((v,i)=>({v,i})).sort((a,b)=>b.v-a.v);
  ok(speOrder[0].i===25,'BEH  the residual distance Q catches the fault in a discarded direction (top index '+speOrder[0].i+')');
  ok(p.spe[25]>p.speUcl,'BEH  that run is above the Q reference percentile');
  ok(p.limitKind.indexOf('retrospective')===0,'GUARD the limits are labelled retrospective');
  ok(m.mlPCA([[1,2,3],[2,3,4]],2,1)===null,'GUARD too few rows returns null');
}

/* ---------------- REF/GUARD: the k-means++ weighted draw ---------------- */
{
  /* The defect: the loop subtracted the chosen weight and then advanced, so a
     variate falling in an interior bin selected the NEXT point. Tested here
     directly rather than inferred from a clustering result. */
  const w=[1,1,1,1];                      /* cumulative edges at .25 .5 .75 */
  near(m.mlWeightedDraw(w,0.10),0,0,'REF  weighted draw: u = 0.10 selects bin 0');
  near(m.mlWeightedDraw(w,0.30),1,0,'REF  weighted draw: u = 0.30 selects bin 1');
  near(m.mlWeightedDraw(w,0.60),2,0,'REF  weighted draw: u = 0.60 selects bin 2');
  near(m.mlWeightedDraw(w,0.90),3,0,'REF  weighted draw: u = 0.90 selects bin 3');
  near(m.mlWeightedDraw([0,0,1],0.5),2,0,'REF  weighted draw skips zero-weight bins');
  const counts=[0,0,0],rng=m.mlRng(99),ww=[0.6,0.3,0.1];
  for(let i=0;i<30000;i++)counts[m.mlWeightedDraw(ww,rng())]++;
  const share=counts.map(c=>c/30000);
  ok(Math.abs(share[0]-0.6)<0.02&&Math.abs(share[1]-0.3)<0.02&&Math.abs(share[2]-0.1)<0.02,
     'REF  draw frequencies match the weights ('+share.map(s=>s.toFixed(3)).join(', ')+')');
}
{
  const pts=[];for(let i=0;i<30;i++)pts.push([i<15?0:10,i<15?0:10]);
  const km=m.mlKMeans(pts,2,1);
  ok(km.sizes[0]===15&&km.sizes[1]===15,'BEH  two separated clouds split evenly ('+km.sizes.join('/')+')');
  near(km.silhouette,1,1e-9,'REF  silhouette of two identical well-separated clouds is 1');
  ok(!Number.isFinite(m.mlSilhouette(pts,pts.map(()=>0),1)),'GUARD silhouette is undefined at k = 1');
}
{
  const rng=m.mlRng(31),uni=Array.from({length:40},()=>[rng(),rng()]);
  const s=m.mlClusterStructure(uni,8,4,12);
  ok(s.structure===false,'GUARD a uniform cloud is reported as no more structured than chance (silhouette '+s.silhouette.toFixed(3)+' vs null '+s.nullQ90.toFixed(3)+')');
  const rng2=m.mlRng(32),two=Array.from({length:40},(_,i)=>[(i<20?0:8)+rng2()*0.4,(i<20?0:8)+rng2()*0.4]);
  const s2=m.mlClusterStructure(two,8,4,12);
  ok(s2.structure===true&&s2.k===2,'BEH  two genuine clouds are found, with k chosen by silhouette (k '+s2.k+')');
}

/* ---------------- BEH/GUARD: the driver model ---------------- */
{
  const rng=m.mlRng(17),X=[],y=[];
  for(let i=0;i<80;i++){const a=rng(),b=rng(),c=rng();
    X.push([a,b,c]);y.push(a>0.55?1:0);}
  const sp=m.mlTimeSplit(80,0.7);
  const L=m.mlLogistic(X,y,{iters:500,lambda:1,holdout:{
    Xtr:X.slice(0,sp.cut),ytr:y.slice(0,sp.cut),
    Xte:X.slice(sp.cut),yte:y.slice(sp.cut),schemaFrozen:true}});
  ok(L.w[0]>Math.abs(L.w[1])&&L.w[0]>Math.abs(L.w[2]),'BEH  the driving metric gets the largest weight');
  ok(L.aucIn>0.85,'BEH  in-sample AUC recovers the signal ('+L.aucIn.toFixed(3)+')');
  ok(Number.isFinite(L.aucOut),'GUARD an out-of-time AUC is computed from the supplied holdout ('+L.aucOut.toFixed(3)+')');
  ok(L.nTrain+L.nTest===80&&L.nTest>0,'GUARD the later period is held out ('+L.nTrain+' train / '+L.nTest+' test)');
  ok(L.schemaFrozen===true,'GUARD the caller declares whether the feature schema was frozen on training rows');
  ok(L.enoughEvents===true,'BEH  the event floor passes with '+L.nPos+' flagged runs and '+L.p+' metrics');
  const D=m.mlLogistic(X,y,{iters:200});
  ok(!Number.isFinite(D.aucOut)&&/no held-out period/.test(D.outWhy),
     'GUARD with no holdout supplied there is no out-of-time number, and the reason says so');
}
{
  const rng=m.mlRng(18),X=[],y=[];
  for(let i=0;i<40;i++){X.push([rng(),rng(),rng(),rng(),rng(),rng()]);y.push(i===3||i===9?1:0);}
  const L=m.mlLogistic(X,y,{iters:200});
  ok(L.enoughEvents===false,'GUARD two flagged runs across six metrics fails the event floor');
  near(L.eventsPerFeature,2/6,1e-12,'BEH  events per feature is reported');
}
{
  /* Training-only standardisation: shifting the held-out period must not move
     the training statistics, so the fitted weights are untouched. */
  const rng=m.mlRng(23),X=[],y=[];
  for(let i=0;i<60;i++){const a=rng();X.push([a,rng()]);y.push(a>0.5?1:0);}
  const sp=m.mlTimeSplit(60,0.7);
  const hold=Xs=>({Xtr:Xs.slice(0,sp.cut),ytr:y.slice(0,sp.cut),
    Xte:Xs.slice(sp.cut),yte:y.slice(sp.cut),schemaFrozen:true});
  const A=m.mlLogistic(X,y,{iters:300,holdout:hold(X)});
  const X2=X.map((r,i)=>i>=sp.cut?[r[0]+100,r[1]]:r.slice());
  const B=m.mlLogistic(X,y,{iters:300,holdout:hold(X2)});
  ok(JSON.stringify(A.w)===JSON.stringify(B.w),'GUARD the fitted weights do not depend on the held-out values');
  ok(A.nTrain===B.nTrain,'GUARD the training split does not depend on the held-out values');
  ok(A.aucOut!==B.aucOut,'BEH  but the out-of-time score does, so the period is genuinely held out');
}

/* ---------------- GUARD: determinism and no mutation ---------------- */
{
  const y=[1,2,3,4,5,4,3,2,1,2,3,4,5,6,5,4,3,2,1,2];
  const a=JSON.stringify(m.mlChangepoints(y,2)),b=JSON.stringify(m.mlChangepoints(y,2));
  ok(a===b,'GUARD the same input gives the same output');
  const pts=Array.from({length:30},(_,i)=>[i%7,i%5]);
  ok(JSON.stringify(m.mlKMeans(pts,2,1).assign)===JSON.stringify(m.mlKMeans(pts,2,1).assign),
     'GUARD clustering is reproducible with the same seed');
}
{
  /* Nothing in the engine may write to the caller's arrays. Freezing them makes
     any assignment throw in strict mode and silently fail otherwise, so both
     the absence of an exception and the unchanged content are checked. */
  const x=Object.freeze(Array.from({length:40},(_,i)=>i+1));
  const yv=Array.from({length:40},(_,i)=>10+0.1*i+(i===20?2:0));
  const y=Object.freeze(yv.slice());
  const before=JSON.stringify(y);
  let threw='';
  try{
    m.mlForecast(x,y,5);m.mlChangepoints(y,3);m.mlAnomalyScores(y);
    const rows=Object.freeze(Array.from({length:40},(_,i)=>Object.freeze([i%5,i%3,i%7,i%11])));
    m.mlPCA(rows,2,1);
    m.mlLogistic(rows.map(r=>r.slice()),rows.map((_,i)=>i%4===0?1:0),{iters:100});
    m.mlKMeans(rows.map(r=>r.slice()),2,1);
  }catch(e){threw=e.message;}
  ok(threw==='','GUARD no engine function writes to a frozen input'+(threw?' ('+threw+')':''));
  ok(JSON.stringify(y)===before,'GUARD the input series is unchanged after every call');
}

console.log('\n'+(n-fail)+' of '+n+' checks passed'+(fail?' — '+fail+' FAILED':''));
process.exit(fail?1:0);
