"""QuantStudio-style .eds writer.

The archive is a ZIP whose entries all live under apldbio/sds/.  Names are
looked up exactly, so no leading ./ and no extra root folder.

What matters for coverage:

  messages.log            every software and most hardware charts.  Each line
                          must be "<Kind> <epoch.fraction> <rest>", with one
                          space after the kind, or it is skipped outright.
  calibrations/*.ini      calib_uniformity, calib_background, calib_roi, and
                          the calibration-validity criterion
  quant/*.quant           saturation, and the instrument serial
  multicomponentdata.xml  rox_level, rox_cv
  analysis_result.txt     Ct, calls, Rn/dRn curves, standard curves
  analysis_protocol.xml   thresholds, hence ctRecalc and ct_mismatch
  instrumentdata.mf       handoff_min
  extensions/Tamper       the integrity verdict: MD5 over every other entry,
                          in archive order, as uppercase hex with no padding
"""
import hashlib, math, zipfile

from curves import rn_curve, crossing
from layout import CHANNELS, PASSIVE_DYE, EDS_TASK

P = "apldbio/sds/"
DYES = [c[5] for c in CHANNELS] + [PASSIVE_DYE]
QS_FILTER = {"FAM": "x1-m1", "VIC": "x2-m2", "ABY": "x3-m3", "JUN": "x4-m4",
             "MUSTANG PURPLE": "x6-m6"}
# Rn is written on a scale of roughly 1e3 to 3e3 rather than 1 to 3.
#
# The page's unanalysed-signal test uses an ABSOLUTE noise floor of
# max(3, 6*MAD, 0.02*reference amplitude) in stored fluorescence units.  On an
# Rn axis of 1.0 to 3.1 every amplitude is about 2.1, below the floor of 3, so no
# QuantStudio orphan could ever be detected however rising the trace — which is
# exactly what an earlier version of this generator ran into.  Thresholds below
# are on the same scale.
RN_SCALE = 1000.0
THRESHOLD = {"35S": 200.0, "T-NOS": 240.0, "HMG": 180.0, "LEC": 220.0}


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _grid(rows, cols, f):
    return "\n".join(",".join("%.4f" % f(i, j) for j in range(cols)) for i in range(rows))


def _cal_head(name, ts_ms, exp_ms, rows, cols, serial):
    return ("# Instrument calibration file. Synthetic.\n\n[head]\nname=%s\nversion=1.0.5\n"
            "timestamp=%d\nexpirytime=%d\ncalibrationID=1\noperator=GUEST\n\n"
            "[instrument]\nversion=0.14.10\nsn=%s\ntype=appletini\nblockid=18\n"
            "numofrow=%d\nnumofcol=%d\n\n" % (name, ts_ms, exp_ms, serial, rows, cols))


def build(path, spec, wells, meta, rng):
    rows, cols = spec["rows"], spec["cols"]
    npos, cycles = rows * cols, spec["cycles"]
    t0 = spec["start_epoch"]
    name = spec["name"]
    serial = spec["serial"]
    sc = meta.get("scenario", "normal")
    ents = []

    def add(n, data):
        ents.append((P + n, data.encode("utf-8") if isinstance(data, str) else data))

    # ---------- curves and results ----------------------------------------
    res, mc = {}, {}
    by_pos = {w.pos: w for w in wells}
    for w in wells:
        for ch, (_n, _e, _m, _i, target, dye) in enumerate(CHANNELS):
            if target not in w.cq:
                continue
            cq = w.cq[target]
            # amp_scale below 1 is probe or dye degradation (see missy/ixo.py)
            rn, drn = rn_curve(cq, cycles, rng, base=RN_SCALE * (1.0 + 0.02 * ch),
                               top=RN_SCALE * (2.1 - 0.12 * ch) * spec.get("amp_scale", 1.0),
                               noise=RN_SCALE * 0.0035)
            thr = THRESHOLD[target]
            rc = crossing(drn, thr)
            res[(w.pos, target)] = (rn, drn, cq, rc)
        sig = {}
        for ch, (_n, _e, _m, _i, target, dye) in enumerate(CHANNELS):
            r = res.get((w.pos, target))
            # multicomponent counts stay near 1e5, as an instrument writes them
            sig[dye] = [100.0 * v for v in (r[0] if r else
                        [RN_SCALE * (1.0 + rng.gauss(0, 0.004)) for _ in range(cycles)])]
        # passive reference: level sets rox_level, well-to-well spread sets rox_cv
        lv = spec.get("rox_level", 148000.0) * (1 + rng.gauss(0, spec.get("rox_cv", 0.012)))
        sig[PASSIVE_DYE] = [lv + rng.gauss(0, 420) for _ in range(cycles)]
        mc[w.pos] = sig

    # ---------- Manifest.mf ------------------------------------------------
    add("Manifest.mf",
        "Manifest-Version: 1.0\nContent-Type: %s\n"
        "Implementation-Title: QuantStudio 3 and 5 Software\n"
        "Implementation-Version: 1.7.2\nSpecification-Vendor: synthetic\n"
        "Specification-Title: Experiment Document Specification\n"
        "Specification-Version: 1.3.1\n\n" % spec.get("kind", "Std"))

    # ---------- experiment.xml ---------------------------------------------
    run_state = "ABORTED" if sc == "runstate_aborted" else "COMPLETE"
    samples = sorted({w.name for w in wells})
    ex = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "<Experiment>",
          "<Id>%s</Id>" % spec["uid"], "<Name>%s</Name>" % _esc(name),
          "<RunState>%s</RunState>" % run_state,
          "<FinalAnalysisCompleted>%s</FinalAnalysisCompleted>"
          % ("false" if run_state != "COMPLETE" else "true"),
          "<CreatedTime>%d</CreatedTime>" % int(spec["created_epoch"] * 1000),
          "<ModifiedTime>%d</ModifiedTime>" % int(spec["modified_epoch"] * 1000),
          "<RunStartTime>%d</RunStartTime>" % int(t0 * 1000),
          "<RunEndTime>%d</RunEndTime>" % int(spec["end_epoch"] * 1000),
          "<FileName>D:\\synthetic\\%s.eds</FileName>" % _esc(name),
          "<Label>RUO / synthetic demonstration</Label>",
          "<Operator>%s</Operator>" % _esc(spec["operator"]),
          "<Comment>%s</Comment>" % _esc(spec["notes"]),
          "<Barcode>SYN-%s</Barcode>" % spec["plate_id"],
          "<Type><Id>%s</Id><Name>%s</Name></Type>"
          % (spec.get("kind", "Std"),
             "Comparative CT (&#916;&#916;CT)" if spec.get("kind") == "rq" else "Standard Curve"),
          "<Samples>" + "".join(
              "<Sample><Name>%s</Name><Color>-5236961</Color>"
              "<Concentration>1.0</Concentration></Sample>" % _esc(s) for s in samples)
          + "</Samples>",
          "<Detectors>" + "".join(
              "<Detector><Name>%s</Name><Reporter>%s</Reporter><Quencher>None</Quencher>"
              "<Color>-32768</Color></Detector>" % (c[4], c[5]) for c in CHANNELS)
          + "</Detectors>",
          "<ChemistryType>TAQMAN</ChemistryType>",
          "<TCProtocolMode>Standard</TCProtocolMode>",
          "<DNATemplateType>WET_DNA</DNATemplateType>",
          "<InstrumentTypeId>appletini</InstrumentTypeId>",
          "<BlockTypeID>18</BlockTypeID>",
          "<PlateTypeID>TYPE_%dX%d</PlateTypeID>" % (rows, cols),
          '<ExperimentProperty type="InstrumentInfo">'
          '<PropertyValue key="instrumentType"><String>%s</String></PropertyValue>'
          '<PropertyValue key="instrumentSerialNumber"><String>%s</String></PropertyValue>'
          '<PropertyValue key="instrumentName"><String>%s</String></PropertyValue>'
          '<PropertyValue key="blockSerialNumber"><String>SYNBLK-%s</String></PropertyValue>'
          "</ExperimentProperty>"
          % (spec["instrument_type"], serial, spec["instrument_name"], serial),
          '<ExperimentProperty type="InstrumentTypeInfo">'
          '<PropertyValue key="INSTRUMENT_TYPE_KEY"><String>%s</String></PropertyValue>'
          "</ExperimentProperty>" % spec["type_key"],
          "<Reagents><Reagent><Type>Master Mix</Type><Name>synthetic master mix</Name>"
          "<PartNumber>SYN-MM-001</PartNumber><LotNumber>%s</LotNumber>"
          "<ExpirationDate>2027-06-30</ExpirationDate></Reagent></Reagents>" % spec["lot"],
          "</Experiment>"]
    add("experiment.xml", "\n".join(ex))

    # ---------- plate_setup.xml -------------------------------------------
    ps = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "<Plate>",
          "<Name>%s</Name>" % _esc(spec["plate_id"]),
          "<Rows>%d</Rows><Columns>%d</Columns>" % (rows, cols),
          "<PlateKind><Name>%d-Well Plate (%dx%d)</Name><Type>TYPE_%dX%d</Type>"
          "<RowCount>%d</RowCount><ColumnCount>%d</ColumnCount></PlateKind>"
          % (npos, rows, cols, rows, cols, rows, cols),
          "<BarCode>SYN-%s</BarCode>" % spec["plate_id"]]
    ps.append("<FeatureMap><Feature><Id>sample</Id><Name>sample</Name></Feature>" + "".join(
        "<FeatureValue><Index>%d</Index><FeatureItem><Sample><Name>%s</Name>"
        "<Color>-5236961</Color></Sample></FeatureItem></FeatureValue>"
        % (w.pos, _esc(w.name)) for w in sorted(wells, key=lambda x: x.pos)) + "</FeatureMap>")

    def tasks(w):
        s = ""
        for (_n, _e, _m, _i, target, dye) in CHANNELS:
            if target not in w.cq and not (w.orphan and target == CHANNELS[0][4]):
                continue
            s += ("<DetectorTask><Task>%s</Task><Concentration>%s</Concentration>"
                  "<Detector><Name>%s</Name><Reporter>%s</Reporter>"
                  "<Quencher>None</Quencher><Color>-32768</Color></Detector></DetectorTask>"
                  % (EDS_TASK[w.role], "1.0" if w.qty is None else repr(w.qty), target, dye))
        return s

    ps.append("<FeatureMap><Feature><Id>detector-task</Id><Name>detector-task</Name></Feature>"
              + "".join("<FeatureValue><Index>%d</Index><FeatureItem><DetectorTaskList>%s"
                        "</DetectorTaskList></FeatureItem></FeatureValue>" % (w.pos, tasks(w))
                        for w in sorted(wells, key=lambda x: x.pos)) + "</FeatureMap>")
    ps.append("<FeatureMap><Feature><Id>comment</Id><Name>comment</Name></Feature>"
              + "".join("<FeatureValue><Index>%d</Index><FeatureItem>%s</FeatureItem>"
                        "</FeatureValue>" % (w.pos, _esc(w.note)) for w in wells if w.note)
              + "</FeatureMap>")
    wl = []
    for i in range(npos):
        w = by_pos.get(i)
        s = "<Well><Index>%d</Index><IsOmit>%s</IsOmit>" % (i, "true" if (w and w.omit) else "false")
        if w:
            for code in w.flags:
                for (_n, _e, _m, _i, target, _d) in CHANNELS:
                    if target in w.cq:
                        s += "<FlagName>%s-%s</FlagName>" % (code, target)
                        break
        wl.append(s + "</Well>")
    passive_xml = PASSIVE_DYE
    ps.append("<Wells>" + "".join(wl) + "</Wells>"
              "<PassiveReferenceDye>%s</PassiveReferenceDye></Plate>" % passive_xml)
    add("plate_setup.xml", "\n".join(ps))

    # plate_setup.ini — a different reference here is the passive-reference mismatch
    ini_ref = "ROX" if sc == "passive_mismatch" else PASSIVE_DYE
    add("plate_setup.ini",
        "[head]\nname = PlateLayout\n\n[block]\nnumWells = %d\nnumRows = %d\nnumCols = %d\n\n"
        "[dye]\nplate = %d-Well Plate (%dx%d)\ndyes = %s\nreference= %s\n\n[layout]\n"
        % (npos, rows, cols, npos, rows, cols, ",".join(DYES), ini_ref)
        + "".join("%s%d = %s\n" % ("ABCDEFGHIJKLMNOP"[i // cols], i % cols + 1, ",".join(DYES))
                  for i in range(npos)))

    # ---------- tcprotocol.xml --------------------------------------------
    def step(coll, temp, hold, ramp=2.7):
        return ("<TCStep><CollectionFlag>%d</CollectionFlag><RampRate>%s</RampRate>"
                "<Temperature>%s</Temperature><Temperature>%s</Temperature>"
                "<HoldTime>%d</HoldTime><CollectionMode>%s</CollectionMode></TCStep>"
                % (coll, ramp, temp, temp, hold, "ENDPOINT" if coll else "NONE"))
    prot_cycles = cycles + 1 if sc == "cycle_mismatch" else cycles
    add("tcprotocol.xml",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><TCProtocol>'
        "<BlockID>18</BlockID><SampleVolume>20.0</SampleVolume><RunMode>Standard</RunMode>"
        "<CoverTemperature>105.0</CoverTemperature>"
        "<TCStage><StageFlag>PRE_CYCLING</StageFlag><NumOfRepetitions>1</NumOfRepetitions>"
        + step(0, "95.0", 300) + "</TCStage>"
        "<TCStage><StageFlag>CYCLING</StageFlag><NumOfRepetitions>%d</NumOfRepetitions>" % prot_cycles
        + step(0, "95.0", 15) + step(1, "60.0", 60) + "</TCStage>"
        '<CollectionProfile ProfileId="1">'
        + "".join('<CollectionCondition><FilterSet Excitation="%s" Emission="%s"/>'
                  "<Frames>0</Frames></CollectionCondition>"
                  % tuple(QS_FILTER[c[5]].split("-")) for c in CHANNELS)
        + "</CollectionProfile></TCProtocol>")

    # ---------- analysis_protocol.xml -------------------------------------
    def jv(n, typ, tag, val):
        return ('<JaxbSettingValue><Name>%s</Name><JaxbValueItem type="%s">'
                "<%s>%s</%s></JaxbValueItem></JaxbSettingValue>" % (n, typ, tag, val, tag))

    def det(obj, thr, auto=True):
        return ("<JaxbAnalysisSettings><Type>com.apldbio.sds.platform.core.analysis."
                "IDetectorSettings</Type>" + jv("ConfidenceLevel", "Double", "DoubleValue", "99.0")
                + jv("Threshold", "Double", "DoubleValue", thr)
                + jv("AutoBaseline", "Boolean", "BooleanValue", "true" if auto else "false")
                + jv("BaselineStart", "Integer", "IntValue", 3)
                + jv("BaselineStop", "Integer", "IntValue", 15)
                + jv("AutoCt", "Boolean", "BooleanValue", "true" if auto else "false")
                + jv("ObjectName", "String", "StringValue", obj) + "</JaxbAnalysisSettings>")

    manual_thr = sc in ("ct_mismatch", "manual")
    ap = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><JaxbAnalysisProtocol>'
          "<Name>synthetic</Name>" + det("AnalysisProtocol.DEFAULT_SETTINGS", 0.2))
    for (_n, _e, _m, _i, target, _d) in CHANNELS:
        ap += det(target, THRESHOLD[target], auto=not manual_thr)
    for w in sorted(wells, key=lambda x: x.pos):
        if not w.manual:
            continue
        for (_n, _e, _m, _i, target, _d) in CHANNELS:
            if target in w.cq:
                ap += ("<JaxbAnalysisSettings><Type>com.apldbio.sds.platform.core.analysis."
                       "IWellSettings</Type>" + jv("WellIndex", "Integer", "IntValue", w.pos)
                       + jv("ObjectName", "String", "StringValue", target)
                       + jv("BaselineStart", "Integer", "IntValue", 5)
                       + jv("BaselineStop", "Integer", "IntValue", 18)
                       + jv("AutoBaseline", "Boolean", "BooleanValue", "false")
                       + jv("UseDetectorDefaults", "Boolean", "BooleanValue", "false")
                       + "</JaxbAnalysisSettings>")
                break
    ap += ("<JaxbAnalysisSettings><Type>com.apldbio.sds.platform.core.analysis."
           "ISignalSmoothingSettings</Type>"
           + jv("SignalSmoothing", "Boolean", "BooleanValue", "true") + "</JaxbAnalysisSettings>")
    ap += ("<JaxbAnalysisSettings><Type>com.apldbio.sds.platform.core.analysis."
           "IDataSelectSettings</Type>" + jv("StageNum", "Integer", "IntValue", 2)
           + jv("StepNum", "Integer", "IntValue", 2) + jv("PointNum", "Integer", "IntValue", 1)
           + "</JaxbAnalysisSettings>")
    ap += ("<JaxbAnalysisSettings><Type>com.apldbio.sds.platform.core.analysis."
           "IAlgorithmSelectSettings</Type>"
           + jv("AlgorithmName", "String", "StringValue", "default") + "</JaxbAnalysisSettings>")
    for code, crit in (("NHC", "LESS_THAN 35.0"), ("HSD", "GREATER_THAN 0.5"),
                       ("CC", "LESS_THAN 0.8"), ("EAF", "LESS_THAN 0.8")):
        ap += ("<AnalysisSetting><Type>%s</Type><SettingValue><Name>enabled</Name>"
               "<Type>Boolean</Type><BooleanValue>true</BooleanValue></SettingValue>"
               "<SettingValue><Name>criteria</Name><Type>String</Type>"
               "<StringValue>%s</StringValue></SettingValue>"
               "<SettingValue><Name>omitEnabled</Name><Type>Boolean</Type>"
               "<BooleanValue>false</BooleanValue></SettingValue></AnalysisSetting>"
               % (code, crit))
    if spec.get("kind") == "rq":
        # The delta-delta-Ct settings the page reads for a relative-quantification
        # document.  Without the endogenous control and the calibrator it does not
        # build rqResults, and the relative-quantification export stays unavailable.
        ap += ("<JaxbAnalysisSettings><Type>com.apldbio.sds.platform.core.analysis."
               "IDDCtAnalysisSettings</Type>"
               + jv("EndogenousControl", "String", "StringValue", "HMG")
               + jv("Calibrator", "String", "StringValue", spec.get("calibrator", ""))
               + jv("RQConfidence", "Double", "DoubleValue", "95.0")
               + jv("Multiplex", "Boolean", "BooleanValue", "true") + "</JaxbAnalysisSettings>")
    add("analysis_protocol.xml", ap + "</JaxbAnalysisProtocol>")

    # ---------- analysis_result.txt ---------------------------------------
    L = ["Session Name\t",
         "Well\tSample Name\tDetector\tTask\tCt\tAvg Ct\tCt SD\tDelta Ct\tQty\tAvg Qty\t"
         "Qty SD\tAmp Status\tCq Conf"]
    fmt = lambda a: "\t".join("%.7g" % v for v in a)
    # replicate means, by sample name and target
    groups = {}
    for w in wells:
        for target, cq in w.cq.items():
            groups.setdefault((w.name, target), []).append(cq)
    done_std, rq_seen = set(), set()
    for w in sorted(wells, key=lambda x: x.pos):
        for (_n, _e, _m, _i, target, _d) in CHANNELS:
            if target not in w.cq:
                continue
            rn, drn, cq, rc = res[(w.pos, target)]
            g = [v for v in groups[(w.name, target)] if v is not None]
            mean = sum(g) / len(g) if g else None
            sd = (sum((v - mean) ** 2 for v in g) / (len(g) - 1)) ** 0.5 if len(g) > 1 else None
            if cq is None:
                ct_txt, amp = "Undetermined", "-1"
            else:
                shown = cq + (0.9 if sc == "ct_mismatch" else 0.0)
                ct_txt, amp = "%.5f" % shown, ("0" if "CC" in w.flags else "1")
            if w.call == 2 and cq and cq >= cycles:
                amp = "1"
            L.append("\t".join([
                str(w.pos), w.name, target, EDS_TASK[w.role].title(), ct_txt,
                "" if mean is None else "%.5f" % mean,
                "" if sd is None else "%.5f" % sd, "",
                "" if w.qty is None else repr(w.qty),
                "" if w.qty is None else repr(w.qty), "", amp,
                "0.61" if "CC" in w.flags else "0.97"]))
            L.append("Rn values\t" + fmt(rn))
            L.append("Delta Rn values\t" + fmt(drn))
            # A delta-delta-Ct triplet becomes one rqResults row, and it attaches
            # to the result block it follows.  Emitted after every block they all
            # attach to the last well and the page builds exactly one row, which
            # is what a first attempt here produced.
            if (spec.get("kind") == "rq" and w.role == "unknown" and target != "HMG"
                    and cq is not None and (w.name, target) not in rq_seen):
                rq_seen.add((w.name, target))
                dct = round(cq - 22.6, 4)
                rq = round(2.0 ** (-(dct - 8.0)), 4)
                L.append("DDCT Values\t%d\t%s\t%s\t\t\t\t%s\t%s\t0.04\t0.03\t\t%s\t%s\t%s\tfalse\t%s"
                         % (w.pos, w.name, target, dct, dct, rq, round(rq * 0.86, 4),
                            round(rq * 1.17, 4), round(dct - 8.0, 4)))
                L.append("Study Stat Values\t2.0\t%s\t%s\t0.04\t0.03" % (dct, dct))
                L.append("Study RQ Values\t0\t%s\t%s\t%s\t%s"
                         % (rq, round(rq * 0.86, 4), round(rq * 1.17, 4), round(dct - 8.0, 4)))
            if target in meta.get("std_targets", []) and target not in done_std:
                done_std.add(target)
                slope = -spec.get("std_slope", 3.32)
                eff = (10 ** (-1 / slope) - 1) * 100
                std = sorted([x for x in wells if x.role == "standard" and x.cq.get(target)],
                             key=lambda x: -x.qty)
                L.append("Std Curve Results\t%s\t%.4f\t%.4f\t\t%.3f\t"
                         % (target, 0.9972, slope, 35.4))
                L.append("Std Curve Results X Values\t"
                         + "\t".join("%.4f" % math.log10(x.qty) for x in std))
                L.append("Std Curve Results Y Values\t"
                         + "\t".join("%.4f" % x.cq[target] for x in std))
    # a rising trace with no sample name: an orphan for the EDS path
    for (pos, _ch, cq) in meta.get("orphans", []):
        # The unanalysed trace is given a strong amplitude on purpose.  The noise
        # floor is max(3, 6*MAD, 0.02*median) over the amplitudes of the analysed
        # curves, and on a plate where most analysed wells do amplify that MAD is
        # large: an orphan of ordinary amplitude (2101) fell just under the floor
        # (2117) and was not reported.  A contaminating signal worth flagging is
        # the one that stands clear of that spread.
        rn, drn = rn_curve(cq, cycles, rng, base=RN_SCALE, top=RN_SCALE * 4.2,
                           noise=RN_SCALE * 0.0035)
        L.append("\t".join([str(pos), "", CHANNELS[0][4], "Unknown", "Undetermined",
                            "", "", "", "", "", "", "-1", "0.41"]))
        L.append("Rn values\t" + fmt(rn))
        L.append("Delta Rn values\t" + fmt(drn))
    add("analysis_result.txt", "\r\n".join(L) + "\r\n")

    # ---------- multicomponentdata.xml ------------------------------------
    m = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><MulticomponentData>'
         "<WellCount>%d</WellCount><CycleCount>%d</CycleCount>" % (npos, cycles)]
    for i in range(npos):
        m.append('<DyeData WellIndex="%d"><DyeList>[%s]</DyeList></DyeData>'
                 % (i, ", ".join(DYES)))
    for i in range(npos):
        s = mc.get(i) or {d: [1000.0 + rng.gauss(0, 6) for _ in range(cycles)] for d in DYES}
        m.append('<SignalData WellIndex="%d">' % i
                 + "".join("<CycleData>[%s]</CycleData>" % ", ".join("%.2f" % v for v in s[d])
                           for d in DYES) + "</SignalData>")
    add("multicomponentdata.xml", "".join(m) + "</MulticomponentData>")
    add("puredyematrix.txt",
        "[common]\nnumofrow=%d\nnumofcol=%d\n\n[puredyes]\ndyes=%s\n" % (rows, cols, ",".join(DYES)))

    # ---------- filterdata.xml ---------------------------------------------
    # Raw counts per filter set and cycle.  Without it run.eds.raw.sets is empty
    # and the "Multicomponent and raw filter data" export stays unavailable.
    # One PlatePointData per filter per cycle; an entry missing either
    # FILTER_SET or CYCLE is skipped by the parser.
    fd = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          "<PlatePointDataCollection><Name>FilterData</Name>"]
    for c in range(cycles):
        for (_n, _e, _m, _i, target, dye) in CHANNELS:
            vals = []
            for i in range(npos):
                s_ = mc.get(i)
                vals.append(s_[dye][c] if s_ else 1000.0 + rng.gauss(0, 6))
            fd.append("<PlatePointData><Stage>2</Stage><Cycle>%d</Cycle><Step>2</Step>"
                      "<Point>1</Point><PlateData><Rows>%d</Rows><Cols>%d</Cols>"
                      "<WellData>%s</WellData>"
                      "<Attribute><key>FILTER_SET</key><value>%s</value></Attribute>"
                      "<Attribute><key>CYCLE</key><value>%d</value></Attribute>"
                      "<Attribute><key>TYPE</key><value>QUANT</value></Attribute>"
                      "</PlateData></PlatePointData>"
                      % (c + 1, rows, cols, "\t".join("%.1f" % v for v in vals),
                         QS_FILTER[dye], c + 1))
    add("filterdata.xml", "".join(fd) + "</PlatePointDataCollection>")

    # ---------- calibrations ----------------------------------------------
    cal_ts = int((t0 - 45 * 86400) * 1000)
    cal_exp = int((t0 - 2 * 86400) * 1000) if sc == "cal_expired" else int((t0 + 320 * 86400) * 1000)
    head = lambda n: _cal_head(n, cal_ts, cal_exp, rows, cols, serial)
    edge = spec.get("calib_edge", 1.14)
    add("calibrations/uniformity.ini", head("UniformityCalibration")
        + "[uniformity]\nx1-m1=<<eof\n"
        + _grid(rows, cols, lambda i, j: edge if (i in (0, rows - 1) or j in (0, cols - 1)) else 1.0)
        + "\neof\n\n[QC]\npassed=1\n")
    bg = spec.get("calib_bg", 2300.0)
    add("calibrations/background.ini", head("BackgroundCalibration")
        + "[background_offset]\nx1-m1=<<eof\n"
        + _grid(rows, cols, lambda i, j: bg * (-1) ** (i + j) + 7 * i)
        + "\neof\n\n[QC]\npassed=1\n")
    add("calibrations/roi.ini", head("ROICalibration") + "[roi_diameter]\n"
        + "".join("%s=%.5f\n" % (QS_FILTER[c[5]], spec.get("calib_roi", 35.5) + 0.03 * k)
                  for k, c in enumerate(CHANNELS))
        + "\n[horizontal_pos]\nx1-m1=1\n")
    add("calibrations/puredye.ini", head("PureDyeCalibration")
        + "[puredyes]\ndyes=%s\n" % ",".join(DYES))

    # ---------- quant ------------------------------------------------------
    sat_bad = spec.get("saturated_wells", 0)
    qhead = ("[instrument]\nblockid\tnumofrow\tnumofcol\tcoversn\tversion\tcoverid\t"
             "lamphours\tblocksn\ttype\tsn\n18\t%d\t%d\t*\t%s\t*\t*\t*\truo\t%s\n\n"
             "[head]\nversion\tname\n1.0.5\tQuantitation\n\n"
             % (rows, cols, spec["firmware"], serial))
    for k, c in enumerate(CHANNELS):
        x, mm = QS_FILTER[c[5]].split("-")
        body = qhead + "[quant]\nregion\tquant\tcount\tsaturation\n"
        for i in range(npos):
            body += "IA%d\t%d\t%d\t%d\n" % (i + 1, 2700000 + i * 31, 990,
                                            1 if (k == 0 and i < sat_bad) else 0)
        add("quant/S02_C001_T02_P0001_%s_%s_E1.quant" % (mm.upper(), x.upper()), body)
    add("quant/2-1-2-1-m1-x1.xml",
        '<?xml version="1.0" ?><run><dyeIniFile>/data/vendor/IS/experiments/%s/apldbio/'
        "sds/calibrations/puredye.ini</dyeIniFile></run>" % _esc(name))
    add("instrumentdata.mf",
        "#%s\nInstrument-Data-Version=1.0\n" % spec["mf_date"])
    add("tools.xml",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Tools>'
        '<ToolInfo vendor="synthetic" description="primary analysis" version="4.1.1.4" '
        'name="Primary Analysis Module" id="com.apldbio.sds.platform.algorithm.primary.module"/>'
        '<ToolInfo vendor="synthetic" description="ct" version="1.3.0" name="Ct Module" '
        'id="com.apldbio.sds.platform.algorithm.ct.module"/></Tools>')
    add("export_setting.xml",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><ExportSetting>'
        "<ExportFormat>QuantStudio</ExportFormat><OutputFormat>xls</OutputFormat>"
        "<ExportFileName>%s</ExportFileName>"
        "<ExportFileLocation>D:\\synthetic</ExportFileLocation></ExportSetting>" % _esc(name))

    # ---------- messages.log ----------------------------------------------
    if sc != "no_log":
        add("messages.log", _messages_log(spec, meta, rng))

    # ---------- Tamper -----------------------------------------------------
    h = hashlib.md5()
    for _n, d in ents:
        h.update(d)
    digest = "".join("%X" % b for b in h.digest())
    if sc == "tamper_break":
        digest = "0" + digest[1:] if digest[0] != "0" else "1" + digest[1:]
    add("extensions/Tamper", digest)

    dtt = spec["zip_date"]
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in ents:
            z.writestr(zipfile.ZipInfo(n, date_time=dtt), d, compress_type=zipfile.ZIP_DEFLATED)
    return path


def _messages_log(spec, meta, rng):
    """One line per instrument event.  The grammar is strict: kind, one space,
    an epoch timestamp with at least nine digits and a fraction, then the rest."""
    sc = meta.get("scenario", "normal")
    t0 = spec["start_epoch"]
    cycles = spec["cycles"]
    serial = spec["serial"]
    name = spec["name"]
    zones = spec.get("zones", 6)
    spread = spec.get("zone_spread", 0.35)
    heat = spec.get("qs_heat", 3.4)
    cool = spec.get("qs_cool", 2.0)
    lines = []
    t = [t0]

    def ln(kind, dt, text):
        t[0] += dt
        lines.append("%s %.3f %s" % (kind, t[0], text))

    def temps(mean, tag="hold"):
        vs = [mean + rng.gauss(0, spread / 3.0) for _ in range(zones)]
        vs[0] = mean + spread / 2.0
        vs[-1] = mean - spread / 2.0
        return ",".join("%.1f" % v for v in vs)

    ln("Info", 0.02, "Instrument Version:    %s" % spec["firmware"])
    ln("Info", 0.01, "Messages.log Version:  1.1")
    ln("Info", 0.01, "Instrument Name:       %s" % spec["instrument_name"])
    ln("Info", 0.05, "Instrument Properties: -product=QuantStudio3_5 -serialNumber=%s "
                     "-hostname=synthetic -subsystems=TBC:Board1,Optics,LED "
                     "-version=%s -ready=True" % (serial, spec["firmware"]))
    ln("Info", 0.01, "Memory Properties:     3682300 kB")
    ln("Info", 0.05, "TBC Properties:        -hardwareVersion=1 -maxSampleVolume=100.0 "
                     "-minSampleVolume=1.0 -blockDescription=%d -bootcodeVersion=1 -blockID=18 "
                     "-lifeDegreesClimbed=%d -firmwareID=0 -lifeCycleCount=%d "
                     "-runModes=Direct,Fast,Standard -blockSerial=SYNBLK-%s -firmwareVersion=%s"
                     % (spec["rows"] * spec["cols"], spec["block_degrees"],
                        spec["block_cycles"], serial, spec["firmware"]))
    # command round trips -> cmd_rt
    for k in range(14):
        ln("Debug", 0.01, "C: %d TBC:PROP?" % (100 + k))
        ln("Debug", abs(rng.gauss(0.26, 0.09)) + spec.get("cmd_rt_extra", 0.0),
           "S: OK %d -hardwareVersion=1" % (100 + k))
    ln("Debug", 0.01, "C: ACCess CONTROLLER")
    ln("Debug", 0.07, "S: OK ACCess CONTROLLER")
    ln("Run", 0.10, 'Starting "%s"' % name)
    ln("Run", 0.05, "Setting sample volume to 20.0 microlitres")
    ln("Run", 0.20, "Stage PRERUN")
    ln("Debug", 0.10, "Cover Lowering")
    ln("Debug", spec.get("cover_down_s", 9.6), "Cover Lowered")

    # The temperature trace, logged at 1 Hz.  It has to be a real step response,
    # not a staircase: ccThermalSteps looks for plateaus of at least three
    # samples within 0.6 degC of a programmed setpoint, and measures overshoot
    # and settling against them.  A ramp that stops dead on the setpoint leaves
    # overshoot and settling with nothing to measure, which is what a first
    # attempt here produced.
    over = spec.get("qs_overshoot", 1.7)
    tau = 2.2
    hs = spec.get("heatsink", 33.0)

    def temp_line(T):
        ln("Temperature", 1.0, "-sample=%s -heatsink=%.1f -cover=105.2 -block=%s"
           % (temps(T), hs, temps(T)))

    def go(frm, to, hold, overshoot=0.0):
        T = frm
        rate = heat if to > frm else cool
        while abs(T - to) > 1e-9:
            T += math.copysign(min(abs(to - T), rate), to - T)
            temp_line(T if abs(T - to) > 1e-9 else T + overshoot)
        for k in range(hold):
            temp_line(to + overshoot * math.exp(-(k + 1) / tau) + rng.gauss(0, 0.04))

    go(25.0, 95.0, 14, over)            # pre-cycling denaturation hold

    predicted = 1800 + cycles * 70
    for c in range(1, cycles + 1):
        ln("Run", 0.20, "Cycle %d" % c)
        # 60 -> 95 -> 60 every cycle, so each cycle contributes one heating and
        # one cooling transition, one overshoot and one settling measurement
        # The hold has to outlast the overshoot decay: ccThermalSteps needs three
        # consecutive samples inside 0.6 degC of the setpoint, and the first few
        # samples after an overshoot of ~1.7 degC are still outside it.
        go(60.0 if c > 1 else 95.0, 95.0, 9, over)
        go(95.0, 60.0, 7)
        ln("LEDStatus", 0.05, "Temperature:%.4f Current:%.5f Voltage:3.00235 JuncTemp:%.4f"
           % (54.6 + rng.gauss(0, 0.3), spec.get("led_current", 9.29) + rng.gauss(0, 0.03),
              spec.get("led_junction", 69.4) + rng.gauss(0, 0.4)))
        for k, ch in enumerate(CHANNELS):
            x, mm = QS_FILTER[ch[5]].split("-")
            expo = spec.get("exposure", [15, 18, 22, 26])[k]
            ln("Info", 0.30, "Motor start %s %s" % (mm, x))
            ln("Info", abs(rng.gauss(spec.get("wheel_ms", 300) / 1000.0, 0.03)),
               "Motor end %s %s" % (mm, x))
            ln("Info", 0.01, "Emission Encoder %d 18000 Excitation Encoder %d 15750"
               % (3 + rng.randint(-1, 1), -2 + rng.randint(-1, 1)))
            ln("Info", 0.01, "Capture start %s %s" % (mm, x))
            ln("Debug", 0.01, "Start XML:IMAGe+ {'exposure': '%d', 'sampleTemperature': '%s'}"
               % (expo, temps(60.0 + spec.get("read_offset", 0.4))))
            ln("Debug", 0.04, "CAMera:ACQuire start exposure")
            ln("Debug", expo / 1000.0 + spec.get("cam_overhead_s", 0.42),
               "CAMera:ACQuire end exposure")
            ln("Image", 0.015, "-run='%s' -stage=2 -cycle=%d -step=2 -point=1  -emission=%s "
                               "-excitation=%s  -exposure=%d -lamp=90 -filepath='SYN:%s'"
               % (name, c, mm, x, expo, name))
            ln("Preprocessing", abs(rng.gauss(spec.get("img_proc_s", 0.5), 0.06)),
               "<quote.message>Input run configuration file: /synthetic/quant/2-%d-2-1-%s-%s.xml"
               % (c, mm, x))
            ln("Preprocessing", 0.08, "ROI Quantitation done in %.3f seconds"
               % abs(rng.gauss(spec.get("roi_s", 0.032), 0.004)))
        if sc == "sched_catchup" and c % 4 == 0:
            ln("Scheduler", 0.01, "Catching up")
        elif c % 12 == 0:
            ln("Scheduler", 0.01, "Catching up")
        if sc == "log_errors" and c % 7 == 0:
            ln("Error", 0.01, "Error in command: synthetic fault injection")
        # the one-second clock: the lateness of these ticks is tick_late
        for _ in range(spec.get("ticks_per_cycle", 6)):
            late = abs(rng.gauss(spec.get("tick_late_ms", 6), 4)) / 1000.0
            ln("Time", 1.0 + late, "-elapsed=%d -remaining=%d"
               % (int(t[0] - t0), max(0, predicted - int(t[0] - t0))))
    ln("Run", 0.10, 'Completed "%s"' % name)
    ln("Debug", 0.10, "Cover Raising")
    ln("Debug", spec.get("cover_up_s", 5.4), "Cover Raised")
    ln("Run", 0.10, 'Ended "%s"' % name)
    return "\n".join(lines) + "\n"
