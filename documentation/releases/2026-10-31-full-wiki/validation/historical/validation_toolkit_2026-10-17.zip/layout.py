"""Plate layout designer.

One source of truth for both writers, so an .ixo run and an .eds run of the
same scenario carry the same sample set, the same control materials and the
same replicate structure.

Everything here exists to satisfy a matching rule in the page's SC-06 profile.
The control names are not decorative: SOP-06 matches controls by regex on the
sample name, and a name that misses the regex becomes an ordinary sample, which
is how the previous attempt ended up with empty control charts.

  /^NTC$/i                      reaction blank          exactly "NTC"
  /^(BLANK|BLK)\s*EX/i          extraction blank
  /^(BLANK|BLK)\s*MAC/i         grinding / environment blank
  /^(CN|NC)\s+PORUMB\b/i        maize negative matrix control; positive on HMG
  /^(CN|NC)\s+SOIA\b/i          soy negative matrix control;  positive on LEC
  /^415B(?=\b|\d)/i             ERM-BF415b certified reference material
  /^410CP(?=\b|\d)/i            ERM-BF410cp certified reference material

The DD.MM.YYYY token in a control name is the extraction date.  It becomes the
chart's batch segment, so it must be a real calendar date with a four-digit
year and must not be later than the run.  Anything after the material name and
the date (DIL 1, DIL2) is the aliquot qualifier and starts a separate series.

Replicates are wells that share an IDENTICAL sample string.  Two wells named
"..._a" and "..._b" are two samples, not two replicates, and the SOP then
reports "1 replicate, SOP requires 2" for both.
"""
import math

T35S, TNOS, THMG, TLEC = "35S", "T-NOS", "HMG", "LEC"
TARGETS = [T35S, TNOS, THMG, TLEC]

# LightCycler channels, in the order the analyses reference them, and the
# QuantStudio dye that carries the same target.
CHANNELS = [
    # name,      ex,  em,  integration ms, target,  QS dye
    ("465-510", 465, 510, 240, T35S, "FAM"),
    ("533-580", 533, 580, 280, TNOS, "VIC"),
    ("533-610", 533, 610, 320, THMG, "ABY"),
    ("618-660", 618, 660, 360, TLEC, "JUN"),
]
PASSIVE_DYE = "MUSTANG PURPLE"          # QuantStudio passive reference

# Sample roles, in the vocabulary of each container.
IXO_TYPE = {"unknown": "qsUnknown", "standard": "qsStandard", "ntc": "qsNoTemplate",
            "negative": "qsNegative", "positive": "qsPositive", "calibrator": "qsPosCalibrator"}
EDS_TASK = {"unknown": "UNKNOWN", "standard": "STANDARD", "ntc": "NTC",
            "negative": "NEGATIVE_CONTROL", "positive": "POSITIVE_CONTROL", "calibrator": "POSITIVE_CONTROL"}


class Well:
    __slots__ = ("pos", "name", "role", "qty", "cq", "omit", "manual", "call", "flags",
                 "note", "crm", "orphan")

    def __init__(self, pos, name, role, cq, qty=None, omit=False, manual=False,
                 call=None, flags=(), note="", crm=False, orphan=False):
        self.pos = pos
        self.name = name
        self.role = role            # key of IXO_TYPE / EDS_TASK
        self.qty = qty              # standard quantity, or None
        self.cq = dict(cq)          # {target: Cq or None}; only these targets are analysed
        self.omit = omit
        self.manual = manual
        self.call = call            # force a stored call: 0 neg, 1 uncertain, 2 pos
        self.flags = tuple(flags)   # EDS flag codes, e.g. ("CC",) -> CQCONF
        self.note = note
        self.crm = crm
        self.orphan = orphan


def _jit(rng, x, s=0.12):
    return None if x is None else round(x + rng.gauss(0, s), 3)


def design(rng, rows, cols, run_index, extract_dates, scenario="normal", drift=None):
    """drift carries the slow method/operator phenomena the first set did not have.

        ntc_detect   probability that one reaction blank replicate amplifies
        ctrl_step    Cq added to every certified-material control (a lot change)
        ref_shift    Cq added to every taxon reference (inhibition creeping in)
        rep_spread   per-replicate Cq sigma, i.e. pipetting precision
        col_bias     (column index, Cq delta) — one channel of a multichannel tip
        amp_scale    is read by the writers, not here; it scales curve amplitude
    """ 
    """Return (wells, meta).  wells is a list of Well; meta carries the labels the
    writers need (standard targets, the orphan positions, the note text)."""
    d = drift or {}
    ntc_detect = float(d.get("ntc_detect", 0.0))
    ctrl_step = float(d.get("ctrl_step", 0.0))
    ref_shift = float(d.get("ref_shift", 0.0))
    rep_spread = float(d.get("rep_spread", 0.0))
    col_bias = d.get("col_bias") or (None, 0.0)
    npos = rows * cols
    scale = 4 if cols >= 24 else 1          # 384-well plate carries four times the samples
    W = []
    meta = {"std_targets": [T35S, TNOS], "orphans": [], "scenario": scenario}

    d_ex, d_mac, d_cn, d_415, d_415b, d_410 = extract_dates

    def put(pos, name, role, cq, **kw):
        W.append(Well(pos, name, role, cq, **kw))

    # ---- controls -----------------------------------------------------------
    # NTC: all four targets, nothing detected.  The contamination scenario puts
    # a late Cq into one replicate, which fails the control and, because it sits
    # within 3 cycles of the highest sample Cq, also trips the NTC-gap criterion.
    ntc_cq = {t: None for t in TARGETS}
    for k in range(3 * scale):
        c = dict(ntc_cq)
        if scenario == "ntc_contam" and k == 0:
            c[T35S] = _jit(rng, 33.4)
        elif ntc_detect and rng.random() < ntc_detect:
            # a contamination RATE rather than a single contaminated run: every
            # reaction blank is its own trial, so the p-chart has a denominator
            c[T35S] = _jit(rng, 34.2, 0.6)
        put(k, "NTC", "ntc", c)
    p = 3 * scale

    for k in range(2 * scale):
        put(p + k, "BLANK EX %s" % d_ex, "negative", ntc_cq)
    p += 2 * scale
    for k in range(2 * scale):
        put(p + k, "BLANK MAC %s" % d_mac, "negative", ntc_cq)
    p += 2 * scale

    # Negative matrix controls.  Negative on the GMO targets, positive on their
    # own taxon reference — the page treats the reference row of these wells as
    # a positive control with purpose "reference amplification", Cq window 20-27.
    for k in range(2 * scale):
        put(p + k, "CN PORUMB %s" % d_cn, "negative",
            {T35S: None, TNOS: None, THMG: _jit(rng, 23.1 + ref_shift)})
    p += 2 * scale
    for k in range(2 * scale):
        put(p + k, "CN SOIA %s" % d_cn, "negative",
            {T35S: None, TNOS: None, TLEC: _jit(rng, 23.4 + ref_shift)})
    p += 2 * scale

    # Certified reference materials.  Windows: 29-36 on the GMO targets,
    # 20-27 on the taxon reference.  Two extracts of 415b on one plate, so the
    # second becomes "additional extract 1" and segments its own chart.
    pc_shift = 1.9 if scenario == "pc_drift" else 0.0
    for k in range(2 * scale):
        put(p + k, "415B %s" % d_415, "calibrator",
            {T35S: _jit(rng, 31.6 + pc_shift + ctrl_step),
             TNOS: _jit(rng, 32.1 + pc_shift + ctrl_step),
             THMG: _jit(rng, 23.8 + ref_shift)}, crm=True)
    p += 2 * scale
    for k in range(2 * scale):
        put(p + k, "415B %s DIL 1" % d_415b, "calibrator",
            {T35S: _jit(rng, 34.5 + ctrl_step), TNOS: _jit(rng, 34.9 + ctrl_step),
             THMG: _jit(rng, 26.2 + ref_shift)}, crm=True)
    p += 2 * scale
    for k in range(2 * scale):
        put(p + k, "410CP %s" % d_410, "calibrator",
            {T35S: _jit(rng, 30.8 + ctrl_step), TNOS: _jit(rng, 31.2 + ctrl_step),
             TLEC: _jit(rng, 23.6 + ref_shift)}, crm=True)
    p += 2 * scale

    # ---- standards ----------------------------------------------------------
    # Six ten-fold levels, so the log range is 5 and clears minLogs = 3.
    # slope -3.32 is 100 % efficiency; the eff_bad scenario uses -3.00 (~115 %).
    # The efficiency chart re-fits the standards from their own Cq values, so a
    # drifting efficiency has to be in the SPACING of the standard levels here —
    # writing a different slope into the stored curve object alone changes
    # nothing, which is what a first attempt did.
    slope = float(d.get("std_slope", 3.00 if scenario == "eff_bad" else 3.32))
    for lv in range(6):
        qty = 10.0 ** (5 - lv)
        for k in range(2):
            put(p, "STD %d" % (lv + 1), "standard",
                {T35S: _jit(rng, 18.4 + slope * lv, 0.06),
                 TNOS: _jit(rng, 19.1 + slope * lv, 0.06)}, qty=qty)
            p += 1

    # ---- samples ------------------------------------------------------------
    # Pairs of identical names, alternating maize and soy.  Each sample carries
    # its own taxon reference only: a maize sample has HMG, a soy sample LEC.
    # Positions that are in no analysis for a channel keep a flat curve, so they
    # are not mistaken for orphans.
    n_pairs = (npos - p - 2 * scale) // 2
    for i in range(n_pairs):
        soy = i % 2 == 1
        name = "SYNTH %s %04d" % ("SOY" if soy else "MZE", 1000 + run_index * 97 + i)
        ref = TLEC if soy else THMG
        gmo = (i % 3 == 0)                      # a third of the samples are positive
        cq35 = _jit(rng, 30.2 + (i % 5) * 0.4) if gmo else None
        cqnos = _jit(rng, 30.9 + (i % 5) * 0.4) if gmo else None
        cqref = _jit(rng, 22.4 + (i % 7) * 0.25 + ref_shift)
        spread, omit, manual, call, flags = 0.0, False, False, None, ()

        if scenario == "sd_fail" and i == 0:
            spread = 1.45                        # |a-b|/sqrt(2) = 1.03 > 0.5 -> Repeat
        if scenario == "late_signal" and i in (0, 2):
            cq35, cqnos = _jit(rng, 38.6), _jit(rng, 38.9)   # above cqLate 38 -> Repeat
        if scenario == "late_ref" and i == 0:
            cqref = _jit(rng, 36.8)              # reference cqLate 36 -> Inconclusive
        if scenario == "ref_missing" and i == 1:
            # The sample must be GMO-negative for this to reach the sample outcome.
            # On a GMO-positive sample the 35S row is Positive and the reference
            # failure only shows in the reference rows, which sopSampleRows keeps
            # out of sample_outcome — so the run looked clean.  i == 1 is soy and
            # not GMO-positive, so its 35S row becomes Invalid: "reference not
            # detected — a negative cannot be reported".
            cqref = None
        if scenario == "partial" and i == 3:
            # Likewise: a partial detection only becomes Repeat where there is
            # something to detect, so this must land on a GMO-positive sample
            # (i % 3 == 0).  On a negative sample both replicates are negative
            # and the outcome is simply Negative.
            spread = None                        # one replicate detected, one not
        if scenario == "call_disagree" and i == 6:
            # Exactly 40.0, which is both the SOP cqMax and the QuantStudio cycle
            # count: the LightCycler path flags a stored Positive at exactly the
            # cut-off, and the QuantStudio path treats Ct >= cycles as undetermined
            # while the stored call still says Positive.  One value, both platforms.
            cq35, call = 40.0, 2
        if scenario == "omitted" and i in (1, 3):
            omit = True                          # one replicate of a pair
        if scenario == "manual" and i in (2, 5):
            # CC becomes CQCONF on the QuantStudio side and feeds low_conf; the
            # stored call is set to Uncertain so that the LightCycler side raises
            # the same "uncertain call" review finding.  Without it a manual
            # setting left no trace at all in an .ixo.
            manual, flags, call = True, ("CC",), 1
        if scenario == "undetermined" and i == 1:
            cq35, cqnos, cqref = None, None, None

        for k in range(2):
            c = {T35S: cq35, TNOS: cqnos, ref: cqref}
            # pipetting precision: each replicate gets its own Cq, which is what
            # B-O1 rep_sd and the replicate acceptance rule actually measure
            if rep_spread:
                c = {t: (None if v is None else round(v + rng.gauss(0, rep_spread), 3))
                     for t, v in c.items()}
            # one channel of a multichannel tip delivering short: every well of
            # one plate column reads late, which is what B-O3 rowcol looks for
            if col_bias[0] is not None and (p % cols) == col_bias[0]:
                c = {t: (None if v is None else round(v + col_bias[1], 3))
                     for t, v in c.items()}
            if spread:
                c = {t: (None if v is None else round(v + (spread / 2 if k else -spread / 2), 3))
                     for t, v in c.items()}
            if spread is None and k == 1:
                c = {t: None for t in c}
            # i == 1 loses both replicates, which is the only route to the
            # "Not interpreted" outcome: a group with no usable well at all.
            drop_both = scenario == "omitted" and i == 1
            W.append(Well(p, name, "unknown", c, omit=omit and (drop_both or k == 0),
                          manual=manual and k == 0, call=call if k == 0 else None,
                          flags=flags if k == 0 else ()))
            p += 1

    # ---- deliberately unanalysed signal ------------------------------------
    # A position with a rising curve that no analysis claims.  This is what the
    # "signal in wells that are not in any analysis" graph and the rising-curve
    # review view are for.  Named, so the page classes it as contamination.
    if scenario == "orphan":
        for k in range(2 * scale):
            if p + k < npos:
                meta["orphans"].append((p + k, 0, _jit(rng, 29.5)))
                # orphan=True keeps the well out of the result rows but still gives
                # it a detector task, so the page can resolve the curve's channel.
                # Without the task the reporter is unknown, the channel comes out NaN
                # and the curve never reaches allCurves — which is why an earlier
                # version produced no QuantStudio orphans at all.
                W.append(Well(p + k, "SYNTH ORPHAN %04d" % (k + 1), "unknown", {}, orphan=True))
    return W, meta


def named_positions(wells):
    return {w.pos for w in wells}


def analysis_positions(wells, target):
    """Positions whose well is analysed for this target, in plate order."""
    return [w.pos for w in sorted(wells, key=lambda x: x.pos) if target in w.cq]
