/* Tests for the advisory PANEL. Revision 3, after the second review.
   Run: node test_panel.js

   The panel is a script, not a module, so it is loaded into a vm context with
   stubs for the page functions it reads -- the same approach the reviewer used.
   svgPlot is replaced by a recorder, which is what lets the geometry of a
   figure be asserted rather than merely its presence. Figure geometry in the
   real renderer is checked separately, in the browser probe.                 */
const fs=require('fs'),vm=require('vm'),path=require('path');
const engine=require('./ml_advisory.js');

let fail=0,n=0;
const ok=(c,msg)=>{n++;if(!c)fail++;console.log((c?'PASS  ':'FAIL  ')+msg);};

function makeContext(){
  const FIGS=[];
  const ctx=Object.assign({},engine,{
    console,FIGS,
    PLOT_CAPTURE:null,SVG_CLIP_N:0,
    CC_COL:{ok:"#16a34a",warn:"#d97706",bad:"#dc2626",none:"#94a3b8",pt:"#2563eb",line:"#64748b",rule:"#f59e0b"},
    CC_SEG_PALETTE:["#2563eb","#7c3aed","#0891b2","#16a34a"],
    CC_STATE:{instrument:"LC · A",protocol:"",variant:""},
    SOP:{name:"SOP-T",version:"1",locked:false},
    SOP_HASH:"hash-1",
    svgPlot:o=>{FIGS.push(o);return '<svg width="1" height="1"></svg>';},
    svgMessage:()=>'<svg></svg>',
    esc:v=>String(v==null?"":v).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])),
    ui:v=>String(v==null?"":v),
    table:(cols,rows)=>'<table>'+rows.map(r=>'<tr>'+cols.map(c=>'<td>'+(r[c.key]==null?'':r[c.key])+'</td>').join('')+'</tr>').join('')+'</table>',
    fmtTick:v=>String(+Number(v).toPrecision(6)),
    extent:(vals,pad)=>{const v=vals.filter(Number.isFinite);if(!v.length)return [0,1];
      const lo=Math.min(...v),hi=Math.max(...v),p=(hi-lo||Math.abs(hi)||1)*(pad==null?0.05:pad);
      return [lo-p,hi+p];},
    uniq:a=>[...new Set(a)],
    sopFmtTime:ms=>new Date(ms).toISOString().replace("T"," ").slice(0,19),
    localizeDOM:()=>{},
    document:{querySelectorAll:()=>[],querySelector:()=>null},
  });
  ctx.sopHash=()=>ctx.SOP_HASH;
  ctx.ROWS=[];
  ctx.ccAllRows=()=>ctx.ROWS;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname,'ml_panel.js'),'utf8'),ctx);
  return ctx;
}
const run=(ctx,code)=>vm.runInContext(`(()=>{${code}})()`,ctx);

/* a history row in the shape ccRowsFromRuns produces */
const mkRow=(i,over)=>Object.assign({
  key:"K"+i,run:"R"+i,date:Date.UTC(2026,0,1)+i*864e5,instrument:"LC · A",platform:"LC",
  protocol:"",firmware:"1.0",software:"2.0",operator:"op",
  m:{a:i,b:Math.sin(i),c:i*i,findings:{count:i%2},copied:{count:0}}},over||{});

/* ---------------- the reviewer's label-only cache reproduction ---------------- */
{
  const ctx=makeContext();
  ctx.ROWS=Array.from({length:20},(_,i)=>mkRow(i));
  const r=run(ctx,`
    const c={rows:ROWS,instrument:"LC · A",protocol:"",baseFrom:""};
    const a=mlMultivariate(c,"whole cohort");
    const flipped=ROWS.map(x=>({...x,m:{...x.m,findings:{count:1-x.m.findings.count}}}));
    const b=mlMultivariate({...c,rows:flipped},"whole cohort");
    return {sameObject:a===b,sameKey:a.key===b.key,
      firstLabelA:a.label[0],firstLabelB:b.label[0],
      expectedB:flipped[0].m.findings.count>0?1:0};`);
  ok(r.sameObject===false,'R2-1 a label-only change returns a fresh result, not the cached one');
  ok(r.sameKey===false,'R2-1 and the dependency key differs');
  ok(r.firstLabelB===r.expectedB,
     `R2-1 the label vector matches the current input (got ${r.firstLabelB}, expected ${r.expectedB})`);
  ok(r.firstLabelA!==r.firstLabelB,'R2-1 the two label vectors are genuinely different');
}
{
  /* the cache must still work, and must break on every other dependency */
  const ctx=makeContext();
  ctx.ROWS=Array.from({length:20},(_,i)=>mkRow(i));
  const r=run(ctx,`
    const c=()=>({rows:ROWS,instrument:"LC · A",protocol:"",baseFrom:""});
    const a=mlMultivariate(c(),"whole cohort");
    const hit=mlMultivariate(c(),"whole cohort")===a;
    const scope=mlMultivariate(c(),"all extracts")===a;
    const fw=(()=>{const rows=ROWS.map((x,i)=>i===3?{...x,firmware:"9.9"}:x);
      return mlMultivariate({...c(),rows},"whole cohort")===a;})();
    const nm=(()=>{const rows=ROWS.map((x,i)=>i===3?{...x,run:"RENAMED"}:x);
      return mlMultivariate({...c(),rows},"whole cohort")===a;})();
    const val=(()=>{const rows=ROWS.map((x,i)=>i===3?{...x,m:{...x.m,a:x.m.a+100}}:x);
      return mlMultivariate({...c(),rows},"whole cohort")===a;})();
    const cp=(()=>{const rows=ROWS.map((x,i)=>i===3?{...x,m:{...x.m,copied:{count:7}}}:x);
      return mlMultivariate({...c(),rows},"whole cohort")===a;})();
    mlMultivariate(c(),"whole cohort");
    SOP_HASH="hash-2";
    const sop=mlMultivariate(c(),"whole cohort")===a;
    return {hit,scope,fw,nm,val,cp,sop};`);
  ok(r.hit===true,'BEH  identical inputs do hit the cache');
  ok(r.scope===false,'R2-5 a change of multivariate scope breaks the cache');
  ok(r.fw===false,'R2-1 a firmware change breaks it (the tables print firmware)');
  ok(r.nm===false,'R2-1 a run rename breaks it (the tables print run names)');
  ok(r.val===false,'R2-1 a feature value change breaks it');
  ok(r.cp===false,'R2-1 a copied-count change breaks it');
  ok(r.sop===false,'R2-1 an SOP profile change breaks it');
}
{
  const ctx=makeContext();
  ctx.ROWS=Array.from({length:20},(_,i)=>mkRow(i));
  const r=run(ctx,`
    const c={rows:ROWS,instrument:"LC · A",protocol:"",baseFrom:""};
    const a=mlMultivariate(c,"whole cohort");
    return {keyIsString:typeof a.key==="string",keyLong:a.key.length>200,
      digest:a.fingerprint,digestShort:a.fingerprint.length===8};`);
  ok(r.keyIsString&&r.keyLong,'R2-1 the cache compares a full serialised key ('+'length > 200'+'), not a digest');
  ok(r.digestShort,'BEH  the 8-character digest is kept for display only ('+r.digest+')');
}

/* ---------------- the third review's holdout-schema cache reproduction ----------
   A metric can clear the 80 % presence rule inside the training window while
   failing it over the whole cohort. It is then absent from the full-cohort
   matrix and present in the training-only matrix the out-of-time model is
   fitted on, so revision 3's key -- which enumerated the derived full-cohort
   artefacts -- never saw its values.                                        */
{
  const ctx=makeContext();
  /* 40 rows: a, b, c always present; d on 23 of the first 28 and 4 of the last 12.
     Full cohort 27/40 = 67.5 %, below the rule. Training 23/28 = 82 %, above it. */
  const mkD=i=>{
    const inTrain=i<28;
    const has=inTrain?(i%7!==3||i>=25):(i%3===0);
    return has?{d:0.5+i*0.01}:{};
  };
  ctx.ROWS=Array.from({length:40},(_,i)=>mkRow(i,{
    m:Object.assign({a:i,b:Math.sin(i),c:i*i,findings:{count:i%2},copied:{count:0}},mkD(i))}));
  const r=run(ctx,`
    const c=rows=>({rows,instrument:"LC · A",protocol:"",baseFrom:""});
    const A=mlMultivariate(c(ROWS),"whole cohort");
    const bumped=ROWS.map(x=>("d" in x.m)?{...x,m:{...x.m,d:x.m.d+100}}:x);
    const B=mlMultivariate(c(bumped),"whole cohort");
    ML_STATE.mv=null;
    const fresh=mlMultivariate(c(bumped),"whole cohort");
    const trainD=o=>{if(!o.holdout)return null;
      const j=o.holdout.keys.indexOf("d");return j<0?null:o.holdout.Xtr[0][j];};
    return {fullKeys:A.F.keys,trainingKeys:A.holdout?A.holdout.keys:null,
      dInCohortSchema:A.F.keys.indexOf("d")>=0,
      dInTrainingSchema:!!A.holdout&&A.holdout.keys.indexOf("d")>=0,
      dCoverage:ROWS.filter(x=>"d" in x.m).length,
      reusedCache:A===B,keyUnchanged:A.key===B.key,
      cachedTrainingD:trainD(B),freshTrainingD:trainD(fresh),
      bumpedEqualsFresh:B.key===fresh.key};`);
  ok(r.dInCohortSchema===false,
     `R3-1 the probe metric is excluded from the cohort schema (present on ${r.dCoverage} of 40 runs)`);
  ok(r.dInTrainingSchema===true,
     'R3-1 and included in the training-only schema, which is the case that escaped the key');
  ok(r.reusedCache===false,'R3-1 changing only that metric does NOT return the cached object');
  ok(r.keyUnchanged===false,'R3-1 and the dependency key changes');
  ok(r.cachedTrainingD!==null&&r.cachedTrainingD===r.freshTrainingD,
     `R3-1 the training matrix carries the current values (got ${r.cachedTrainingD}, fresh ${r.freshTrainingD})`);
  ok(Math.abs(r.cachedTrainingD-100.5)<1e-9,
     `R3-1 specifically 100.5 after adding 100, not the stale 0.5 (got ${r.cachedTrainingD})`);
  ok(r.bumpedEqualsFresh===true,'R3-1 computing the same input twice is still deterministic');
}
{
  /* the key is built from the INPUTS, so a metric no schema reads at all still
     changes it -- the property that closes this class of defect rather than
     patching one instance of it */
  const ctx=makeContext();
  ctx.ROWS=Array.from({length:20},(_,i)=>mkRow(i,{
    m:{a:i,b:Math.sin(i),c:i*i,rare:(i===0?1:undefined),
       findings:{count:i%2},copied:{count:0}}}));
  const r=run(ctx,`
    const c=rows=>({rows,instrument:"LC · A",protocol:"",baseFrom:""});
    const A=mlMultivariate(c(ROWS),"whole cohort");
    const inAnySchema=A.F.keys.indexOf("rare")>=0||(A.holdout&&A.holdout.keys.indexOf("rare")>=0);
    const changed=ROWS.map((x,i)=>i===0?{...x,m:{...x.m,rare:999}}:x);
    const B=mlMultivariate(c(changed),"whole cohort");
    /* and a metric key order change must NOT break it: the serialisation is canonical */
    const reordered=ROWS.map(x=>({...x,m:Object.fromEntries(Object.entries(x.m).reverse())}));
    const C=mlMultivariate(c(reordered),"whole cohort");
    return {inAnySchema:!!inAnySchema,changedKey:A.key!==B.key,reorderSame:A.key===C.key};`);
  ok(r.inAnySchema===false,'R3-1 the probe metric is read by no schema at all');
  ok(r.changedKey===true,'R3-1 yet changing its value still changes the key (inputs are the boundary)');
  ok(r.reorderSame===true,'R3-1 while reordering the metric object does not, since the serialisation is canonical');
}

/* ---------------- the reviewer's limit reproductions ---------------- */
const mkPts=(n,over)=>Array.from({length:n},(_,i)=>Object.assign({
  row:mkRow(i),x:i+1,y:1+0.01*i,raw:1+0.01*i,pre:false,flags:[]},over?over(i):{}));
{
  const ctx=makeContext();
  ctx.PTS=mkPts(10);
  const r=run(ctx,`
    const noLimits=mlSeries({type:"i",pts:PTS,def:{},baselineReady:true});
    const withLimits=mlSeries({type:"i",def:{},baselineReady:true,
      pts:PTS.map(p=>({...p,ucl:2,lcl:0}))});
    const upperOnly=mlSeries({type:"i",def:{},baselineReady:true,
      pts:PTS.map(p=>({...p,ucl:2}))});
    const notReady=mlSeries({type:"i",def:{},baselineReady:false,
      pts:PTS.map(p=>({...p,ucl:2,lcl:0}))});
    const partial=mlSeries({type:"i",def:{},baselineReady:true,
      pts:PTS.map((p,i)=>i<5?{...p,ucl:2,lcl:0}:{...p})});
    const constP=mlSeries({type:"p",def:{},baselineReady:true,
      pts:PTS.map(p=>({...p,ucl:100,lcl:0}))});
    const varyingP=mlSeries({type:"p",def:{},baselineReady:true,
      pts:PTS.map((p,i)=>({...p,ucl:1+i*0.1,lcl:0}))});
    const ewma=mlSeries({type:"ewma",def:{},baselineReady:true,
      pts:PTS.map(p=>({...p,y:p.y*0.3,ucl:2,lcl:0}))});
    const cusum=mlSeries({type:"cusum",def:{},baselineReady:true,
      pts:PTS.map(p=>({...p,y:1,ucl:5,lcl:-5}))});
    const funnel=mlSeries({type:"funnel",pts:[],def:{}});
    return {noLimits:noLimits.limitsApply,noWhy:noLimits.limitWhy,
      withLimits:withLimits.limitsApply,
      upperOnly:upperOnly.limitsApply,upperOneSided:upperOnly.oneSided,
      notReady:notReady.limitsApply,partial:partial.limitsApply,
      constP:constP.limitsApply,constWhy:constP.limitWhy,varyingP:varyingP.limitsApply,
      ewma:ewma.limitsApply,cusum:cusum.limitsApply,funnel:funnel.funnel};`);
  ok(r.noLimits===false,'R2-3 a chart with NO limits does not get a crossing assessment');
  ok(/no control limits/.test(r.noWhy),'R2-3 and the reason names the missing limits');
  ok(r.withLimits===true,'BEH  a chart with established constant limits still does');
  ok(r.upperOnly===true&&r.upperOneSided===true,'R2-3 a genuine one-sided limit is assessed and flagged as one-sided');
  ok(r.notReady===false,'R2-3 a chart whose own baseline is not established is not assessed');
  ok(r.partial===false,'R2-3 limits present on only some runs do not count as established');
  ok(r.constP===false,'R2-3 a p-chart is suppressed by type even when its limits have been constant');
  ok(/future denominator/.test(r.constWhy),'R2-3 and the reason says historical constancy is not a future denominator');
  ok(r.varyingP===false,'BEH  a p-chart with varying limits is also suppressed');
  ok(r.ewma===false&&r.cusum===false,'BEH  EWMA and CUSUM remain suppressed');
  ok(r.funnel===true,'R2-5 a funnel chart is marked as declined');
}

/* ---------------- the whole layer is declined for a funnel ---------------- */
{
  const ctx=makeContext();
  ctx.ROWS=Array.from({length:20},(_,i)=>mkRow(i));
  const r=run(ctx,`
    const res={type:"funnel",pts:[{operator:"a",n:10,y:0.1,flags:[]},{operator:"b",n:12,y:0.2,flags:[]}],
      def:{code:"F1",title:"funnel",unit:"%",id:"ntc_rate"},X:{label:"n"},cfg:{},spec:{}};
    const h=mlAdvisoryHtml(res);
    const tok=(h.match(/data-ml="(ml[0-9]+)"/)||[])[1];
    const body=mlAdvisoryBody(tok);
    return {len:body.length,declined:/not offered for it/.test(body),
      hasMulti:/Hotelling|instrument as a whole/.test(body),
      hasClusters:/Behaviour groups/.test(body),hasDrivers:/flagged run/.test(body),
      figures:FIGS.length};`);
  ok(r.declined===true,'R2-5 the funnel panel says the layer is not offered');
  ok(r.hasMulti===false&&r.hasClusters===false&&r.hasDrivers===false,
     'R2-5 and it does NOT continue into the multivariate, clustering or driver panels');
  ok(r.figures===0,'R2-5 no figure is drawn for a funnel chart');
}

/* ---------------- the coefficient figure's geometry ---------------- */
{
  const ctx=makeContext();
  /* a cohort with enough flagged runs in both halves to clear the event floor */
  ctx.ROWS=Array.from({length:60},(_,i)=>mkRow(i,{
    m:{a:i%7,b:(i*13)%11,c:(i*5)%9,findings:{count:(i%3===0)?1:0},copied:{count:0}}}));
  const r=run(ctx,`
    const c={rows:ROWS,instrument:"LC · A",protocol:"",baseFrom:""};
    const mv=mlMultivariate(c,"whole cohort");
    FIGS.length=0;
    const html=mlPanelDrivers(mv);
    const bars=FIGS.filter(f=>(f.series||[]).some(s=>s.type==="bar"));
    const fig=FIGS[FIGS.length-1]||{};
    const lines=(fig.series||[]).filter(s=>s.type==="line");
    const rows=lines.map(s=>({from:s.data[0],to:s.data[1]}));
    return {shown:/Weight/.test(html),figs:FIGS.length,
      barSeries:bars.length,
      lineSeries:lines.length,
      startAtZero:rows.every(q=>q.from[0]===0),
      sameRow:rows.every(q=>q.from[1]===q.to[1]),
      distinctRows:new Set(rows.map(q=>q.from[1])).size,
      endsAtWeights:rows.map(q=>q.to[0]),
      weights:mv.logit?mv.logit.w.slice().sort((a,b)=>Math.abs(b)-Math.abs(a)).slice(0,10):[],
      xSpan:fig.x,enough:mv.logit?mv.logit.enoughEvents:null};`);
  ok(r.enough===true,'BEH  the probe cohort clears the event floor so the figure is drawn');
  ok(r.barSeries===0,'R2-2 no vertical-bar series is used for the coefficients');
  ok(r.lineSeries>=3,'R2-2 each coefficient is a line segment ('+r.lineSeries+' of them)');
  ok(r.startAtZero===true,'R2-2 every segment starts at zero on the weight axis');
  ok(r.sameRow===true,'R2-2 every segment stays on its own metric row');
  ok(r.distinctRows===r.lineSeries,'R2-2 one row per metric, none overlapping');
  {
    const want=r.weights.map(v=>+v.toPrecision(12)).sort((a,b)=>a-b);
    const got=r.endsAtWeights.map(v=>+v.toPrecision(12)).sort((a,b)=>a-b);
    ok(JSON.stringify(want)===JSON.stringify(got),
       'R2-2 segment END values are the coefficients themselves, not ranks');
  }
  ok(r.xSpan[0]<=Math.min(...r.endsAtWeights)&&r.xSpan[1]>=Math.max(...r.endsAtWeights),
     'R2-2 the weight axis spans the coefficients, negatives included');
}

/* ---------------- captured context, not live globals ---------------- */
{
  const ctx=makeContext();
  ctx.ROWS=Array.from({length:24},(_,i)=>mkRow(i,{instrument:i<12?"LC · A":"LC · B"}));
  const r=run(ctx,`
    const res={type:"i",def:{code:"C1",title:"t",unit:"u",id:"a"},X:{label:"Run"},cfg:{},spec:{},
      baselineReady:true,pts:ROWS.filter(x=>x.instrument==="LC · A").map((x,i)=>
        ({row:x,x:i+1,y:1+0.01*i,raw:1+0.01*i,pre:false,flags:[],ucl:2,lcl:0}))};
    const h=mlAdvisoryHtml(res);
    const tok=(h.match(/data-ml="(ml[0-9]+)"/)||[])[1];
    CC_STATE.instrument="LC · B";          /* the user switches instrument */
    CC_STATE.protocol="something else";
    const body=mlAdvisoryBody(tok);
    return {usedA:/LC · A/.test(body),usedB:/LC · B/.test(body),
      proto:/something else/.test(body)};`);
  ok(r.usedA===true&&r.usedB===false,
     'R2-5 the panel is computed for the instrument captured when it was created');
  ok(r.proto===false,'R2-5 and for the protocol filter captured then, not the current one');
}

/* ---------------- the two populations are labelled ---------------- */
{
  const ctx=makeContext();
  ctx.ROWS=Array.from({length:30},(_,i)=>mkRow(i));
  const r=run(ctx,`
    const pts=ROWS.map((x,i)=>({row:x,x:i+1,y:1+0.01*i,raw:1+0.01*i,pre:false,flags:[],
      ucl:2,lcl:0,segment:i<15?"extract 1":"extract 2"}));
    const res={type:"i",def:{code:"C1",title:"t",unit:"u",id:"a"},X:{label:"Run"},cfg:{},spec:{},
      baselineReady:true,segmented:true,pts,
      segments:[{key:"extract 1",n:15,ready:true},{key:"extract 2",n:15,ready:true,last:true}]};
    const h=mlAdvisoryHtml(res);
    const tok=(h.match(/data-ml="(ml[0-9]+)"/)||[])[1];
    const body=mlAdvisoryBody(tok);
    return {saysExtract:/Control material charted in the three panels below/.test(body),
      warnsSwitch:/computed over ALL/.test(body),
      scope:/multivariate scope: all extracts/.test(body)};`);
  ok(r.saysExtract===true,'BEH  the univariate panels name the extract they use');
  ok(r.warnsSwitch===true,'R2-5 the panel states that the later panels use a different population');
  ok(r.scope===true,'R2-5 and the scope is recorded in the footer and the cache key');
}

console.log('\n'+(n-fail)+' of '+n+' panel checks passed'+(fail?' — '+fail+' FAILED':''));
process.exit(fail?1:0);
