#!/usr/bin/env python3
"""Carve a labelled subset out of a generated set, with its own manifest.

    python3 make_subset.py SET_DIR OUT_DIR [--per-cohort 8]

Export completeness has to be tested on a set small enough that the "everything
as one ZIP" item is not several gigabytes, but it must still be a recorded
subset of the real input set rather than a different set generated separately —
which is the confusion an outside review rightly objected to. This copies the
first N runs of every cohort and filters MANIFEST.tsv and EXPECTED.tsv to match,
so the subset carries its own manifest and its own slice of the assertion matrix.
"""
import argparse, hashlib, os, shutil, sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("setdir")
    ap.add_argument("outdir")
    ap.add_argument("--per-cohort", type=int, default=8)
    a = ap.parse_args()
    man = os.path.join(a.setdir, "MANIFEST.tsv")
    if not os.path.exists(man):
        sys.exit("no MANIFEST.tsv in %s" % a.setdir)
    os.makedirs(a.outdir, exist_ok=True)

    head, *rows = open(man).read().splitlines()
    seen, keep = {}, []
    for r in rows:
        f = r.split("\t")
        coh = f[0]
        if seen.get(coh, 0) >= a.per_cohort:
            continue
        seen[coh] = seen.get(coh, 0) + 1
        keep.append(f)
    names = {f[2] for f in keep}

    for f in keep:
        shutil.copy2(os.path.join(a.setdir, f[1]), os.path.join(a.outdir, f[1]))
    with open(os.path.join(a.outdir, "MANIFEST.tsv"), "w") as out:
        out.write(head + "\n")
        for f in keep:
            out.write("\t".join(f) + "\n")
    ep = os.path.join(a.setdir, "EXPECTED.tsv")
    if os.path.exists(ep):
        ehead, *erows = open(ep).read().splitlines()
        with open(os.path.join(a.outdir, "EXPECTED.tsv"), "w") as out:
            out.write(ehead + "\n")
            n = 0
            for r in erows:
                if r.split("\t")[0] in names:
                    out.write(r + "\n")
                    n += 1
    sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
    print("subset: %d runs (%s)" % (len(keep), ", ".join("%s=%d" % kv for kv in sorted(seen.items()))))
    print("  source manifest sha256 %s" % sha(man))
    print("  subset manifest sha256 %s" % sha(os.path.join(a.outdir, "MANIFEST.tsv")))
    print("  expectations kept      %d" % n)
    tot = sum(os.path.getsize(os.path.join(a.outdir, x)) for x in os.listdir(a.outdir))
    print("  %.1f MiB -> %s" % (tot / 1048576, a.outdir))


if __name__ == "__main__":
    main()
