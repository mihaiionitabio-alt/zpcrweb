#!/usr/bin/env python3
"""Check that each slow phenomenon in the DRIFT cohorts reaches its chart.

    python3 verify_drift.py INDEX_HTML DRIFT_DIR

Per-run assertions cannot see a trend, so this reads the control-chart series the
page computes and compares the first quarter of the cohort with the last, or the
runs before a lot change with the runs after, and reports the measured change.
"""
import glob, json, os, statistics as st, sys
from playwright.sync_api import sync_playwright

idx, setdir = sys.argv[1], sys.argv[2]
files = sorted(glob.glob(os.path.join(setdir, "*.ixo")) + glob.glob(os.path.join(setdir, "*.eds")))

PROBE = r"""
() => {
  const out = {instruments: [], series: {}};
  ccInstruments().forEach(inst => {
    const rows = ccRowsFor(inst.key);
    out.instruments.push({key: inst.key, platform: inst.platform, n: rows.length});
    const grab = (id, variant) => {
      const def = CC_BY_ID[id]; if (!def) return null;
      const res = ccCompute(def, rows, variant === undefined ? null : variant);
      const st = ccStatus(res);
      return {pts: (res.pts || []).filter(p => Number.isFinite(p.y)).map(p => p.y),
              level: st.level, text: st.text, baseline: !!res.baselineReady};
    };
    const vlist = id => { const def = CC_BY_ID[id];
      return def && def.variants ? ccVariants(def, rows) : [null]; };
    ['pc_amplitude', 'pc_cq', 'efficiency', 'ntc_rate', 'rep_sd', 'rowcol',
     'manual_rate', 'late_rate', 'ntc_op', 'action_op', 'rox_level', 'ic_shift'
    ].forEach(id => {
      vlist(id).forEach(v => {
        const g = grab(id, v);
        if (g) out.series[inst.key + ' | ' + id + ' | ' + (v === null ? '-' : v)] = g;
      });
    });
    // operator split for the by-operator charts
    out.series[inst.key + ' | operators'] = {ops: [...new Set(rows.map(r => r.operator))]};
  });
  return out;
}
"""

with sync_playwright() as pw:
    b = pw.chromium.launch(args=["--js-flags=--max-old-space-size=8192"])
    pg = b.new_page()
    errs = []
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    pg.goto("file://" + os.path.abspath(idx))
    pg.wait_for_function("typeof RUNS !== 'undefined'")
    pg.evaluate("() => showTab('sop')"); pg.wait_for_timeout(300)
    pg.select_option("#sop-preset", "demo"); pg.click("#sop-apply-preset"); pg.wait_for_timeout(600)
    pg.evaluate("() => showTab('load')"); pg.wait_for_timeout(200)
    pg.set_input_files("#file", files); pg.click("#read")
    pg.wait_for_function("RUNS.length >= %d" % len(files), timeout=1800000)
    res = pg.evaluate(PROBE)
    b.close()

def trend(v, frac=0.25):
    k = max(2, int(len(v) * frac))
    return st.mean(v[:k]), st.mean(v[-k:])

def step(v):
    h = len(v) // 2
    return st.mean(v[:h]), st.mean(v[h:])

print("instruments:", ", ".join("%s (%s, %d runs)" % (i["key"], i["platform"], i["n"])
                                for i in res["instruments"]))
print("console errors:", len(errs))
print()
hdr = "%-46s %9s %9s %9s  %s"
print(hdr % ("series", "first", "last", "change", "status"))
checks = []
for key in sorted(res["series"]):
    s = res["series"][key]
    if "pts" not in s or len(s["pts"]) < 8:
        continue
    a, b2 = trend(s["pts"])
    print(hdr % (key[:46], "%.4g" % a, "%.4g" % b2, "%+.4g" % (b2 - a), s["text"][:40]))
    checks.append((key, a, b2, s))

print()
print("WHAT EACH PHENOMENON SHOULD HAVE DONE")
def find(sub):
    return [(k, a, b2, s) for (k, a, b2, s) in checks if sub in k]

def verdict(name, ok, detail):
    print("  %-4s %-34s %s" % ("PASS" if ok else "FAIL", name, detail))
    return ok

allok = True
amp = find("pc_amplitude")
if amp:
    drops = [(b2 - a) / a for (_k, a, b2, _s) in amp if a]
    allok &= verdict("probe degradation (B-M1)", min(drops) < -0.2,
                     "amplitude change %s" % ", ".join("%+.0f%%" % (d * 100) for d in drops[:4]))
# Only the GMO-target control series should stay put: the HMG and LEC series are
# the taxon reference, and they move on purpose — that is the inhibition drift.
cq = [x for x in find("pc_cq") if "| HMG |" not in x[0] and "| LEC |" not in x[0]]
ref = [x for x in find("pc_cq") if "| HMG |" in x[0] or "| LEC |" in x[0]]
if cq:
    moves = [abs(b2 - a) for (_k, a, b2, _s) in cq]
    allok &= verdict("...with target Cq NOT following", max(moves) < 1.2,
                     "largest 35S/T-NOS control move %.2f cycles (the lot step is +0.65)" % max(moves))
if ref:
    rise = max(b2 - a for (_k, a, b2, _s) in ref)
    allok &= verdict("inhibition drift (reference Cq)", rise > 1.2,
                     "taxon reference +%.2f cycles across the cohort" % rise)
eff = find("efficiency")
if eff:
    rise = max(b2 - a for (_k, a, b2, _s) in eff)
    allok &= verdict("efficiency drift (B-M3)", rise > 4,
                     "efficiency %+.1f %% across the cohort" % rise)
ntc = find("ntc_rate")
if ntc:
    r = max(b2 - a for (_k, a, b2, _s) in ntc)
    allok &= verdict("contamination trend (B-M5)", r > 0.1,
                     "reaction-blank positive rate %+.2f" % r)
rs = find("rep_sd")
if rs:
    allok &= verdict("operator precision (B-O1)", any(s["pts"] and max(s["pts"]) > 0.3 for (_k, _a, _b, s) in rs),
                     "rep_sd up to %.2f Cq" % max(max(s["pts"]) for (_k, _a, _b, s) in rs))
rc = find("rowcol")
if rc:
    allok &= verdict("faulty tip column (B-O3)", any(max(s["pts"]) > 0.4 for (_k, _a, _b, s) in rc),
                     "largest row/column offset %.2f Cq" % max(max(s["pts"]) for (_k, _a, _b, s) in rc))
rox = find("rox_level")
if rox:
    k, a, b2, s = rox[0]
    lo, hi = step(s["pts"])
    allok &= verdict("reagent-lot step (ROX)", abs(hi - lo) > 4000,
                     "passive reference %+.0f at the lot change" % (hi - lo))
funnels = [(k, s) for k, s in res["series"].items() if "ntc_op" in k or "action_op" in k]
flagged = [k for k, s in funnels if s.get("level") in ("bad", "warn")]
allok &= verdict("operator funnel (B-O5/B-O6)", bool(flagged),
                 "%d of %d funnel series flag an operator" % (len(flagged), len(funnels)))
ics = [(k, s) for k, s in res["series"].items() if "ic_shift" in k]
verdict("IC shift (B-M6)", False,
        "still unreachable: %s" % (ics[0][1]["text"][:60] if ics else "no series"))
print()
print("RESULT: " + ("pass" if allok else "fail"))
json.dump(res, open(os.path.join(setdir, "drift_probe.json"), "w"), indent=1)
