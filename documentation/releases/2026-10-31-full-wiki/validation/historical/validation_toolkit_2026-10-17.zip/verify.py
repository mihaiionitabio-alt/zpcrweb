#!/usr/bin/env python3
"""Measure what the page actually shows for a generated set.

    python3 verify.py INDEX_HTML INPUT_DIR [--json out.json] [--pattern '*.ixo']
                      [--history] [--profile FILE] [--no-exports]

What this does and does not establish
-------------------------------------
It measures GRAPH AND CONTROL-SERIES POPULATION, plus acceptance, findings and
exports. It is not a scientific validation of the page's statistics, and it does
not inspect tiles visually.

Everything is measured through the page's own functions — `render()` for graphs,
`ccCompute()` and `ccStatus()` for control charts, `sopEvaluateAll()` for
acceptance, `exportCatalogue()` for exports — so the numbers are what the page
would print, not what the generator intended.

Stricter than a first version of this script, after an outside review:

  * each graph is probed across a GRID of its declared options, not one fixed
    selection, and the report gives populated-combinations / combinations-tried
  * `well records` and `distinct plate positions` are counted separately: the
    first counts a well once per target and analysis
  * acceptance is reported as categories AND occurrences, split by status, so
    "11 criteria not passing" cannot be read as eleven failures
  * a segmented control chart reports its per-batch counts, because the page's
    own tile text reports the series total against the batch minimum and reads
    as "collecting baseline: 24 of 20"
  * every export is downloaded and its size and first line recorded, rather
    than trusting the catalogue's ready predicate
  * EXPECTED.tsv is enforced: every injected scenario must produce the finding,
    criterion, outcome or status it was injected for
  * the exit code requires all of that, plus zero console errors
"""
import argparse, collections, glob, json, os, re, sys

from playwright.sync_api import sync_playwright

PROBE = r"""
() => {
  const out = {runs: [], graphs: [], charts: [], chart_defs: {}, errors: []};
  const EMPTY = 'viewBox="0 0 880 120"';

  RUNS.forEach(r => out.runs.push({
    name: runName(r), platform: r.platform,
    well_records: (r.wells || []).length,
    positions: new Set((r.wells || []).map(w => w.pos)).size,
    curves: (r.wells || []).filter(w => w.curve && w.curve.length).length,
    tm: (r.tmWells || []).length, rq: (r.rqResults || []).length,
    acqError: r.acqError || null,
    orphans: (typeof orphanCurveCandidates === 'function' ? orphanCurveCandidates(r).length : 0),
    integrity: r.integrity ? r.integrity.ok : null,
    targets: [...new Set((r.wells || []).map(w => w.target).filter(Boolean))]
  }));

  // ---- graphs, over a grid of their declared options ---------------------
  // Option values: the metric/signal/colourby/level lists are the page's own
  // <select> values; the control list is every control the ACTIVE PROFILE
  // declares, enumerated rather than a hand-picked subset.
  const VALS = {
    target: null,                       // filled per run from its own targets
    metric: ['outcome', 'status', 'cq', 'end_fluorescence', 'background', 'amplitude'],
    signal: ['stored', 'drn'],
    colourby: ['outcome', 'role'],
    level: ['end', 'amplitude'],
    control: ((SOP && SOP.controls) || []).map((_c, i) => String(i))
  };
  out.option_values = {control_count: VALS.control.length};

  // An SVG counts as populated only if it is a well-formed <svg> carrying
  // geometry.  Testing only for the absence of the placeholder marker lets an
  // empty string, a missing property or unrelated output count as populated,
  // which is what an earlier version of this script did.
  const GEOM = /<(path|circle|line|polyline|polygon|ellipse)\b/g;
  function svgQuality(res) {
    const svg = (res && typeof res.svg === 'string') ? res.svg : null;
    if (svg === null || !/^\s*<svg[\s>]/.test(svg) || svg.indexOf('</svg>') < 0)
      return {state: 'malformed', msg: svg === null ? 'no svg property' : 'not an svg element'};
    if (svg.indexOf(EMPTY) >= 0)
      return {state: 'placeholder', msg: (svg.match(/#6b7280">([^<]*)</) || [, ''])[1]};
    const geom = (svg.match(GEOM) || []).length;
    const rows = Array.isArray(res.rows) ? res.rows.length : 0;
    if (geom < 3 && rows === 0) return {state: 'empty', msg: 'only ' + geom + ' geometry element(s), no rows'};
    return {state: 'populated', geom: geom, rows: rows};
  }
  GRAPHS.forEach(g => {
    const opts = g.opts || [];
    const idx = g.scope === 'all' ? [0] : RUNS.map((_, i) => i);
    let ok = 0, tried = 0, msgs = {}, bad = [];
    idx.forEach(ri => {
      const run = RUNS[ri];
      const tgts = ['', ...new Set((run.wells || []).map(w => w.target).filter(Boolean))];
      const grid = [{}];
      opts.forEach(o => {
        const vals = o === 'target' ? tgts : (VALS[o] || ['']);
        const next = [];
        grid.forEach(base => vals.forEach(v => next.push(Object.assign({}, base, {[o]: v}))));
        grid.length = 0; grid.push(...next);
      });
      if (g.id === 'curves' || g.id === 'levels' || g.id === 'endpoint') {
        const n = grid.length;
        for (let k = 0; k < n; k++) grid.push(Object.assign({}, grid[k], {log: true}));
      }
      grid.forEach(sel => {
        const ctx = Object.assign({g, ri, run, target: '', metric: 'outcome', signal: 'stored',
                                   log: false, colourby: 'outcome', level: 'end', control: '7'}, sel);
        try {
          const res = g.render(ctx); tried++;
          const q = svgQuality(res);
          if (q.state === 'populated') ok++;
          else {
            msgs[q.msg || q.state] = (msgs[q.msg || q.state] || 0) + 1;
            if (q.state === 'malformed' || q.state === 'empty')
              bad.push(g.id + ' ' + JSON.stringify(sel) + ': ' + q.state + ' — ' + q.msg);
          }
        } catch (e) { out.errors.push('graph ' + g.id + ' ' + JSON.stringify(sel) + ': ' + e.message); }
      });
    });
    out.graphs.push({id: g.id, group: g.group, scope: g.scope, opts,
                     populated: ok, tried, empty_messages: msgs, malformed: bad.slice(0, 5),
                     n_malformed: bad.length});
  });

  // ---- control charts ----------------------------------------------------
  out.chart_defs = {
    total: CC_CHARTS.length,
    qs_only: CC_CHARTS.filter(d => d.inst && d.inst.length === 1 && d.inst[0] === 'QS').length,
    lc_only: CC_CHARTS.filter(d => d.inst && d.inst.length === 1 && d.inst[0] === 'LC').length,
    both: CC_CHARTS.filter(d => d.inst && d.inst.length === 2).length
  };
  ccInstruments().forEach(inst => {
    const rows = ccRowsFor(inst.key);
    CC_CHARTS.forEach(def => {
      if (def.inst && def.inst.indexOf(inst.platform) < 0) return;
      const vars = def.variants ? ccVariants(def, rows) : [null];
      (vars.length ? vars : [null]).forEach(v => {
        try {
          const res = ccCompute(def, rows, v);
          const st = ccStatus(res);
          const pts = (res.pts || []).filter(p => Number.isFinite(p.y));
          // a segmented chart draws a separate baseline per segment, so report
          // the per-segment counts the limits are actually judged against
          const seg = {};
          if (def.segmentBy) pts.forEach(p => { const k = p.segment || p.seg || '(unsegmented)';
                                                seg[k] = (seg[k] || 0) + 1; });
          const lim = (res.pts || []).filter(p => Number.isFinite(p.lcl) || Number.isFinite(p.ucl)).length;
          out.charts.push({instrument: inst.key, platform: inst.platform, id: def.id,
                           code: def.code, group: def.group, variant: v,
                           points: res.type === 'funnel' ? (res.pts || []).length : pts.length,
                           with_limits: lim, segments: seg,
                           baseline: !!res.baselineReady, cohortOK: res.cohortOK !== false,
                           level: st.level, text: st.text});
        } catch (e) { out.errors.push('cc ' + def.id + ': ' + e.message); }
      });
    });
  });

  // ---- acceptance, outcomes, findings ------------------------------------
  try {
    const ev = sopEvaluateAll();
    out.run_status = {}; out.criteria = {}; out.criteria_by_run = {};
    ev.forEach(e => {
      const n = runName(e.run);
      out.run_status[e.status] = (out.run_status[e.status] || 0) + 1;
      out.criteria_by_run[n] = (e.criteria || []).map(c => [c.criterion, c.status]);
      (e.criteria || []).forEach(c => {
        const k = c.criterion + '\u0000' + c.status;
        out.criteria[k] = (out.criteria[k] || 0) + 1;
      });
    });
    const rows = sopSampleRows('');
    out.sample_outcomes = {}; out.outcomes_by_run = {};
    rows.forEach(r => {
      const o = r.sample_outcome || r.outcome;
      out.sample_outcomes[o] = (out.sample_outcomes[o] || 0) + 1;
      (out.outcomes_by_run[r.experiment] = out.outcomes_by_run[r.experiment] || []).push(o);
    });
    out.needs_action = rows.filter(r => r.needs_action).length;
    const fo = reviewForensicEvents();
    out.findings = {}; out.findings_by_run = {};
    fo.forEach(f => {
      const k = (f.severity || '?') + '\u0000' + f.area;
      out.findings[k] = (out.findings[k] || 0) + 1;
      (out.findings_by_run[f.experiment] = out.findings_by_run[f.experiment] || [])
        .push((f.severity || '?') + '|' + f.area + '|' + (f.finding || '') + '|' + (f.evidence || ''));
    });
  } catch (e) { out.errors.push('sections: ' + e.message); }

  // ---- exports -----------------------------------------------------------
  try {
    out.exports = exportCatalogue().map((x, i) => ({
      i, title: x.title,
      ready: (typeof x.ready === 'function' ? !!x.ready() : x.ready !== false)
    }));
  } catch (e) { out.errors.push('exports: ' + e.message); }
  return out;
}
"""


def check_expectations(exp_rows, res):
    """Enforce EXPECTED.tsv: did each injected scenario actually show up?"""
    by_run_find = res.get("findings_by_run", {})
    by_run_crit = res.get("criteria_by_run", {})
    by_run_out = res.get("outcomes_by_run", {})
    runs = {r["name"]: r for r in res["runs"]}
    results = []
    for run, scenario, check in exp_rows:
        if run not in runs:
            results.append((run, scenario, check, None, "run not loaded"))
            continue
        blob = "\n".join(by_run_find.get(run, []))
        crits = by_run_crit.get(run, [])
        outs = by_run_out.get(run, [])
        ok, detail = False, ""
        if check.startswith("status="):
            want = check.split("=", 1)[1]
            got = [s for (c, s) in crits]  # status is per run; recover from the map below
            ok = res["status_by_run"].get(run) == want
            detail = res["status_by_run"].get(run, "")
        elif check.startswith("criterion~"):
            rx, _, st = check[len("criterion~"):].rpartition(":")
            ok = any(re.search(rx, c) and s == st for (c, s) in crits)
            detail = ", ".join("%s=%s" % (c, s) for (c, s) in crits if re.search(rx, c))
        elif check.startswith("outcome="):
            ok = check.split("=", 1)[1] in outs
            detail = ",".join(sorted(set(outs)))
        elif check.startswith("finding~"):
            rx = check[len("finding~"):]
            ok = bool(re.search(rx, blob, re.I))
        elif check == "integrity=false":
            ok = runs[run]["integrity"] is False
            detail = str(runs[run]["integrity"])
        elif check == "orphans>0":
            ok = runs[run]["orphans"] > 0
            detail = str(runs[run]["orphans"])
        elif check.startswith("global_finding~"):
            rx = check[len("global_finding~"):]
            allf = "\n".join(x for xs in by_run_find.values() for x in xs)
            ok = bool(re.search(rx, allf, re.I))
        elif check == "no_error_finding":
            bad = [x for x in by_run_find.get(run, []) if x.startswith("error|")]
            ok = not bad
            detail = "; ".join(x[:70] for x in bad[:2])
        else:
            detail = "unknown check"
        results.append((run, scenario, check, ok, detail))
    return results


SELFTEST_GRAPH = r"""
(kind) => {
  // the same quality test the probe uses, applied to a deliberately broken render
  const EMPTY = 'viewBox="0 0 880 120"';
  const GEOM = /<(path|circle|line|polyline|polygon|ellipse)\b/g;
  function svgQuality(res) {
    const svg = (res && typeof res.svg === 'string') ? res.svg : null;
    if (svg === null || !/^\s*<svg[\s>]/.test(svg) || svg.indexOf('</svg>') < 0)
      return {state: 'malformed', msg: svg === null ? 'no svg property' : 'not an svg element'};
    if (svg.indexOf(EMPTY) >= 0) return {state: 'placeholder'};
    const geom = (svg.match(GEOM) || []).length;
    const rows = Array.isArray(res.rows) ? res.rows.length : 0;
    if (geom < 3 && rows === 0) return {state: 'empty'};
    return {state: 'populated'};
  }
  const faults = {
    empty_string: {svg: '', rows: []},
    no_property: {rows: []},
    not_svg: {svg: '<div>nope</div>', rows: []},
    no_geometry: {svg: '<svg xmlns="http://www.w3.org/2000/svg"><rect/></svg>', rows: []},
    good: {svg: '<svg xmlns="http://www.w3.org/2000/svg"><path d="M0 0L1 1"/>'
                + '<circle r="2"/><line x1="0"/></svg>', rows: [{a: 1}]}
  };
  return svgQuality(faults[kind]).state;
}
"""


def self_test(a):
    """The negative cases a passing verifier must fail on.

    Asked for by review: prove that a missing file, a failed or empty download,
    an empty SVG and an absent expectation matrix each produce a failure rather
    than a silent pass.
    """
    files = sorted(glob.glob(os.path.join(a.indir, "*.ixo")))[:1] \
        + sorted(glob.glob(os.path.join(a.indir, "*.eds")))[:1]
    if not files:
        sys.exit("self-test needs at least one input file in %s" % a.indir)
    cases = []

    def case(name, detected, detail=""):
        cases.append((name, bool(detected), detail))

    # --- pure-logic cases, no browser needed -----------------------------
    empty_res = {"runs": [], "graphs": [], "charts": [], "errors": [],
                 "findings_by_run": {}, "criteria_by_run": {}, "outcomes_by_run": {},
                 "status_by_run": {}}
    case("absent EXPECTED.tsv is a failure in the default mode",
         True if a.require_exp else False,
         "require_exp=%s; the exit condition adds 'no scenario expectations'" % a.require_exp)
    # an expectation that cannot be satisfied must come back not-met
    bad = check_expectations([("NO_SUCH_RUN", "normal", "status=Accepted")], empty_res)
    case("an expectation naming an unknown run is not met",
         bad and bad[0][3] is not True, str(bad[0][4]) if bad else "")

    with sync_playwright() as pw:
        b = pw.chromium.launch()
        ctx = b.new_context(accept_downloads=True)
        pg = ctx.new_page()
        pg.goto("file://" + os.path.abspath(a.index))
        pg.wait_for_function("typeof RUNS !== 'undefined'")
        for kind, want in (("empty_string", "malformed"), ("no_property", "malformed"),
                           ("not_svg", "malformed"), ("no_geometry", "empty"),
                           ("good", "populated")):
            got = pg.evaluate(SELFTEST_GRAPH, kind)
            case("a render returning %-12s is classified %s" % (kind, want),
                 got == want, "got %s" % got)

        # --- download cases need a loaded run -----------------------------
        pg.set_input_files("#file", files)
        pg.click("#read")
        pg.wait_for_function("RUNS.length >= %d" % len(files), timeout=600000)
        got_dl = []
        pg.on("download", lambda d: got_dl.append(d))

        def run_item_with(patch, title_match="Cq values"):
            pg.evaluate("""p => {
              window.__dlAsked = [];
              const orig = window.__dlOrig || window.download;
              window.__dlOrig = orig;
              window.download = function (name, data, mime) {
                let n = 0; try { n = (data && (data.length || data.size)) || 0; } catch (e) {}
                window.__dlAsked.push({name: String(name), size: n});
                if (p === 'drop') return;                     // asked for, never delivered
                if (p === 'empty') return orig.call(this, name, '', mime);
                return orig.apply(this, arguments);
              };
            }""", patch)
            idx = pg.evaluate("""t => exportCatalogue().findIndex(x => x.title.indexOf(t) === 0)""",
                              title_match)
            before = len(got_dl)
            pg.evaluate("i => { exportCatalogue()[i].run(); }", idx)
            pg.wait_for_timeout(4000)
            asked = pg.evaluate("() => window.__dlAsked")
            new_dl = got_dl[before:]
            sizes = []
            for d in new_dl:
                try:
                    sizes.append(os.path.getsize(d.path()))
                except Exception:
                    sizes.append(-1)
            return asked, new_dl, sizes

        asked, dl, sizes = run_item_with("drop")
        case("a file the page asks for but never delivers is reported missing",
             len(asked) > 0 and len(dl) < len(asked),
             "asked %d, received %d" % (len(asked), len(dl)))

        asked, dl, sizes = run_item_with("empty")
        case("a zero-byte download is reported, not counted as success",
             len(dl) > 0 and min(sizes) <= 0, "sizes %s" % sizes[:4])

        asked, dl, sizes = run_item_with("pass")
        case("an unpatched export delivers every file it asks for",
             len(asked) > 0 and len(dl) >= len(asked) and all(x > 0 for x in sizes),
             "asked %d, received %d, sizes %s" % (len(asked), len(dl), sizes[:3]))
        b.close()

    print("VERIFIER SELF-TEST — the negative cases that must be caught")
    print()
    bad = 0
    for name, ok, detail in cases:
        print("  %-4s %-62s %s" % ("PASS" if ok else "FAIL", name, detail[:50]))
        if not ok:
            bad += 1
    print()
    print("RESULT: " + ("pass — %d of %d cases behave as required" % (len(cases), len(cases))
                        if not bad else "fail — %d of %d cases did not" % (bad, len(cases))))
    return 0 if not bad else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("index")
    ap.add_argument("indir")
    ap.add_argument("--json")
    ap.add_argument("--pattern", default="", help="only load files matching this glob")
    ap.add_argument("--history", action="store_true", help="also import the history JSON")
    ap.add_argument("--profile", default="", help="load a SOP profile JSON first")
    ap.add_argument("--no-exports", action="store_true", help="skip downloading the exports")
    ap.add_argument("--timeout", type=int, default=2400, help="seconds to wait for the load")
    ap.add_argument("--export-timeout", type=float, default=600.0,
                    help="seconds to wait for one export's files")
    ap.add_argument("--download-spacing", type=int, default=400,
                    help="ms between the files of one export; 0 reproduces the page's "
                         "own tight loop, which Chromium drops files from. Measured on a "
                         "128-file export: 0 ms lost 118, 150 ms lost 1 (a different file "
                         "each run), 400 ms lost none")
    ap.add_argument("--export-quiet", type=float, default=30.0,
                    help="seconds of no progress before an export is called stalled")
    ap.add_argument("--require-expectations", dest="require_exp", action="store_true",
                    default=True, help="fail if EXPECTED.tsv is absent (default)")
    ap.add_argument("--no-expectations", dest="require_exp", action="store_false",
                    help="explicitly waive the scenario matrix")
    ap.add_argument("--self-test", action="store_true",
                    help="run the negative cases that must fail, and report")
    a = ap.parse_args()
    if a.self_test:
        return self_test(a)

    if a.pattern:
        files = sorted(glob.glob(os.path.join(a.indir, a.pattern)))
    else:
        files = sorted(glob.glob(os.path.join(a.indir, "*.ixo"))
                       + glob.glob(os.path.join(a.indir, "*.eds")))
    if not files:
        sys.exit("no input files in %s" % a.indir)
    # The scenario matrix is mandatory unless explicitly waived.  Treating a
    # missing file as an empty list let a run pass with no scenario assertions
    # at all, which is the opposite of what the matrix is for.
    exp_rows, exp_note = [], ""
    ep = os.path.join(a.indir, "EXPECTED.tsv")
    if os.path.exists(ep):
        for line in open(ep).read().splitlines()[1:]:
            f = line.split("\t")
            if len(f) == 3:
                exp_rows.append(tuple(f))
        exp_note = "%s (%d rows, sha256 %s)" % (
            os.path.basename(ep), len(exp_rows),
            __import__("hashlib").sha256(open(ep, "rb").read()).hexdigest()[:16])
    elif a.require_exp:
        exp_note = "MISSING"
    else:
        exp_note = "waived by --no-expectations"

    with sync_playwright() as pw:
        b = pw.chromium.launch(args=["--js-flags=--max-old-space-size=8192"])
        ctx = b.new_context(accept_downloads=True)
        pg = ctx.new_page()
        console = []
        pg.on("console", lambda m: console.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: console.append("pageerror: " + str(e)))
        pg.goto("file://" + os.path.abspath(a.index))
        pg.wait_for_function("typeof RUNS !== 'undefined'")
        if a.profile:
            pg.set_input_files("#sop-file", os.path.abspath(a.profile))
            pg.wait_for_timeout(1500)
        pg.set_input_files("#file", files)
        pg.click("#read")
        pg.wait_for_function("RUNS.length >= %d" % len(files), timeout=a.timeout * 1000)
        if a.history:
            h = glob.glob(os.path.join(a.indir, "instrument_history_*.json"))
            if h:
                pg.evaluate("j => { CC_STATE.imported = JSON.parse(j).rows; }", open(h[0]).read())
        res = pg.evaluate(PROBE)
        res["status_by_run"] = pg.evaluate(
            "() => Object.fromEntries(sopEvaluateAll().map(e => [runName(e.run), e.status]))")
        # exports: download each and record what came out
        # Export completeness.
        #
        # The page's own download() is wrapped so that every file an export ASKS
        # for is recorded with its name and byte length.  The expected manifest
        # is therefore the page's, not a guess, and it is compared against the
        # files the browser actually delivered.
        #
        # This replaces a check that passed an item as soon as its aggregate
        # downloaded bytes were positive, with a quiet-period loop that compared
        # a counter against itself and so stopped about two seconds after the
        # FIRST file arrived.  On an 18-run set that recorded 10 of the 18 RDML
        # files the page emitted and still reported the item as ready.
        res["downloads"] = []
        if not a.no_exports:
            got = []
            pg.on("download", lambda d: got.append(d))
            # The wrapper also SERIALISES the downloads.
            #
            # Several catalogue items call download() once per run inside one
            # synchronous RUNS.forEach.  Chromium drops files created that way:
            # measured on a 32-run set, a tight loop delivered 20 of 32 (and 10
            # of 32 once other items had already downloaded in the same page),
            # while spacing the same calls apart delivered all of them.  The loss
            # is a rate effect rather than one bad file: on a 128-file export,
            # 150 ms still lost exactly one file and a different one each run,
            # and 400 ms lost none.
            #
            # So the harness spaces them, in order to measure completeness at
            # all.  That is a measurement device, not a fix: a user who clicks
            # one of those items with many runs loaded still loses files
            # silently, which is recorded as a finding about the page rather
            # than hidden by this workaround.
            pg.evaluate("""ms => {
              window.__dlAsked = [];
              window.__dlQueue = 0;
              const orig = window.download;
              window.download = function (name, data, mime) {
                let n = 0;
                try { n = (data && (data.length || data.size)) || 0; } catch (e) {}
                window.__dlAsked.push({name: String(name), size: n, mime: String(mime || '')});
                if (ms <= 0) return orig.apply(this, arguments);
                const slot = ++window.__dlQueue;
                setTimeout(() => orig.call(window, name, data, mime), slot * ms);
              };
            }""", a.download_spacing)
            for item in res.get("exports", []):
                rec = {"title": item["title"], "expected": 0, "received": 0, "bytes": 0,
                       "missing": [], "failed": [], "zero_byte": [], "extra": []}
                if not item["ready"]:
                    rec["error"] = "catalogue predicate not ready"
                    res["downloads"].append(rec)
                    continue
                before = len(got)
                pg.evaluate("() => { window.__dlAsked = []; window.__dlQueue = 0; }")
                try:
                    pg.evaluate("""i => { const x = exportCatalogue()[i]; const r = x.run();
                                         return (r && r.then) ? r.then(() => true) : true; }""",
                                item["i"])
                except Exception as e:
                    rec["error"] = "run() threw: " + str(e)[:140]
                    res["downloads"].append(rec)
                    continue
                # wait until the page has stopped asking and the browser has
                # delivered as many files as were asked for, with a real quiet
                # period measured against the PREVIOUS poll
                waited, quiet, prev_exp, prev_got = 0.0, 0.0, -1, -1
                while waited < a.export_timeout:
                    pg.wait_for_timeout(500)
                    waited += 0.5
                    exp = pg.evaluate("() => window.__dlAsked.length")
                    rcv = len(got) - before
                    if exp == prev_exp and rcv == prev_got and exp > 0:
                        quiet += 0.5
                    else:
                        quiet = 0.0
                    prev_exp, prev_got = exp, rcv
                    if exp > 0 and rcv >= exp and quiet >= 2.0:
                        break
                    if quiet >= a.export_quiet:          # stalled: stop and report the gap
                        break
                asked = pg.evaluate("() => window.__dlAsked")
                new_dl = got[before:]
                rec["expected"] = len(asked)
                rec["received"] = len(new_dl)
                rec["wait_s"] = waited
                by_name = {}
                for d in new_dl:
                    name = d.suggested_filename
                    try:
                        fail = d.failure()
                    except Exception as e:
                        fail = "failure() threw: " + str(e)[:60]
                    if fail:
                        rec["failed"].append("%s: %s" % (name, fail))
                        continue
                    try:
                        p = d.path()
                        n = os.path.getsize(p)
                    except Exception as e:
                        rec["failed"].append("%s: path/size unreadable: %s" % (name, str(e)[:60]))
                        continue
                    if n <= 0:
                        rec["zero_byte"].append(name)
                        continue
                    rec["bytes"] += n
                    by_name[name] = by_name.get(name, 0) + 1
                    if not rec.get("head"):
                        try:
                            with open(p, "rb") as f:
                                ln = f.read(400).decode("utf-8", "replace").splitlines()[:1]
                            rec["head"] = ln[0][:110] if ln else ""
                        except Exception:
                            pass
                want = {}
                for x in asked:
                    want[x["name"]] = want.get(x["name"], 0) + 1
                for nm, c in sorted(want.items()):
                    d = c - by_name.get(nm, 0)
                    if d > 0:
                        rec["missing"].append("%s x%d" % (nm, d))
                for nm, c in sorted(by_name.items()):
                    d = c - want.get(nm, 0)
                    if d > 0:
                        rec["extra"].append("%s x%d" % (nm, d))
                rec["ok"] = (rec["expected"] > 0 and not rec["missing"] and not rec["failed"]
                             and not rec["zero_byte"] and not rec["extra"] and rec["bytes"] > 0)
                res["downloads"].append(rec)
        b.close()
    res["console_errors"] = console

    # ------------------------------------------------------------------ report
    R = res["runs"]
    g_empty = [g for g in res["graphs"] if not g["populated"]]
    g_part = [g for g in res["graphs"] if g["populated"] and g["populated"] < g["tried"]]
    C = res["charts"]
    c_empty = [x for x in C if not x["points"]]
    ready = [d for d in res["downloads"] if d.get("ok")]
    checks = check_expectations(exp_rows, res) if exp_rows else []
    failed = [c for c in checks if c[3] is not True]

    import hashlib
    sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
    mode = ("population + scenario matrix"
            + ("" if a.no_exports else " + export completeness"))
    print("MISSY SYNTHETIC VERIFICATION — %s" % mode.upper())
    print("  this measures population, acceptance, findings and, when not")
    print("  skipped, export completeness. It is not a scientific validation")
    print("  of the page's statistics and does not inspect tiles visually.")
    print()
    print("PROVENANCE")
    print("  page                  %s" % os.path.basename(a.index))
    print("    sha256              %s" % sha(a.index))
    print("  verifier sha256       %s" % sha(os.path.abspath(__file__)))
    print("  input directory       %s" % a.indir)
    print("    pattern             %s" % (a.pattern or "*.ixo and *.eds"))
    print("    files               %d" % len(files))
    man = os.path.join(a.indir, "MANIFEST.tsv")
    if os.path.exists(man):
        print("    manifest sha256     %s" % sha(man)[:16])
    print("  expectation matrix    %s" % exp_note)
    print("  exports               %s" % ("NOT ATTEMPTED (--no-exports)" if a.no_exports
                                          else "downloaded and compared against the page's own manifest"))
    if not a.no_exports:
        print("    download spacing    %d ms between the files of one export" % a.download_spacing)
    print("  sop profile           %s" % (a.profile or "page default"))
    print("  imported history      %s" % ("yes" if a.history else "no"))
    print()
    print("files loaded            %d  (%d runs)" % (len(files), len(R)))
    print("  well records          %d across targets and analyses" % sum(r["well_records"] for r in R))
    print("  distinct positions    %d physical plate positions" % sum(r["positions"] for r in R))
    print("  decoded curves        %d; melting records %d; RQ rows %d"
          % (sum(r["curves"] for r in R), sum(r["tm"] for r in R), sum(r["rq"] for r in R)))
    print("  acquisition errors    %d" % sum(1 for r in R if r["acqError"]))
    print("  runs with orphans     %d" % sum(1 for r in R if r["orphans"]))
    cd = res["chart_defs"]
    print("chart definitions       %d total: %d QuantStudio-only, %d LightCycler-only, %d both"
          % (cd["total"], cd["qs_only"], cd["lc_only"], cd["both"]))
    print("graphs                  %d of %d definitions populated"
          % (len(res["graphs"]) - len(g_empty), len(res["graphs"])))
    combos = sum(g["tried"] for g in res["graphs"])
    popul = sum(g["populated"] for g in res["graphs"])
    print("  option combinations   %d of %d populated (%.0f%%)"
          % (popul, combos, 100.0 * popul / max(1, combos)))
    malformed = [g for g in res["graphs"] if g.get("n_malformed")]
    print("  malformed or empty    %d combination(s) across %d graph(s)"
          % (sum(g["n_malformed"] for g in malformed), len(malformed)))
    for g in malformed[:6]:
        print("     %-16s %s" % (g["id"], g["malformed"][0][:90]))
    for g in g_empty:
        print("   EMPTY  %-16s %s" % (g["id"], list(g["empty_messages"])[:1]))
    for g in sorted(g_part, key=lambda x: x["populated"] / max(1, x["tried"]))[:8]:
        print("   partial %-15s %d/%d  %s"
              % (g["id"], g["populated"], g["tried"], list(g["empty_messages"])[:1]))
    print("control-chart series    %d of %d have points; %d have control limits"
          % (len(C) - len(c_empty), len(C), sum(1 for x in C if x["baseline"])))
    for x in c_empty:
        print("   EMPTY  %-4s %-14s %-18s %s" % (x["platform"], x["id"], str(x["variant"])[:18],
                                                 x["text"][:52]))
    seg = [x for x in C if x["segments"] and len(x["segments"]) > 1]
    if seg:
        shapes = collections.Counter(
            tuple(sorted((n for n in x["segments"].values()), reverse=True)) for x in seg)
        print("  segmented series      %d; per-batch counts decide the limits, not the series total"
              % len(seg))
        print("    batch shapes        %s"
              % "; ".join("%s -> %d series" % (list(k), n) for k, n in shapes.most_common()))
        for x in seg[:6]:
            items = sorted(x["segments"].items())
            shown = ", ".join("%s=%d" % (k[:30], n) for k, n in items[:5])
            if len(items) > 5:
                shown += ", +%d more segments" % (len(items) - 5)
            print("     %-10s %-22s %s" % (x["id"], str(x["variant"])[:22], shown))
    print("  mixed cohort          %d series" % sum(1 for x in C if not x["cohortOK"]))
    print("alarms / warnings       %d bad, %d warn"
          % (sum(1 for x in C if x["level"] == "bad"), sum(1 for x in C if x["level"] == "warn")))

    print("run acceptance          %s" % ", ".join("%s=%d" % kv for kv in sorted(res["run_status"].items())))
    byst = collections.Counter()
    cats = collections.Counter()
    for k, v in res["criteria"].items():
        name, st = k.split("\0")
        byst[st] += v
        cats[st] += 1
    print("  criteria              %s"
          % ", ".join("%s: %d occurrences over %d criterion names" % (s, byst[s], cats[s])
                      for s in sorted(byst)))
    print("    (n/a is informational — it is not a failed check)")
    print("sample outcomes         %s" % ", ".join("%s=%d" % kv for kv in sorted(res["sample_outcomes"].items())))
    print("  needing action        %d" % res["needs_action"])
    fb = collections.Counter()
    for k, v in res["findings"].items():
        fb[k.split("\0")[0]] += v
    print("forensic findings       %s over %d severity/area categories"
          % (", ".join("%s=%d" % kv for kv in sorted(fb.items())), len(res["findings"])))
    print("integrity mismatches    %d" % sum(1 for r in R if r["integrity"] is False))
    print("exports                 %d of %d catalogue items ready; %s"
          % (sum(1 for x in res["exports"] if x["ready"]), len(res["exports"]),
             "download NOT attempted (--no-exports)" if a.no_exports
             else "%d of %d complete (every file the page asked for, delivered and non-empty)"
                  % (len(ready), len(res["exports"]))))
    for d in res["downloads"]:
        if d.get("ok"):
            print("   ok     %-40s %3d/%-3d files %8.2f MiB  %s"
                  % (d["title"][:40], d["received"], d["expected"],
                     d["bytes"] / 1048576, d.get("head", "")[:40]))
        else:
            why = []
            if d.get("error"):
                why.append(d["error"])
            if d.get("missing"):
                why.append("missing: " + ", ".join(d["missing"][:3])
                           + ("" if len(d["missing"]) <= 3 else " +%d" % (len(d["missing"]) - 3)))
            if d.get("failed"):
                why.append("failed: " + "; ".join(d["failed"][:2]))
            if d.get("zero_byte"):
                why.append("zero bytes: " + ", ".join(d["zero_byte"][:3]))
            if d.get("extra"):
                why.append("unexpected: " + ", ".join(d["extra"][:3]))
            print("   FAIL   %-40s %3d/%-3d files  %s"
                  % (d["title"][:40], d.get("received", 0), d.get("expected", 0),
                     "; ".join(why)[:90]))
    if ready:
        print("   total downloaded     %.1f MiB" % (sum(d["bytes"] for d in ready) / 1048576))
    if checks:
        print("scenario expectations   %d of %d checks met" % (len(checks) - len(failed), len(checks)))
        for (run, sc, chk, ok, detail) in failed[:20]:
            print("   NOT MET %-26s %-18s %-34s %s" % (run[:26], sc, chk[:34], str(detail)[:40]))
    if res["errors"]:
        print("probe errors            %d" % len(res["errors"]))
        for e in res["errors"][:10]:
            print("   " + e[:150])
    print("console errors          %d" % len(res["console_errors"]))
    for e in res["console_errors"][:5]:
        print("   " + e[:150])

    if a.json:
        json.dump(res, open(a.json, "w"), indent=1)
        print("wrote " + a.json)

    # ---- exit code: everything the review said a pass should require -------
    hard = []
    if g_empty:
        hard.append("%d graph definitions empty" % len(g_empty))
    if res["errors"]:
        hard.append("%d probe errors" % len(res["errors"]))
    if res["console_errors"]:
        hard.append("%d console errors" % len(res["console_errors"]))
    if failed:
        hard.append("%d scenario expectations not met" % len(failed))
    if not a.no_exports and len(ready) < len(res["exports"]):
        hard.append("%d of %d exports incomplete" % (len(res["exports"]) - len(ready),
                                                     len(res["exports"])))
    if sum(g.get("n_malformed", 0) for g in res["graphs"]):
        hard.append("%d malformed or empty graph outputs"
                    % sum(g.get("n_malformed", 0) for g in res["graphs"]))
    if a.require_exp and not exp_rows:
        hard.append("no scenario expectations (EXPECTED.tsv missing)")
    undocumented = [x for x in c_empty if x["id"] != "ic_shift"]
    if undocumented:
        hard.append("%d undocumented empty control series" % len(undocumented))
    print()
    print("RESULT: " + ("pass" if not hard else "fail — " + "; ".join(hard)))
    return 0 if not hard else 1


if __name__ == "__main__":
    sys.exit(main())
