"""LightCycler-480-style .ixo writer.

The container is an <objectstream signature="IXOS"> XML document followed by a
trailing MD5 line.  Objects are selected by their class attribute, so the class
strings below are load-bearing.

Three parts decide whether the control charts have data at all:

  TemperatureLog      heat_rate, cool_rate, overshoot, settling, transition,
                      templog_late, and the thermal trace graph
  AcquisitionStore    the six props Time/Temp/Channel/IntgrTime/Valid/RefValue
                      must be consecutive and in that order, or ccIxoAcquisitions
                      silently returns nothing and every optics and timing chart
                      goes blank while the curves still decode
  FloPoints           one float32 per plate position, which is where the curves,
                      bg_median, plateau_median and pc_amplitude come from
"""
import base64, hashlib, math, struct, zlib

from arz import arz_u32, arz_f64, hex_double
from curves import amp_curve
from layout import CHANNELS, IXO_TYPE

SW_VERSION = "1.5.1.62"


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + "%03d" % (t.microsecond // 1000)


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def md5_trailer(body):
    """'$AABBCCDD-...' — the MD5 digest read as four little-endian words."""
    h = hashlib.md5(body).digest()
    return "$" + "-".join("%08X" % struct.unpack("<I", h[i:i + 4])[0] for i in (0, 4, 8, 12))


# --------------------------------------------------------------------------
# thermal simulation -> TemperatureLog + acquisition timestamps
# --------------------------------------------------------------------------
def simulate_thermal(programs, rng, heat=4.62, cool=2.26, dt_ms=410, overshoot=1.45,
                     tau=1.1, start_t=25.0, acq_at=(1, 2), jitter_ms=0.0,
                     late_log_share=0.0):
    """programs = [(name, cycles, mode, [(target, hold_s, slope, acq_mode), ...]), ...]

    Returns (times_ms, temps, acquisitions) where acquisitions is a list of
    (program_index, segment_index, cycle, t_ms).  The ramp rates are what
    heat_rate and cool_rate measure; `overshoot` must exceed the 0.5 degC
    settling band to be visible at all, since a smaller excursion never leaves
    the band the page measures against.
    """
    times, temps, acq = [], [], []
    clock, T = 0.0, start_t
    d = dt_ms / 1000.0

    def ramp_and_hold(target, hold):
        nonlocal clock, T
        while abs(T - target) > 1e-9:
            r = heat if target > T else cool
            T += math.copysign(min(abs(target - T), r * d), target - T)
            clock += d
            temps.append(T)
            times.append(clock * 1000.0)
        over = overshoot if target > 90 else 0.0
        t0, end = clock, clock + hold
        while clock < end - 1e-9:
            clock += d
            temps.append(target + over * math.exp(-(clock - t0) / tau) + rng.gauss(0, 0.03))
            times.append(clock * 1000.0)

    for pi, (_n, cycles, _m, segs) in enumerate(programs):
        for c in range(cycles):
            for si, (tg, hold, _slope, am) in enumerate(segs):
                ramp_and_hold(tg, hold)
                if am in (1, 2) and (pi, si) == acq_at:
                    j = rng.gauss(0, jitter_ms) if jitter_ms else 0.0
                    acq.append((pi, si, c, int(round(clock * 1000 - 300 + j))))

    ms = [int(round(v)) for v in times]
    if late_log_share:                      # intervals over 500 ms feed templog_late
        n = int(len(ms) * late_log_share)
        for i in range(1, n + 1):
            k = (i * 37) % (len(ms) - 1) + 1
            for j in range(k, len(ms)):
                ms[j] += 260
    for i in range(1, len(ms)):             # strictly increasing is a hard requirement
        if ms[i] <= ms[i - 1]:
            ms[i] = ms[i - 1] + 1
    return ms, temps, acq


# --------------------------------------------------------------------------
# AcquisitionStore
# --------------------------------------------------------------------------
def acquisition_store(acq, channels, curves, npos, rng, setpoint, lamp_ref,
                      lamp_drift_pct, invalid=(), gap_ms=1030, scaling=20000):
    n_ch, n_cyc = len(channels), len(acq)
    out = ['<obj name="root" class="HTCAcquisitionStore" version="1">',
           '<prop name="ChannelCount">%d</prop><prop name="SampleCount">%d</prop>' % (n_ch, npos),
           '<list name="Cycles" count="%d">' % n_cyc]
    for (pi, si, c, t0) in acq:
        out.append('<obj name="Item" class="TCycle" version="1">'
                   '<prop name="Program">%d</prop><prop name="Segment">%d</prop>'
                   '<prop name="Cycle">%d</prop><list name="Acquisitions" count="%d">'
                   % (pi, si, c, n_ch))
        for ch in range(n_ch):
            intgr = channels[ch][3]
            t = t0 + ch * (gap_ms + intgr)
            frac = c / max(1, n_cyc - 1)
            ref = lamp_ref[ch] * (1.0 + lamp_drift_pct[ch] / 100.0 * frac) + rng.gauss(0, 4)
            flo = struct.pack("<%df" % npos, *curves[ch][c])
            out.append('<obj name="Item" class="THTCFloAcquisition" version="3">'
                       '<prop name="Time">%d</prop>'
                       '<prop name="Temp">%s</prop>'
                       '<prop name="Channel">%d</prop>'
                       '<prop name="IntgrTime">%d</prop>'
                       '<prop name="Valid">%d</prop>'
                       '<prop name="RefValue">%s</prop>'
                       '<prop name="ScalingFactor">%d</prop>'
                       '<prop name="FloPoints">%s</prop></obj>'
                       % (t, hex_double(setpoint + rng.gauss(0, 0.09)), ch, intgr,
                          0 if (c, ch) in invalid else 1, hex_double(ref), scaling,
                          base64.b64encode(flo).decode()))
        out.append('</list></obj>')
    out.append('</list></obj>')
    return base64.b64encode(zlib.compress("".join(out).encode("utf-8"), 6)).decode()


# --------------------------------------------------------------------------
def build(spec, wells, meta, rng):
    rows, cols = spec["rows"], spec["cols"]
    npos = rows * cols
    programs = spec["programs"]
    th = dict(spec.get("thermal", {}))
    times, temps, acq = simulate_thermal(programs, rng, **th)
    n_cyc = len(acq)
    n_ch = len(CHANNELS)

    # ---- curves, one array per channel and cycle, indexed by plate position
    by_pos = {w.pos: w for w in wells}
    curves = [[[0.0] * npos for _ in range(n_cyc)] for _ in range(n_ch)]
    orph = {(p, ch): cq for (p, ch, cq) in meta.get("orphans", [])}
    for ch, (_nm, _ex, _em, _ig, target, _dye) in enumerate(CHANNELS):
        for pos in range(npos):
            w = by_pos.get(pos)
            if (pos, ch) in orph:
                cq = orph[(pos, ch)]
            elif w is not None and target in w.cq:
                cq = w.cq[target]
            else:
                cq = None                      # unassigned channel or empty well: flat
            # amp_scale below 1 is probe or dye degradation: the amplitude falls
            # while the Cq stays where it is, which is the signature B-M1
            # pc_amplitude exists to catch and A-M1 pc_cq must NOT show.
            cv = amp_curve(cq, n_cyc, rng,
                           base=1680.0 + 24.0 * ch + (6.0 if w is None else 0.0),
                           amp=(2050.0 - 70.0 * ch) * spec.get("amp_scale", 1.0),
                           drift=spec.get("baseline_drift", 0.0))
            for c in range(n_cyc):
                curves[ch][c][pos] = cv[c]

    store = acquisition_store(
        acq, CHANNELS, curves, npos, rng,
        setpoint=programs[1][3][-1][0],
        lamp_ref=spec.get("lamp_ref", [7100.0, 12400.0, 16800.0, 20200.0]),
        lamp_drift_pct=spec.get("lamp_drift", [-1.2, -1.5, -1.9, -2.4]),
        invalid=set(spec.get("invalid_acq", ())))

    L = []
    A = L.append
    A('<objectstream signature="IXOS" version="1">\r\n')
    A('\t<obj name="root" class="HTCExperiment" version="5">\r\n')
    for k, v in (("name", spec["name"]), ("UID", spec["uid"]), ("OwnerUID", spec["owner_uid"]),
                 ("Created", iso(spec["created"])), ("CreatedByName", spec["operator"]),
                 ("LastModified", iso(spec["modified"])),
                 ("LastModifiedByName", spec["operator"]),
                 ("SWVersion", SW_VERSION), ("State", "Closed"),
                 ("Notes", spec["notes"])):
        A('\t\t<prop name="%s">%s</prop>\r\n' % (k, esc(v)))
    A('\t\t<list name="AppliedTemplates" count="1"><item>generated demonstration template</item></list>\r\n')

    A('\t\t<obj name="run" class="HTCRun" version="7">\r\n')
    for k, v in (("name", "Run"), ("Created", iso(spec["created"])),
                 ("StartTime", iso(spec["start"])), ("EndTime", iso(spec["end"])),
                 ("InstrumentName", spec["instrument_name"]),
                 ("InstrumentVersion", spec["firmware"]),
                 ("InstrumentID", spec["instrument_id"]),
                 ("PlateID", spec["plate_id"]), ("Technician", spec["operator"]),
                 ("InstrCalibrationDate", iso(spec["calibration"])),
                 ("RevsComplete", 1), ("MacroName", ""), ("MacroOwner", ""),
                 ("ChannelCount", n_ch), ("InstrumentSubclass", npos),
                 ("SampleVolume", 20), ("DefFormatName", "Multi Colour Hydrolysis Probe")):
        A('\t\t\t<prop name="%s">%s</prop>\r\n' % (k, esc(v)))
    A('\t\t\t<obj name="blocktype" class="HTCBlockType" version="2">'
      '<prop name="Id">%d</prop><prop name="RowCount">%d</prop><prop name="ColCount">%d</prop>'
      '<prop name="RampRateMaxUp">4.4</prop><prop name="RampRateMaxDn">2.2</prop>'
      '<prop name="ReactionVolMin">10</prop><prop name="ReactionVolMax">100</prop>'
      '<prop name="ReactionVolDefault">20</prop></obj>\r\n' % (npos, rows, cols))

    A('\t\t\t<list name="channels" count="%d">\r\n' % n_ch)
    for (nm, ex, em, ig, _t, _d) in CHANNELS:
        A('\t\t\t\t<obj name="item" class="HTCChannel" version="2">'
          '<prop name="name">%s</prop><prop name="Active">1</prop>'
          '<prop name="EmissionWL">%d</prop><prop name="ExcitationWL">%d</prop>'
          '<prop name="IntgrTime">%d</prop><prop name="MaxIntgrTime">1000</prop>'
          '<prop name="MeltFactor">1.2</prop><prop name="QuantFactor">20</prop></obj>\r\n'
          % (nm, em, ex, ig))
    A('\t\t\t</list>\r\n')

    A('\t\t\t<list name="programs" count="%d">\r\n' % len(programs))
    for (pn, cyc, mode, segs) in programs:
        A('\t\t\t\t<obj name="item" class="HTCRunProgram" version="3">'
          '<prop name="name">%s</prop><prop name="Cycles">%d</prop>'
          '<prop name="AnalysisMode">%s</prop><list name="segments" count="%d">'
          % (esc(pn), cyc, mode, len(segs)))
        for (tg, hold, slope, am) in segs:
            A('<obj name="item" class="HTCRunSegment" version="3">'
              '<prop name="Target">%s</prop><prop name="Target2">0</prop>'
              '<prop name="Hold">%s</prop><prop name="Slope">%s</prop>'
              '<prop name="AcquisitionMode">%d</prop><prop name="AcqPerDegree">0</prop>'
              '<prop name="StepSize">0</prop><prop name="StepDelay">0</prop></obj>'
              % (tg, hold, slope, am))
        A('</list></obj>\r\n')
    A('\t\t\t</list>\r\n')

    A('\t\t\t<prop name="AcqStoreClass">HTCAcquisitionStore</prop>\r\n')
    A('\t\t\t<prop name="AcquisitionStore">%s</prop>\r\n' % store)
    A('\t\t\t<obj name="TemperatureLog" class="TemperatureLog" version="1">'
      '<prop name="Times">%s</prop><prop name="Temps">%s</prop></obj>\r\n'
      % (arz_u32(times), arz_f64(temps)))
    A('\t\t</obj>\r\n')

    # ---- plate model ------------------------------------------------------
    A('\t\t<obj name="samples" class="EMList" version="1"><list name="emlist" count="%d">\r\n'
      % (len(wells) * (2 + 3 * n_ch)))
    for w in sorted(wells, key=lambda x: x.pos):
        A('<obj name="item" class="GenSampleEditName" version="1">'
          '<prop name="Position">%d</prop><prop name="name">%s</prop></obj>\r\n'
          % (w.pos, esc(w.name)))
        A('<obj name="item" class="HTCSampleID" version="1">'
          '<prop name="Position">%d</prop><prop name="SampleID">%s</prop></obj>\r\n'
          % (w.pos, esc(w.name)))
        if w.note:
            A('<obj name="item" class="GenSampleEditNotes" version="1">'
              '<prop name="Position">%d</prop><prop name="Notes">%s</prop></obj>\r\n'
              % (w.pos, esc(w.note)))
        for ch, (_nm, _ex, _em, _ig, target, _d) in enumerate(CHANNELS):
            if target not in w.cq:
                continue
            cp = ('<obj name="ChannelProp" class="ChannelProperty" version="1">'
                  '<prop name="ChannelIdx">%d</prop></obj>' % ch)
            A('<obj name="item" class="QuantSampleTypeProperty" version="1">'
              '<prop name="Position">%d</prop><prop name="SampleType">%s</prop>%s</obj>\r\n'
              % (w.pos, IXO_TYPE[w.role], cp))
            A('<obj name="item" class="QuantConcProperty" version="1">'
              '<prop name="Position">%d</prop><prop name="Concentration">%s</prop>%s</obj>\r\n'
              % (w.pos, "" if w.qty is None else repr(w.qty), cp))
            A('<obj name="item" class="TargetName" version="1">'
              '<prop name="Position">%d</prop><prop name="name">%s</prop>%s</obj>\r\n'
              % (w.pos, esc(target), cp))
    A('</list></obj>\r\n')

    # ---- one absolute-quantification analysis per channel -----------------
    A('\t\t<obj name="analyses" class="AnalysisList" version="1"><list name="emlist" count="%d">\r\n' % n_ch)
    for ch, (nm, ex, em, _ig, target, _d) in enumerate(CHANNELS):
        sub = [w for w in sorted(wells, key=lambda x: x.pos) if target in w.cq]
        A('<obj name="item" class="Legacy Absolute Quantification Analysis" version="6">'
          '<prop name="name">Abs Quant/2nd Derivative Max %s</prop>'
          '<prop name="shortname">%s</prop><prop name="UID">%032X</prop>'
          '<prop name="Created">%s</prop><prop name="LastModified">%s</prop>'
          '<prop name="CreatedByName">%s</prop><prop name="LastModifiedByName">%s</prop>'
          '<prop name="CalcState">4</prop><prop name="IsCCCEnabled">0</prop>'
          '<prop name="SubsetName">%s</prop><prop name="MaxPosSamples">%d</prop>'
          '<obj name="ChannelRatio" class="ChannelRatio" version="1">'
          '<prop name="NumeratorEWL">%d</prop><prop name="NumeratorXWL">%d</prop>'
          '<prop name="DenominatorEWL">0</prop><prop name="DenominatorXWL">0</prop></obj>\r\n'
          % (esc(nm), esc(target), rng.getrandbits(128), iso(spec["analysed"]),
             iso(spec["modified"]), esc(spec["operator"]), esc(spec["operator"]),
             esc(target), npos, em, ex))

        if target in meta.get("std_targets", []):
            std = [w for w in sub if w.role == "standard" and w.cq.get(target)]
            if len(std) >= 4:
                A('<obj name="StdCurve" class="StdCurve" version="3">'
                  '<prop name="Method">Fit Points</prop><prop name="CurveType">Fitted</prop>'
                  '<prop name="State">1</prop><prop name="Slope">%.4f</prop>'
                  '<prop name="YIntercept">%.3f</prop><prop name="FitError">%.4f</prop>'
                  '<prop name="Efficiency">%.4f</prop><prop name="CurveEff">%.2f</prop>'
                  % (-spec.get("std_slope", 3.32), 35.0, 0.012,
                     10 ** (1 / spec.get("std_slope", 3.32)) - 1, 100.0))
                A('<obj name="Standard Samples" class="EMList" version="1"><list name="emlist" count="%d">' % len(std))
                for w in std:
                    A('<obj name="item" class="StdCrvSam" version="2">'
                      '<prop name="name">%s</prop><prop name="Position">%d</prop>'
                      '<prop name="PosAsStr">%s</prop><prop name="CrossingPoint">%s</prop>'
                      '<prop name="Concentration">%s</prop><prop name="Call">2</prop>'
                      '<prop name="TargetName">%s</prop></obj>'
                      % (esc(w.name), w.pos, well_label(w.pos, cols),
                         repr(w.cq[target]), repr(w.qty), esc(target)))
                A('</list></obj></obj>')

        A('<obj name="AnaSamples" class="TAnalysisSampleList" version="1">'
          '<list name="emlist" count="%d">\r\n' % len(sub))
        for w in sub:
            cq = w.cq.get(target)
            call = w.call if w.call is not None else (2 if cq else 0)
            A('<obj name="item" class="QuantSampleB" version="2">'
              '<prop name="IsIncluded">%s</prop><prop name="Pos">%d</prop>'
              '<prop name="Call">%d</prop><prop name="CrossingPointStatus">%d</prop>'
              '<prop name="CrossingPoint">%s</prop><prop name="CpState">1</prop>'
              '<prop name="CpUncertain">%d</prop><prop name="CalcConc">%s</prop>'
              '<prop name="ConcStatus">csNormal</prop>'
              '<prop name="StandardConc">%s</prop><prop name="ManualCall">%d</prop>'
              '<prop name="WarnCodes">%s</prop><prop name="WarnDesc">%s</prop></obj>\r\n'
              % ("0" if w.omit else "1", w.pos, call, 0 if cq else 1,
                 repr(cq) if cq else "0", 1 if call == 1 else 0,
                 "0" if w.qty is None else repr(w.qty),
                 "" if w.qty is None else repr(w.qty), 1 if w.manual else 0,
                 " ".join(w.flags), "manual setting recorded" if w.manual else ""))
        A('</list></obj></obj>\r\n')
    # ---- melting-curve analysis (optional) --------------------------------
    # A result record becomes a melting record when it carries TmCount or a Tms
    # list (resultKindOf), and those records are what the melting-peaks export
    # reads.  Only cohorts whose protocol actually contains a melting programme
    # get this, because adding a programme changes ccProtocolKey and would split
    # a control-chart cohort.
    if spec.get("melt"):
        ch, (nm, ex, em, _ig, target, _d) = 0, CHANNELS[0]
        sub = [w for w in sorted(wells, key=lambda x: x.pos) if target in w.cq]
        A('<obj name="item" class="Legacy Tm Calling Analysis" version="4">'
          '<prop name="name">Tm Calling %s</prop><prop name="shortname">TM</prop>'
          '<prop name="UID">%032X</prop><prop name="Created">%s</prop>'
          '<prop name="LastModified">%s</prop><prop name="CreatedByName">%s</prop>'
          '<prop name="LastModifiedByName">%s</prop><prop name="CalcState">4</prop>'
          '<prop name="SubsetName">%s</prop><prop name="MaxPosSamples">%d</prop>'
          '<obj name="ChannelRatio" class="ChannelRatio" version="1">'
          '<prop name="NumeratorEWL">%d</prop><prop name="NumeratorXWL">%d</prop>'
          '<prop name="DenominatorEWL">0</prop><prop name="DenominatorXWL">0</prop></obj>\r\n'
          % (esc(nm), rng.getrandbits(128), iso(spec["analysed"]), iso(spec["modified"]),
             esc(spec["operator"]), esc(spec["operator"]), esc(target), npos, em, ex))
        A('<obj name="MeltSamples" class="TAnalysisSampleList" version="1">'
          '<list name="emlist" count="%d">\r\n' % len(sub))
        for w in sub:
            cq = w.cq.get(target)
            # a specific product melts near 84 degC; a well with no product gets a
            # single low, broad peak, which is what a primer dimer looks like
            tm = 84.1 + rng.gauss(0, 0.22) if cq else 72.4 + rng.gauss(0, 0.9)
            npk = 2 if (cq and w.role == "unknown" and w.pos % 11 == 0) else 1
            tms = [round(tm, 3)] + ([round(tm - 11.6 + rng.gauss(0, 0.4), 3)] if npk == 2 else [])
            hts = [round(2.4 + rng.gauss(0, 0.3), 3) for _ in tms]
            wds = [round(3.1 + rng.gauss(0, 0.25), 3) for _ in tms]
            ars = [round(14.2 + rng.gauss(0, 1.6), 3) for _ in tms]
            lst = lambda n, v: ('<list name="%s" count="%d">%s</list>'
                                % (n, len(v) + 1, "".join("<item>%s</item>" % x for x in v) + "<item>0</item>"))
            A('<obj name="item" class="MeltSampleB" version="2">'
              '<prop name="Pos">%d</prop><prop name="IsIncluded">%s</prop>'
              '<prop name="TmCount">%d</prop><prop name="Call">%d</prop>'
              '<prop name="ShowShoulder">0</prop><prop name="ManualTms">0</prop>'
              '%s%s%s%s</obj>\r\n'
              % (w.pos, "0" if w.omit else "1", npk, 2 if cq else 0,
                 lst("Tms", tms), lst("Heights", hts), lst("Widths", wds), lst("Amounts", ars)))
        A('</list></obj></obj>\r\n')

    A('</list></obj>\r\n')
    A('\t</obj>\r\n</objectstream>\r\n')

    body = "".join(L).encode("utf-8")
    trailer = md5_trailer(body)
    if spec.get("break_checksum"):
        trailer = "$00000000-" + trailer.split("-", 1)[1]
    return body + trailer.encode() + b"\r\n"


def well_label(pos, cols):
    return "%s%d" % ("ABCDEFGHIJKLMNOP"[pos // cols], pos % cols + 1)


def protocol_key(programs):
    """ccProtocolKey, recomputed here so an imported history matches the cohort."""
    segs = []
    for (_n, _c, _m, ss) in programs:
        for (tg, hold, slope, _am) in ss:
            s = "%g/%gs" % (float(tg), float(hold or 0))
            if slope:
                s += "@" + "%g" % float(slope)
            segs.append(s)
    return " ".join(segs)
