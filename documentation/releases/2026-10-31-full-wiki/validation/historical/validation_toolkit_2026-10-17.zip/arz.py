"""ARZ array encoding used by the LightCycler container.

The page's decoder (ccDecodeArz) inspects byte 0 only: 0x44 ('D') means a
float64 little-endian array, anything else a uint32 little-endian array.  It
then tries header lengths [13,12,14,11,15,10,16], raw and LZSS-decoded, and
keeps the candidate whose whole array is plausible.  A 13-byte header with a
raw payload is what the real files use for Times and is what scores 1.0, so
that is what we write — no LZSS, which the decoder accepts but does not need.
"""
import base64, struct

HDR = 9  # 4 magic bytes + 9 filler = the 13-byte header the decoder prefers


def arz_u32(values):
    """Times, in integer milliseconds.  Must be non-decreasing."""
    v = [int(x) for x in values]
    return base64.b64encode(b"LARZ" + bytes(HDR) + struct.pack("<%dI" % len(v), *v)).decode()


def arz_f64(values):
    """Temperatures in degrees C.  Each must satisfy -50 < v < 200 and |v| > 1e-6."""
    v = [float(x) for x in values]
    return base64.b64encode(b"DARZ" + bytes(HDR) + struct.pack("<%dd" % len(v), *v)).decode()


def hex_double(x):
    """'$4052000000000000' — big-endian IEEE754 double, as hexBEToDouble reads it."""
    return "$" + struct.pack(">d", float(x)).hex().upper()
