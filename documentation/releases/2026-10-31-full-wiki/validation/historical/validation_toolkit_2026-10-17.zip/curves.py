"""Fluorescence curve model.

Values are in the stored-count range the LightCycler writes (roughly 1.5e3
baseline, 2e3 amplitude) so that the page's orphan noise floor — max(3,
6*MAD, 0.02*median amplitude) — sits well below a real positive and well above
a flat well.  Every well gets independent noise: the page hashes each curve to
seven significant digits and reports any repeat across wells or runs as a
copied-data forensic finding, so templated curves are not an option.
"""
import math


def amp_curve(cq, cycles, rng, base=1700.0, amp=2050.0, k=0.62, noise=7.0, drift=0.0):
    """Logistic amplification.  cq=None gives a flat baseline with noise."""
    out = []
    for c in range(1, cycles + 1):
        v = base + drift * c
        if cq is not None:
            v += amp / (1.0 + math.exp(-k * (c - cq - 3.0)))
        out.append(max(1.0, v + rng.gauss(0, noise)))
    return out


def rn_curve(cq, cycles, rng, base=1.0, top=2.1, k=0.60, noise=0.0035):
    """QuantStudio Rn and the matching baseline-subtracted dRn."""
    rn = []
    for c in range(1, cycles + 1):
        v = base + (top / (1.0 + math.exp(-k * (c - cq))) if cq is not None else 0.0)
        rn.append(v + rng.gauss(0, noise))
    b = sum(rn[2:14]) / 12.0
    return rn, [v - b for v in rn]


def crossing(drn, thr):
    """The page's recalcCt: last upward crossing, linearly interpolated, 1-based."""
    ct = None
    for i in range(1, len(drn)):
        if drn[i - 1] < thr <= drn[i]:
            ct = i + (thr - drn[i - 1]) / (drn[i] - drn[i - 1])
    return ct
