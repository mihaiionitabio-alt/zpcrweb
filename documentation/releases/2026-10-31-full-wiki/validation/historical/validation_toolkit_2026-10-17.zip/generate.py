#!/usr/bin/env python3
"""Generate the synthetic MISSY input set.

    python3 generate.py OUTDIR [--small]

Four cohorts are written.  A cohort is the unit the control charts work in:
every run in it must share InstrumentID, the protocol fingerprint and
InstrumentVersion, and a cohort needs at least 20 runs before the page draws
control limits instead of "collecting baseline".  Faults are therefore injected
into the instrument log, the sample layout or the container — never into the
thermal program, which would split the cohort and empty the charts again.

All identifiers, sample names, readings, Cq values, instrument serials,
operators and dates are invented.  Nothing here is derived from a laboratory
file, an instrument or a real sample.
"""
import argparse, collections, datetime as dt, json, os, random, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eds, ixo, rdml
from layout import design
from ixo import protocol_key

NOTE = ("Synthetic demonstration data. Every identifier, sample name, operator, "
        "instrument serial, date and reading in this file was generated for software "
        "testing. No laboratory sample, experiment, operator or instrument is represented.")


# ---------------------------------------------------------------------------
# What each scenario is supposed to make the page say.
#
# This is the assertion matrix an independent review asked for: without it a
# scenario can be injected, parsed and silently not detected, and the coverage
# count would never notice.  verify.py reads EXPECTED.tsv and checks each row
# against the page's own output for that run.
#
#   status=<text>              the run's acceptance status
#   criterion~<rx>:<status>    a criterion whose name matches, in that status
#   outcome=<name>             at least one sample row of the run with it
#   finding~<rx>               a forensic finding of the run, area+text matched
#   integrity=false            the container check failed for this run
#   orphans>0                  unanalysed rising signal was detected
#   no_error_finding           no error-severity finding at all
# ---------------------------------------------------------------------------
def drift_label(i, n, d):
    """The dominant phenomenon of this run, for MANIFEST.tsv."""
    tags = []
    if d["col_bias"]:
        tags.append("tip_column")
    if d["ntc_detect"] > 0.3:
        tags.append("contamination_rising")
    if d["amp_scale"] < 0.8:
        tags.append("probe_degraded")
    if d["std_slope"] < 3.1:
        tags.append("efficiency_high")
    if d["ctrl_step"]:
        tags.append("new_lot")
    if d["rep_spread"] > 0.4:
        tags.append("weak_operator")
    if d["ref_shift"] > 1.5:
        tags.append("inhibition")
    return "+".join(tags) if tags else "drift_baseline"


EXPECT = {
    "normal": ["status=Accepted with review", "no_error_finding"],
    "controls_only": ["status=Accepted"],
    "ntc_contam": ["criterion~^Control result — NTC$:review",
                   "finding~Control result — NTC"],
    "sd_fail": ["outcome=Repeat", "finding~Replicate"],
    "late_signal": ["outcome=Repeat"],
    "late_ref": ["finding~Inconclusive|late"],
    "ref_missing": ["outcome=Invalid"],
    "partial": ["outcome=Repeat"],
    "eff_bad": ["criterion~^Standard curve:review", "finding~Standard curve"],
    # The same injected disagreement is reported differently by platform: the
    # LightCycler path raises "Stored call — positive result(s) stored exactly at
    # Cq 40", the QuantStudio path raises a Ct-traceability hidden positive,
    # "Undetermined result(s) whose stored ΔRn crosses the threshold".
    "call_disagree": ["finding~Stored call|crosses the threshold"],
    "orphan": ["orphans>0", "finding~not in any analysis|Analysis membership"],
    # An omitted well raises "Plate setup — omitted well(s)" in an .eds and
    # nothing at all in an .ixo, so only the outcome is asserted for both.
    "omitted": ["outcome=Not interpreted"],
    "manual": ["finding~Stored call|uncertain|CQCONF|Ct traceability"],
    "undetermined": ["status=Accepted with review"],
    "pc_drift": ["status=Accepted with review"],
    "created_after_start": ["criterion~created before the run:review", "finding~Timeline"],
    "edit_late": ["criterion~Edited within the allowed window:review"],
    "cal_expired": ["criterion~Calibrations valid:review", "finding~Calibration"],
    "passive_mismatch": ["finding~Passive reference|Plate setup"],
    "runstate_aborted": ["status=Rejected", "criterion~Run completed:fail"],
    "tamper_break": ["integrity=false"],
    "checksum_break": ["integrity=false"],
    "no_log": ["finding~messages.log|Instrument log"],
    "ct_mismatch": ["finding~Ct traceability|re-derived"],
    "saturation": ["status=Accepted with review"],
    "log_errors": ["status=Accepted with review"],
    "sched_catchup": ["status=Accepted with review"],
    # A duplicate name is, by definition, not attributable to one run, so it is
    # checked against the whole set rather than per run.
    "duplicate_name": ["global_finding~Duplicate name"],
    # the DRIFT cohorts: every run is a normal, acceptable run.  What they carry
    # is only visible across the cohort, so the per-run assertion is simply that
    # nothing is broken; the cohort-level effects are checked by verify_drift.py.
    "drift_baseline": ["status=Accepted with review", "no_error_finding"],
}

OPERATORS = ["analyst one", "analyst two", "analyst three"]

# ---------------------------------------------------------------------------
# The method and operator story, for the two DRIFT cohorts only.
#
# The first set left these seven charts quiet, and that was the data's fault
# rather than the page's.  Each entry below is one of them, written as a slow
# change across the 50 runs of a cohort so that it is invisible in any single
# run and only a control chart can find it.  The existing 256 runs are NOT
# touched: these are separate instruments, so the drift never contaminates the
# baselines that the earlier cohorts established.
#
#   probe / dye degradation   amplitude falls 38 % while Cq stays put  -> B-M1
#   efficiency drift          slope 3.32 -> 2.98, crossing 110 %       -> B-M3
#   reagent lot step          a new lot at run 25 shifts control Cq    -> A-M1
#   operator differences      one of three analysts pipettes worse     -> B-O1, funnels
#   row / column pattern      one tip channel short for 16 runs        -> B-O3
#   contamination trend       NTC positive rate rises 0 -> 55 %        -> B-M5
#   inhibition drift          taxon reference creeps +2.6 cycles       -> the IC graph
# ---------------------------------------------------------------------------
WEAK_OPERATOR = "analyst three"

# set by main(); when on, every run is also written as an open exchange record
want_rdml = False
rdmldir = None


def drift_for(i, n, operator):
    """What this run of a DRIFT cohort carries.  frac runs 0 -> 1 over the cohort."""
    frac = i / max(1, n - 1)
    weak = operator == WEAK_OPERATOR
    return {
        "frac": frac,
        "amp_scale": 1.0 - 0.38 * frac,
        "std_slope": 3.32 - 0.34 * frac,
        "lot": 1 + (i >= n // 2),
        "ctrl_step": 0.0 if i < n // 2 else 0.65,
        "ref_shift": 2.6 * frac,
        "ntc_detect": 0.75 * frac,
        "rep_spread": 0.52 if weak else 0.15,
        "col_bias": (7, 0.95) if (n * 2) // 5 <= i < (n * 2) // 3 else None,
    }

LC_PROGRAMS = [
    ("Pre-Incubation", 1, "None", [(95, 300, 4.4, 0)]),
    ("Amplification", 45, "Quantification", [(95, 10, 4.4, 0), (60, 15, 2.2, 0), (72, 4, 4.4, 1)]),
]
# A melting programme changes ccProtocolKey, so only a cohort that carries it in
# every run may have it.  It is what gives the melting-peaks export something to
# write; the side cohort carries it and the main cohort does not.
LC_PROGRAMS_MELT = LC_PROGRAMS + [
    ("Melting Curves", 1, "Melting Curves", [(95, 5, 4.4, 0), (65, 60, 2.2, 0), (97, 0, 0.11, 2)]),
]

# scenario per run index; "normal" everywhere else
LC_SCENARIOS = {
    2: "controls_only", 3: "ntc_contam", 4: "sd_fail", 5: "late_signal", 6: "ref_missing",
    7: "eff_bad", 8: "call_disagree", 9: "orphan", 10: "omitted", 11: "manual",
    12: "partial", 13: "late_ref", 15: "pc_drift", 21: "undetermined",
}
# The side cohorts hold what must not touch a baseline cohort: a missing
# instrument log (no firmware -> mixed cohort), container corruption and the
# duplicate-name pair.
LC_SIDE_SCENARIOS = {1: "orphan", 2: "omitted", 3: "created_after_start",
                     4: "edit_late", 5: "manual", 6: "late_ref"}
QS_SIDE_SCENARIOS = {1: "ntc_contam", 2: "orphan", 3: "no_log", 4: "edit_late",
                     5: "created_after_start", 6: "ct_mismatch"}
QS_SCENARIOS = {
    2: "controls_only", 3: "ntc_contam", 4: "sd_fail", 5: "late_signal", 6: "ref_missing",
    7: "eff_bad", 8: "call_disagree", 9: "orphan", 10: "omitted", 11: "manual",
    12: "cal_expired", 13: "passive_mismatch", 14: "ct_mismatch", 15: "saturation",
    16: "log_errors", 17: "sched_catchup", 19: "runstate_aborted",
    20: "tamper_break", 21: "undetermined",
}


def extract_dates(day, run_index, n_runs, first_day):
    """Control extraction dates, DD.MM.YYYY, always before the run.

    A control material's date is its batch, and the chart segments on it, so the
    date must be constant within a batch — but it must also never be later than
    the run, or the page marks the point "after run" and drops it from the
    control-age chart. Fixed calendar dates do both only by accident: with the
    cohort widened to 96 runs, a hard-coded July date sat after the first 61 runs
    and 61 of 96 points carried an impossible extraction date.

    So the batch dates are anchored to the cohort's own first day. The 415b batch
    runs throughout, so its series accumulates the twenty points the limits need.
    The 410cp batch steps once at the half-way point, and the second date is
    anchored three days before the first run that uses it, so both batches are
    large enough to qualify and neither is in the future.
    """
    d = lambda t: t.strftime("%d.%m.%Y")
    half = n_runs // 2
    # The negative matrix controls feed pc_cq through their own taxon reference,
    # so their date segments that chart too.  A fresh date every run gives one
    # point per segment and no series can ever earn limits, so they are prepared
    # in two batches like the certified materials.
    cn_batch = first_day + dt.timedelta(days=3 * half) if run_index >= half else first_day
    return (d(day - dt.timedelta(days=9)),                     # extraction blank, per run
            d(day - dt.timedelta(days=11)),                    # grinding blank, per run
            d(cn_batch - dt.timedelta(days=7)),                # negative matrix controls
            d(first_day - dt.timedelta(days=9)),               # 415B, one batch throughout
            d(first_day - dt.timedelta(days=6)),               # 415B DIL 1, second aliquot
            d(first_day - dt.timedelta(days=12)) if run_index < half
            else d(first_day + dt.timedelta(days=3 * half - 3)))   # 410CP steps here


def lc_cohort(outdir, cohort, n_runs, rows, cols, seed, first_day, scenarios,
              dup_name_at=None, break_checksum_at=None, melt=False, drifting=False):
    made = []
    for i in range(n_runs):
        rng = random.Random(seed * 1000 + i)
        day = first_day + dt.timedelta(days=3 * i)
        start = day.replace(hour=8, minute=40) + dt.timedelta(minutes=7 * (i % 5))
        end = start + dt.timedelta(minutes=97)
        # The fault table repeats every 24 runs, so a longer cohort carries each
        # fault several times (more weight in the charts) while most runs stay normal.
        sc = scenarios.get(i % 24, "normal")
        D = drift_for(i, n_runs, OPERATORS[i % len(OPERATORS)]) if drifting else {}
        if drifting:
            sc = drift_label(i, n_runs, D)
        wells, meta = design(rng, rows, cols, i, extract_dates(day, i, n_runs, first_day), sc,
                             drift=D if drifting else None)
        if sc == "controls_only":
            wells = [w for w in wells if w.role != "unknown"]
        name = "SC_SYNTH_%s_%03d" % (cohort["tag"], i + 1)
        if break_checksum_at is not None and i == break_checksum_at:
            sc = "checksum_break"
        if dup_name_at is not None and i == dup_name_at:
            sc = "duplicate_name"
            name = "SC_SYNTH_%s_%03d" % (cohort["tag"], dup_name_at)  # deliberate duplicate
        frac = i / max(1, n_runs - 1)
        spec = {
            "name": name, "rows": rows, "cols": cols,
            "programs": LC_PROGRAMS_MELT if melt else LC_PROGRAMS, "melt": melt,
            "uid": "%032X" % rng.getrandbits(128), "owner_uid": cohort["owner"],
            "created": (start + dt.timedelta(minutes=12) if sc == "created_after_start"
                        else start - dt.timedelta(minutes=55)),
            "start": start, "end": end,
            "analysed": end + dt.timedelta(minutes=14),
            "modified": end + dt.timedelta(hours=(96 if sc == "edit_late" else 2)),
            "instrument_id": cohort["instrument_id"],
            "instrument_name": cohort["instrument_name"],
            "firmware": cohort["firmware"], "plate_id": "PLATE-SYN-%s-%03d" % (cohort["tag"], i + 1),
            "operator": OPERATORS[i % len(OPERATORS)],
            "calibration": dt.datetime(2026, 1, 14, 9, 0),
            "notes": NOTE + " Plate %dx%d; scenario %s." % (rows, cols, sc),
            "std_slope": D.get("std_slope", 3.00 if sc == "eff_bad" else 3.32),
            "amp_scale": D.get("amp_scale", 1.0),
            # --- the hardware story the trend charts are meant to show ---
            "thermal": {
                # peak heating rate decays slowly, as a Peltier stack ages, and
                # crosses the 4.3 degC/s specification near the end of the series
                "heat": 4.72 - 0.42 * frac + rng.gauss(0, 0.03),
                "cool": 2.44 - 0.30 * frac + rng.gauss(0, 0.03),
                # overshoot drifts upward: nothing a single run would show, which
                # is the point of the CUSUM chart
                "overshoot": 1.35 + 0.9 * frac + rng.gauss(0, 0.05),
                "jitter_ms": 260.0 if i in (16, 17) else 40.0,
                "late_log_share": 0.06 if i in (14, 19) else 0.0,
            },
            "lamp_ref": [7100.0 - 300 * frac, 12400.0 - 500 * frac,
                         16800.0 - 700 * frac, 20200.0 - 900 * frac],
            "lamp_drift": [-1.2 - 4.0 * frac, -1.5 - 4.2 * frac,
                           -1.9 - 4.6 * frac, -2.4 - 5.0 * frac],
            "invalid_acq": {(3, 1), (12, 2)} if i in (6, 13) else set(),
            "baseline_drift": 2.1 if i in (8, 20) else 0.0,
            "break_checksum": break_checksum_at is not None and i == break_checksum_at,
        }
        body = ixo.build(spec, wells, meta, rng)
        stem = name if not (dup_name_at is not None and i == dup_name_at) else "%s_copy" % name
        fn = os.path.join(outdir, "%s.ixo" % stem)
        with open(fn, "wb") as f:
            f.write(body)
        if want_rdml:
            # the same run as an open exchange record; a fresh Random keeps the
            # .ixo bytes identical to a build made without this option
            rr = random.Random(seed * 1000 + i)
            with open(os.path.join(rdmldir, "%s.rdml" % stem), "wb") as f:
                f.write(rdml.build(spec, wells, meta, rr))
        made.append((fn, name, sc, start))
    return made


def qs_cohort(outdir, cohort, n_runs, rows, cols, seed, first_day, scenarios,
              cycles=40, kind="Std", drifting=False):
    made = []
    for i in range(n_runs):
        rng = random.Random(seed * 1000 + i)
        day = first_day + dt.timedelta(days=3 * i)
        start = day.replace(hour=13, minute=20) + dt.timedelta(minutes=5 * (i % 4))
        end = start + dt.timedelta(minutes=88)
        sc = scenarios.get(i % 24, "normal")
        D = drift_for(i, n_runs, OPERATORS[i % len(OPERATORS)]) if drifting else {}
        if drifting:
            sc = drift_label(i, n_runs, D)
        wells, meta = design(rng, rows, cols, i, extract_dates(day, i, n_runs, first_day), sc,
                             drift=D if drifting else None)
        if sc == "controls_only":
            wells = [w for w in wells if w.role != "unknown"]
        name = "SC_SYNTH_%s_%03d" % (cohort["tag"], i + 1)
        frac = i / max(1, n_runs - 1)
        spec = {
            "name": name, "rows": rows, "cols": cols, "cycles": cycles,
            "uid": "%016X" % rng.getrandbits(64),
            "created_epoch": ((start + dt.timedelta(minutes=12)) if sc == "created_after_start"
                              else (start - dt.timedelta(minutes=50))).timestamp(),
            "start_epoch": start.timestamp(), "end_epoch": end.timestamp(),
            "modified_epoch": (end + dt.timedelta(hours=(140 if sc == "edit_late" else 2))).timestamp(),
            "zip_date": (end + dt.timedelta(hours=2)).timetuple()[:6],
            "mf_date": (end + dt.timedelta(minutes=9)).strftime("#%a %b %d %H:%M:%S UTC %Y")[1:],
            "serial": cohort["serial"], "instrument_name": cohort["instrument_name"],
            "instrument_type": cohort["instrument_type"], "type_key": cohort["type_key"],
            "firmware": cohort["firmware"], "plate_id": "%s-%03d" % (cohort["tag"], i + 1),
            "operator": OPERATORS[i % len(OPERATORS)],
            # in a DRIFT cohort the lot number changes WITH a step in the control
            # Cq and the passive reference, so a lot change is visible as a step
            "lot": "SYN-LOT-%d" % (D["lot"] if drifting else 1 + i // 8),
            "kind": kind,
            "calibrator": next((w.name for w in wells if w.role == "unknown"), ""),
            "notes": NOTE + " Plate %dx%d; scenario %s." % (rows, cols, sc),
            "std_slope": D.get("std_slope", 3.00 if sc == "eff_bad" else 3.32),
            "amp_scale": D.get("amp_scale", 1.0),
            "block_cycles": 1500 + 7 * i, "block_degrees": 47800 + 900 * i,
            # the QuantStudio hardware story
            "qs_heat": 3.55 - 0.30 * frac, "qs_cool": 2.12 - 0.22 * frac,
            "zone_spread": 0.35 + (1.45 if i in (7, 22) else 0.55 * frac),
            "heatsink": 32.4 + 4.5 * frac, "led_current": 9.29 + 0.5 * frac,
            "led_junction": 69.4 + 4.0 * frac,
            "exposure": [15 + int(3 * frac), 18, 22, 26 + int(4 * frac)],
            "wheel_ms": 300 + (520 if i in (11, 19) else int(90 * frac)),
            "cam_overhead_s": 0.42 + 0.22 * frac,
            "img_proc_s": 0.50 + 0.35 * frac, "roi_s": 0.032 + 0.010 * frac,
            "tick_late_ms": 6 + (80 if i in (16, 17) else int(14 * frac)),
            "cmd_rt_extra": 0.22 if i in (9, 18) else 0.0,
            "cover_down_s": 9.6 + 2.4 * frac, "cover_up_s": 5.4 + 0.8 * frac,
            "read_offset": 0.4 + 0.5 * frac,
            "rox_level": (148000.0 - 9000 * frac
                          + (9000.0 if drifting and D["lot"] > 1 else 0.0)),
            "rox_cv": 0.012 + (0.05 if i in (10, 21) else 0.004),
            "calib_edge": 1.14 + 0.12 * frac, "calib_bg": 2300.0 + 500 * frac,
            "calib_roi": 35.5 - 0.6 * frac,
            "saturated_wells": 14 if sc == "saturation" else (2 if i % 9 == 0 else 0),
            "ticks_per_cycle": 6,
        }
        fn = os.path.join(outdir, "%s.eds" % name)
        eds.build(fn, spec, wells, meta, rng)
        if want_rdml:
            rr = random.Random(seed * 1000 + i)
            with open(os.path.join(rdmldir, "%s.rdml" % name), "wb") as f:
                f.write(rdml.build(spec, wells, meta, rr))
        made.append((fn, name, sc, start))
    return made


def history(path, cohort_key, protocol, firmware, instrument, platform, n, first_day, seed):
    """An instrument-history JSON in the page's own import format.

    Optional.  It back-fills earlier runs so a chart shows a long baseline
    without shipping a hundred files.  Rows must carry the same instrument,
    protocol and firmware as the loaded files or the cohort check rejects them.
    """
    rng = random.Random(seed)
    rows = []
    for i in range(n):
        day = first_day + dt.timedelta(days=3 * i)
        frac = i / max(1, n - 1)
        m = {
            "heat_rate": round(4.95 - 0.22 * frac + rng.gauss(0, 0.04), 3),
            "cool_rate": round(2.62 - 0.17 * frac + rng.gauss(0, 0.04), 3),
            "overshoot": round(1.20 + 0.14 * frac + rng.gauss(0, 0.06), 3),
            "settling": round(7.4 + rng.gauss(0, 0.5), 2),
            "run_minutes": round(97 + rng.gauss(0, 1.4), 2),
            "bg_median": {"465-510": round(1690 + rng.gauss(0, 12), 1)},
            "plateau_median": {"465-510": round(3720 + rng.gauss(0, 30), 1)},
            "lamp_ref": {"465-510": round(7420 - 10 * i + rng.gauss(0, 18), 1)},
            "lamp_drift": {"465-510": round(-1.1 - 0.02 * i + rng.gauss(0, 0.12), 3)},
            "exposure": {"465-510": 240},
            "chan_switch": round(1030 + rng.gauss(0, 9), 1),
            "cycle_sd": round(72 + rng.gauss(0, 6), 1),
            "invalid_acq": {"bad": 0, "n": 180},
            "templog_late": {"bad": rng.randint(0, 3), "n": 7600},
            "hold_temp": {"mean": round(0.22 + rng.gauss(0, 0.05), 3),
                          "sd": round(0.11 + rng.gauss(0, 0.02), 3), "n": 45},
            "edit_delay": round(0.30 + rng.gauss(0, 0.10), 3),
            "rep_sd": round(0.18 + rng.gauss(0, 0.03), 3),
            "rowcol": round(0.21 + rng.gauss(0, 0.05), 3),
            "efficiency": {"35S": round(99.4 + rng.gauss(0, 1.8), 2),
                           "T-NOS": round(98.1 + rng.gauss(0, 1.9), 2)},
            "ntc_rate": {"reaction blank": {"bad": 0, "n": 3},
                         "extraction process blank": {"bad": 0, "n": 2}},
            "pc_cq": {"35S | ERM-BF415B": round(31.6 + rng.gauss(0, 0.21), 3),
                      "HMG | ERM-BF415B": round(23.8 + rng.gauss(0, 0.18), 3)},
            "pc_amplitude": {"35S | ERM-BF415B": round(2040 + rng.gauss(0, 55), 1)},
            "pc_batch": {"35S | ERM-BF415B": "extracted 2026-07-14 · 415B",
                         "HMG | ERM-BF415B": "extracted 2026-07-14 · 415B"},
            "action_rate": {"bad": rng.randint(0, 2), "n": 33},
            "late_rate": {"bad": rng.randint(0, 2), "n": 33},
            "call_disagree": {"bad": 0, "n": 60},
            "manual_rate": {"bad": rng.randint(0, 2), "n": 190},
            "copied": {"count": 0}, "findings": {"count": rng.randint(0, 3)},
        }
        rows.append({
            "key": "%s-hist-%03d" % (cohort_key, i),
            "run": "SC_SYNTH_HIST_%03d" % (i + 1),
            "file": "SC_SYNTH_HIST_%03d.ixo" % (i + 1),
            "platform": platform, "instrument": instrument,
            "date": int(day.replace(hour=8, minute=40).timestamp() * 1000),
            "operator": OPERATORS[i % len(OPERATORS)],
            "software": "1.5.1.62", "firmware": firmware,
            "block_cycles": 900 + 6 * i, "protocol": protocol,
            "sop": "SC-06 v1.4", "m": m,
        })
    with open(path, "w") as f:
        json.dump({"schema": "qpcr-instrument-history/1", "rows": rows}, f, indent=1)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--scale", type=int, default=4,
                    help="multiplier on the cohort sizes; 1 gives 64 files, the "
                         "default 4 gives 256")
    ap.add_argument("--small", action="store_true",
                    help="6 runs per cohort — fast, but the control charts will "
                         "say 'collecting baseline'")
    ap.add_argument("--only", default="",
                    help="comma-separated cohort tags (LC96, LC384, QS96, QS384, LCDRIFT, QSDRIFT)")
    ap.add_argument("--drift-runs", type=int, default=50,
                    help="runs in each DRIFT cohort (default 50 per file type)")
    ap.add_argument("--rdml", metavar="DIR", default=None,
                    help="also write every run as an open exchange record (.rdml) "
                         "into DIR; the vendor containers are unchanged")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    global want_rdml, rdmldir
    if a.rdml:
        want_rdml, rdmldir = True, a.rdml
        os.makedirs(rdmldir, exist_ok=True)
    scale = 1 if a.small else max(1, a.scale)
    n_main = 6 if a.small else 24 * scale
    n_side = 3 if a.small else 8 * scale
    want = {t.strip().upper() for t in a.only.split(",") if t.strip()}
    build = lambda tag: not want or tag in want

    LC96 = {"tag": "LC96", "instrument_id": "LC-SYNTH-01", "instrument_name": "LC480",
            "firmware": "1.5.0.39", "owner": "F084C1E0269E459DA1053613CA0BF803"}
    LC384 = {"tag": "LC384", "instrument_id": "LC-SYNTH-02", "instrument_name": "LC480",
             "firmware": "1.5.0.39", "owner": "F084C1E0269E459DA1053613CA0BF803"}
    QS96 = {"tag": "QS96", "serial": "SYNQS-0001", "instrument_name": "SYNQS-0001",
            "instrument_type": "QuantStudio 5 - 96-Well 0.2-mL Block",
            "type_key": "APPLETINI_96WELL_PERFORM_200UL", "firmware": "0.14.12"}
    QS384 = {"tag": "QS384", "serial": "SYNQS-0002", "instrument_name": "SYNQS-0002",
             "instrument_type": "QuantStudio 5 - 384-Well Block",
             "type_key": "APPLETINI_384WELL", "firmware": "0.14.12"}
    # The two drift cohorts carry the method and operator story.  Separate
    # instruments, so their slow changes form their own baselines and leave the
    # four original cohorts exactly as they were.
    LCDRIFT = {"tag": "LCDRIFT", "instrument_id": "LC-SYNTH-03", "instrument_name": "LC480",
               "firmware": "1.5.0.39", "owner": "F084C1E0269E459DA1053613CA0BF803"}
    QSDRIFT = {"tag": "QSDRIFT", "serial": "SYNQS-0003", "instrument_name": "SYNQS-0003",
               "instrument_type": "QuantStudio 5 - 96-Well 0.2-mL Block",
               "type_key": "APPLETINI_96WELL_PERFORM_200UL", "firmware": "0.14.12"}

    d0 = dt.datetime(2026, 1, 12, 8, 40)
    report, t = [], time.time()

    # The two main cohorts are the ones that have to earn control limits, so they
    # carry no container corruption and no missing instrument log: one run with
    # either would be reported as a mixed cohort and withdraw every limit.
    if build("LC96"):
        report += [("LC96", r) for r in lc_cohort(
            a.outdir, LC96, n_main, 8, 12, 11, d0, LC_SCENARIOS)]
        print("LC96   %3d runs  %.1fs" % (n_main, time.time() - t)); t = time.time()
    if build("LC384"):
        report += [("LC384", r) for r in lc_cohort(
            a.outdir, LC384, n_side, 16, 24, 23, d0 + dt.timedelta(days=1),
            LC_SIDE_SCENARIOS, dup_name_at=n_side - 1,
            break_checksum_at=max(0, n_side - 3), melt=True)]
        print("LC384  %3d runs  %.1fs  (melting programme, so the melting-peaks export has data)"
              % (n_side, time.time() - t)); t = time.time()
    if build("QS96"):
        report += [("QS96", r) for r in qs_cohort(
            a.outdir, QS96, n_main, 8, 12, 37, d0, QS_SCENARIOS)]
        print("QS96   %3d runs  %.1fs" % (n_main, time.time() - t)); t = time.time()
    if build("QS384"):
        report += [("QS384", r) for r in qs_cohort(
            a.outdir, QS384, n_side, 16, 24, 53, d0 + dt.timedelta(days=1),
            QS_SIDE_SCENARIOS, kind="rq")]
        print("QS384  %3d runs  %.1fs  (relative-quantification document, so the RQ export has data)"
              % (n_side, time.time() - t))

    n_drift = 6 if a.small else a.drift_runs
    if build("LCDRIFT"):
        report += [("LCDRIFT", r) for r in lc_cohort(
            a.outdir, LCDRIFT, n_drift, 8, 12, 71, d0 + dt.timedelta(days=2), {}, drifting=True)]
        print("LCDRIFT %3d runs  %.1fs  (probe, efficiency, lot, operator, tip, contamination, inhibition)"
              % (n_drift, time.time() - t)); t = time.time()
    if build("QSDRIFT"):
        report += [("QSDRIFT", r) for r in qs_cohort(
            a.outdir, QSDRIFT, n_drift, 8, 12, 83, d0 + dt.timedelta(days=2), {}, drifting=True)]
        print("QSDRIFT %3d runs  %.1fs  (the same story on the QuantStudio side)"
              % (n_drift, time.time() - t)); t = time.time()

    history(os.path.join(a.outdir, "instrument_history_LC-SYNTH-01.json"),
            "lc01", protocol_key(LC_PROGRAMS), "1.5.0.39", "LC · LC-SYNTH-01", "LC",
            40, d0 - dt.timedelta(days=130), 7)

    with open(os.path.join(a.outdir, "MANIFEST.tsv"), "w") as f:
        f.write("cohort\tfile\trun_name\tscenario\trun_start\n")
        for coh, (fn, name, sc, start) in report:
            f.write("%s\t%s\t%s\t%s\t%s\n" % (coh, os.path.basename(fn), name, sc,
                                                 start.strftime("%Y-%m-%d %H:%M")))
    # A duplicate run name cannot carry per-run expectations: findings are keyed
    # by experiment name, so two runs sharing one name are indistinguishable.
    # Those names get only the global duplicate-name check.
    dup = {n for n, c in collections.Counter(
        name for _c, (_f, name, _s, _t) in report).items() if c > 1}
    with open(os.path.join(a.outdir, "EXPECTED.tsv"), "w") as f:
        f.write("run_name\tscenario\tcheck\n")
        wrote = 0
        for _coh, (_fn, name, sc, _start) in report:
            for chk in EXPECT.get(sc, []):
                if name in dup and not chk.startswith("global_"):
                    continue
                f.write("%s\t%s\t%s\n" % (name, sc, chk))
                wrote += 1

    files = os.listdir(a.outdir)
    tot = sum(os.path.getsize(os.path.join(a.outdir, x)) for x in files)
    print("%d files, %.1f MiB -> %s" % (len(files), tot / 1048576, a.outdir))
    print("expectations: %d checks over %d runs (EXPECTED.tsv)" % (wrote, len(report)))


if __name__ == "__main__":
    main()
