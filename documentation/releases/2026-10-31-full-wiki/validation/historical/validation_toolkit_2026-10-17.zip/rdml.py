# -*- coding: utf-8 -*-
"""Write an RDML 1.2 exchange file for a run the generator has already designed.

The point of this writer is that it takes the SAME spec, wells and meta that
ixo.build() and eds.build() take, so the .rdml of a run carries the same Cq
values, the same curves, the same sample names and the same roles as its .ixo or
.eds twin.  A reader comparing the three formats is comparing containers, not
data -- which is what makes the pair useful for demonstrating the RDML path.

RDML is an open exchange format, so it carries less than either vendor
container: no temperature log, no optics telemetry, no instrument log, no
container checksum.  Everything the hardware and software charts read is
therefore absent from a .rdml, by the nature of the format rather than by
omission here.
"""
import datetime as dt
import io, math, zipfile

from layout import TARGETS, T35S, TNOS, THMG, TLEC, CHANNELS
import curves

# RDML sample types.  The generator's roles map onto the controlled vocabulary
# of the schema; "calibrator" is a positive control that also anchors a series.
RDML_SAMPLE_TYPE = {
    "unknown": "unkn", "standard": "std", "ntc": "ntc",
    "negative": "ntc", "positive": "pos", "calibrator": "pos",
}
TARGET_TYPE = {T35S: "toi", TNOS: "toi", THMG: "ref", TLEC: "ref"}
DYE_OF = {t: d for (_n, _a, _b, _c, t, d) in CHANNELS}


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _el(tag, val):
    return "" if val in (None, "") else "<%s>%s</%s>" % (tag, _esc(val), tag)


def _instrument(spec):
    """A platform-bearing instrument string: the family first, then the unit."""
    unit = spec.get("instrument_id") or spec.get("serial") or ""
    if spec.get("instrument_type"):                       # QuantStudio side
        family = spec["instrument_type"]
    elif str(spec.get("instrument_name", "")).upper().startswith("LC"):
        family = "LightCycler %s" % str(spec["instrument_name"])[2:].strip() or "LightCycler"
    else:
        family = spec.get("instrument_name") or "unknown"
    return "%s (%s)" % (family, unit) if unit else family


def _dates(spec):
    """The two cohorts carry their dates differently -- the LightCycler side as
    datetimes, the QuantStudio side as epoch seconds -- so read whichever is
    present rather than assuming one shape."""
    def fmt(v):
        if v is None:
            return None
        if isinstance(v, (int, float)):
            return dt.datetime.utcfromtimestamp(v / 1000.0 if v > 1e11 else v
                                                ).strftime("%Y-%m-%dT%H:%M:%S")
        return v.strftime("%Y-%m-%dT%H:%M:%S")
    made = fmt(spec.get("analysed") or spec.get("end_epoch") or spec.get("mf_date"))
    upd = fmt(spec.get("modified") or spec.get("modified_epoch"))
    start = fmt(spec.get("start") or spec.get("start_epoch"))
    return made, upd, start


def build(spec, wells, meta, rng, cycles=None):
    """Return the bytes of a .rdml container for this run."""
    rows, cols = spec["rows"], spec["cols"]
    cycles = int(cycles or spec.get("cycles") or 45)
    slope = float(spec.get("std_slope", 3.32))
    amp_eff = 10.0 ** (1.0 / slope)                 # fold change per cycle
    scale = float(spec.get("amp_scale", 1.0))
    std_targets = meta.get("std_targets", [T35S, TNOS])

    # ---- the declarations -------------------------------------------------
    samples = {}
    for w in wells:
        if w.omit:
            continue
        samples.setdefault(w.name, RDML_SAMPLE_TYPE.get(w.role, "unkn"))

    made, updated, started = _dates(spec)

    L = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<rdml version="1.2" xmlns="http://www.rdml.org">',
         _el("dateMade", made),
         _el("dateUpdated", updated),
         '<experimenter id="%s"><firstName>%s</firstName><lastName>%s</lastName>'
         '</experimenter>' % (_esc(spec["operator"].replace(" ", "-")),
                              _esc(spec["operator"].split()[0]),
                              _esc(spec["operator"].split()[-1])),
         '<documentation id="synthetic"><text>%s</text></documentation>'
         % _esc("Synthetic demonstration run. No value here was measured; "
                "nothing describes a real sample, plate, operator or laboratory.")]
    for t in TARGETS:
        L.append('<dye id="%s"/>' % _esc(DYE_OF.get(t, "FAM")))
    for name in sorted(samples):
        L.append('<sample id="%s"><type>%s</type></sample>' % (_esc(name), samples[name]))
    for t in TARGETS:
        L.append('<target id="%s"><type>%s</type><dyeId id="%s"/>'
                 '<amplificationEfficiency>%.4f</amplificationEfficiency>'
                 '</target>'
                 % (_esc(t), TARGET_TYPE.get(t, "toi"), _esc(DYE_OF.get(t, "FAM")), amp_eff))

    # ---- the run ----------------------------------------------------------
    R = ['<experiment id="%s"><description>%s</description>'
         % (_esc(spec["name"]), _esc(spec["notes"])),
         # the page prints an RDML run as "experiment / run", so the two ids
         # carry different facts rather than repeating the name twice
         '<run id="%s">' % _esc(spec.get("plate_id") or spec["name"]),
         '<experimenter id="%s"/>' % _esc(spec["operator"].replace(" ", "-")),
         # The page takes <instrument> verbatim as the run's platform, and an SOP
         # profile's applicability test matches on the platform name, so this
         # string has to NAME THE PLATFORM -- "LC480 (LC-SYNTH-01)" was read as
         # a platform of that literal text and every run came back
         # "outside this method" with all 58 charts empty.
         _el("instrument", _instrument(spec)),
         "<dataCollectionSoftware><name>MISSY synthetic generator</name>"
         "<version>%s</version></dataCollectionSoftware>" % _esc(spec.get("firmware", "1.0")),
         _el("backgroundDeterminationMethod", "automatic, cycles 3-10"),
         _el("cqDetectionMethod", "automated threshold and baseline settings"),
         _el("runDate", started),
         "<pcrFormat><rows>%d</rows><columns>%d</columns>"
         "<rowLabel>ABC</rowLabel><columnLabel>123</columnLabel></pcrFormat>" % (rows, cols)]

    for w in wells:
        if w.omit:
            continue
        datas = []
        for t in TARGETS:
            if t not in w.cq:
                continue
            cq = w.cq[t]
            adp = curves.amp_curve(cq, cycles, rng,
                                   amp=(2050.0 - 70.0 * TARGETS.index(t)) * scale,
                                   drift=spec.get("baseline_drift", 0.0))
            d = ['<data><tar id="%s"/>' % _esc(t)]
            if cq is not None:
                d.append("<cq>%.3f</cq>" % cq)
            if w.note:
                d.append(_el("note", w.note))
            d.append("".join("<adp><cyc>%d</cyc><fluor>%.4f</fluor></adp>" % (c + 1, f)
                             for c, f in enumerate(adp)))
            if w.role == "standard" and w.qty and t in std_targets:
                d.append("<N0>%.6g</N0>" % float(w.qty))
            d.append("<ampEff>%.4f</ampEff>" % amp_eff)
            d.append("</data>")
            datas.append("".join(d))
        if not datas:
            continue
        R.append('<react id="%d"><sample id="%s"/>%s</react>'
                 % (w.pos + 1, _esc(w.name), "".join(datas)))
    R.append("</run></experiment>")

    L.extend(R)
    L.append("</rdml>")
    xml = "\n".join(x for x in L if x)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr("rdml_data.xml", xml)
    return buf.getvalue()
