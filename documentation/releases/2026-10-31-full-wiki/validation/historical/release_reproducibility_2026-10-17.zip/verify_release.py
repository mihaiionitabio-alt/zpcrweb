import argparse,hashlib,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('folder');a=p.parse_args();root=Path(a.folder).resolve();manifest=root/'SHA256SUMS.txt';failed=[];count=0
for line in manifest.read_text(encoding='utf-8-sig').splitlines():
 if not line.strip():continue
 expected,name=line.split(None,1);target=(root/name.strip()).resolve()
 if not target.is_relative_to(root) or not target.is_file():failed.append(name);continue
 h=hashlib.sha256()
 with target.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 if h.hexdigest()!=expected.lower():failed.append(name)
 count+=1
print(str(count)+' files checked; '+str(len(failed))+' failed')
for name in failed:print('FAILED: '+name)
sys.exit(bool(failed))
