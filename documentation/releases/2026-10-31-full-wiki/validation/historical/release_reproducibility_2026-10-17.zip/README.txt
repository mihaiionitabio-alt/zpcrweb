Release identity, data provenance and draft citation metadata. After downloading the complete record into one folder, run: python verify_release.py path/to/download-folder

The verifier checks file SHA-256 hashes against SHA256SUMS.txt and reports missing or altered files. It checks artifact integrity only, not scientific validity. The citation file deliberately identifies a draft, not a published new DOI.
