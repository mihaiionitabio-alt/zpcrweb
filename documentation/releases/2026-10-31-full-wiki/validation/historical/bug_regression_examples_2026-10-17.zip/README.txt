SYNTHETIC BUG REGRESSION CASES

These files are generated entirely from invented data. They are not transformed laboratory files.

SYNTHETIC_baseline.ixo: generated normal run.
SYNTHETIC_extra_catalogue.ixo: identical run measurements plus an unselected channel catalogue. Expected: the same active channels and optical metrics as baseline.
SYNTHETIC_ambiguous_mapping.ixo: contradictory embedded acquisition mappings. Expected: reject ambiguous mapping rather than silently label channels. This is deliberately invalid input.

The companion Node/Playwright test also covers missing/reversed thermal logs, signed duration discrepancies and sample-selection preservation. These tests establish only the stated cases.
