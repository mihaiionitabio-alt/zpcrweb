from pathlib import Path
import re,hashlib,struct,json,sys
out=Path(__file__).resolve().parent;source=Path(sys.argv[1]) if len(sys.argv)>1 else out/'SYNTHETIC_baseline.ixo';data=source.read_bytes();end=data.index(b'</objectstream>')+len(b'</objectstream>');body=data[:end].rstrip()+b'\r\n'
def write(name,b):
 h=hashlib.md5(b).digest();trailer='$'+'-'.join('%08X'%struct.unpack('<I',h[i:i+4])[0] for i in (0,4,8,12));(out/name).write_bytes(b+trailer.encode()+b'\r\n')
s=body.decode('utf8');ch=re.findall(r'<obj[^>]*class="HTCChannel"[^>]*>.*?</obj>',s,re.S);assert len(ch)==4
selected='<obj name="SyntheticRunInput" class="TCyclingInput"><obj name="DetFormat" class="HTCDetectionFormat"><prop name="name">SYNTHETIC_SELECTED</prop><list name="channels">'+''.join(ch)+'</list></obj></obj>'
def extra_channel(ex,em):return f'<obj class="HTCChannel"><prop name="name">{ex}-{em}</prop><prop name="Active">1</prop><prop name="ExcitationWL">{ex}</prop><prop name="EmissionWL">{em}</prop></obj>'
catalogue='<obj name="SyntheticCatalogue" class="HTCDetectionFormat"><prop name="name">UNSELECTED_CATALOGUE</prop><list name="channels">'+''.join(extra_channel(*p) for p in [(440,488),(465,510),(533,580)])+'</list></obj>'
write('SYNTHETIC_baseline.ixo',body)
write('SYNTHETIC_extra_catalogue.ixo',s.replace('</objectstream>',selected+catalogue+'</objectstream>').encode('utf8'))
conflicting='<obj class="TCyclingInput"><obj name="DetFormat" class="HTCDetectionFormat"><prop name="name">CONFLICTING_SYNTHETIC</prop><list name="channels">'+extra_channel(533,580)+extra_channel(465,510)+'</list></obj></obj>'
write('SYNTHETIC_ambiguous_mapping.ixo',s.replace('</objectstream>',selected+conflicting+'</objectstream>').encode('utf8'))
(out/'README.txt').write_text('SYNTHETIC BUG REGRESSION CASES\n\nThese files are generated entirely from invented data. They are not transformed laboratory files.\n\nSYNTHETIC_baseline.ixo: generated normal run.\nSYNTHETIC_extra_catalogue.ixo: identical run measurements plus an unselected channel catalogue. Expected: the same active channels and optical metrics as baseline.\nSYNTHETIC_ambiguous_mapping.ixo: contradictory embedded acquisition mappings. Expected: reject ambiguous mapping rather than silently label channels. This is deliberately invalid input.\n\nThe companion Node/Playwright test also covers missing/reversed thermal logs, signed duration discrepancies and sample-selection preservation. These tests establish only the stated cases.\n',encoding='utf8')
