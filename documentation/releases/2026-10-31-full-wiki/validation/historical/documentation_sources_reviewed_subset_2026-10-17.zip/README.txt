REVIEWED DOCUMENTATION SOURCE SUBSET - NOT A COMPLETE PDF REBUILD TREE

Includes generic architecture, workflow, controls, RDML, command mode, interface and synthetic-demo manuscript sources, plus reference preamble/build files. main_reference.tex and build_complete_reference.sh describe the larger workstation tree; missing dependencies mean this subset cannot reproduce the complete 6,437-page manual on its own.

Excluded: all figure/image assets, data tables and CSVs, raw/derived validation appendices, Roche-calibrated reconstruction chapter, unreviewed figure sources, private fixtures, generated PDFs, build logs and the proprietary Microsoft font. Identifier scans are not treated as anonymisation guarantees; excluding the data assets is the primary boundary.

The original 7 October manual and later patch supplement are separate record files. No claim is made that this subset exactly matches all dependencies of that historical PDF.
