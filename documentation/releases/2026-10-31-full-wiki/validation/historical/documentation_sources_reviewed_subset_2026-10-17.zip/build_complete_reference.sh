#!/bin/sh
# Build the MISSY technical documentation as a single PDF.
#
# latexmk drives XeLaTeX over the document, repeating passes until the table of
# contents, the list of figures and every cross-reference have settled.  That
# multi-pass loop is the whole of the build: this document binds in no external
# volumes, so nothing is appended afterwards.
#
# The page total printed in the footer comes from \documentpages in main.tex.
# After a build that changes the length, read the last page number, set
# \documentpages to it and build once more; validate_build.py checks the match.
#
# Requires: xelatex and latexmk.  A CJK font is needed: fonts/msyh.ttc if you
# have it, otherwise Microsoft YaHei or Noto Sans CJK SC from the system.
set -e
cd "$(dirname "$0")"
latexmk main.tex
python3 validate_build.py
echo "done: main.pdf"
