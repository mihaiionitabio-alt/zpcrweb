4000 actual browser page screenshots, release 2026.10.17

Extract all 44 page_screenshots_part ZIPs and the catalogue ZIP into one folder, then open SCREENSHOT_INDEX.html. Search by dataset, category, chart or experiment. PNGs are unchanged 1600x1100 Chromium viewport captures, not generated illustrations, annotated slides or recomposed charts. Only the input records are synthetic.

Counts: {'page': 42, 'review': 54, 'sample_selection': 24, 'control_chart': 630, 'machine_learning': 360, 'graph': 2890}

All 4000 PNG dimensions, unique hashes and file bytes were verified. Selected views across datasets and categories were visually checked. This is not an exhaustive scientific validation of every rendered graph. Native unavailable/rejected states were skipped; see SKIPPED_STATES.json. Capture resumed after an earlier harness interruption; completed captures were retained and hash-checked. CAPTURE_REPORT.json page_errors refers to the final resumed invocation.

Capture application SHA256: e2e4b58082386e77e1c125e962e426439fdb0bddbbc5378e34b15e5c956b67fc
Native controls were selected by Playwright and in-memory chart settings; original HTML and raw input files were unchanged. Sticky page navigation and viewport cropping are part of the actual page. No extra explanatory text was overlaid.

Main and drift input sets are supplied in the format-specific and synthetic_drift_scenarios archives. The additional 384-well fixtures are in screenshot_additional_inputs_2026-10-17.zip. The exact harness and a configurable copy are in screenshot_capture_tools_2026-10-17.zip. Manual volume mappings below preserve each chapter and all 6437 original pages.
