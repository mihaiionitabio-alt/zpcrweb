Original 6437-page manual split only between top-level chapters. Chapters remain complete. Original page artwork and numbering preserved; volume bookmarks added. Every page text compared with the original; first and last page raster rendering of every volume checked byte-for-byte.

Manual_volume_01_pages_0001-0074.pdf: Front matter; What the page does; The original synthetic teaching gallery; Architecture of the single file; Tab 1 · Load files: reading and decoding; Tab 2 · SOP: the laboratory's rules as a profile; Control identity, useful graphs and maintenance associations
Manual_volume_02_pages_0075-0120.pdf: Tab 4 · Control panel: control charts for predictive maintenance and quality control; Tab 5 · Graphs; Tab 6 · Quality & forensic review
Manual_volume_03_pages_0121-0168.pdf: Tab 7 · Open formats; Synthetic equipment-history demonstration; Landscape chart atlases for printing and presentations; RDML exchange input; The console; Command mode and assisted mode; How the code is structured, and why; Missy mark, report selection and export contract; The synthetic demonstration set; How every function in the page was validated; Software diagrams: method and legend
Manual_volume_04_pages_0169-0878.pdf: Function by function
Manual_volume_05_pages_0879-0913.pdf: The page in use, on demonstration data
Manual_volume_06_pages_0914-1253.pdf: Independent checks; The exchange-file reader, case by case; What the validation found; Compiling this document and regenerating the figures; Index of the functions in the HTML file; Complete code of the synthetic data generator; Software design views and function data flow; Complete production source; RDML reader source; Validation evidence and the harness that produced it; Release artifacts and reproducibility
Manual_volume_07_pages_1254-1451.pdf: Complete A4 landscape control-chart atlas
Manual_volume_08_pages_1452-1708.pdf: Atlas manifest and source data; The synthetic demonstration files; The figure atlas; The technical annex; Atlas - across runs; Atlas - control charts
Manual_volume_09_pages_1709-2544.pdf: Atlas - LC96
Manual_volume_10_pages_2545-2924.pdf: Atlas - LC384
Manual_volume_11_pages_2925-3608.pdf: Atlas - LCDRIFT
Manual_volume_12_pages_3609-4444.pdf: Atlas - QS96
Manual_volume_13_pages_4445-4824.pdf: Atlas - QS384
Manual_volume_14_pages_4825-5508.pdf: Atlas - QSDRIFT
Manual_volume_15_pages_5509-6006.pdf: Instrument and variant supplement
Manual_volume_16_pages_6007-6083.pdf: Website guide
Manual_volume_17_pages_6084-6437.pdf: Technical annex